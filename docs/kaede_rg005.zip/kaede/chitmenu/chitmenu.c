/****************************************************
  file: chitmenu.c
  purpose: ���j���[���`�F�L�`�F�L�`�F�L�[�b!��DLL��
 ****************************************************/

#include <windows.h>
#include "../include/checkit_menu_common.h"

#define EXPORT _declspec(dllexport)
#pragma pack(1)
#pragma pack()

#define FMO_NAME "checkit menu text fmo"

typedef struct {
	HHOOK hook;
	HWND server_window;
} * FmoData;

static HINSTANCE st_instance;
static HANDLE st_fmo;
static HHOOK st_hook;
static HWND st_server_window;

static UINT st_window_created_message, st_menu_inited_message;

EXPORT LRESULT CALLBACK hook_proc(int code, WPARAM word_param, LPARAM long_param) {
	if(st_hook==NULL) {
		HANDLE fmo;
		FmoData fmo_data;
		
		fmo = OpenFileMapping(PAGE_READWRITE, FALSE, FMO_NAME);
		if(fmo==NULL) {
			return CallNextHookEx(st_hook, code, word_param, long_param);
		}
		fmo_data = MapViewOfFile(fmo, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(*fmo_data));
		st_hook = fmo_data->hook;
		st_server_window = fmo_data->server_window;
		UnmapViewOfFile(fmo_data);
		CloseHandle(fmo);
	}
	
	if(code<0) {
		return CallNextHookEx(st_hook, code, word_param, long_param);
	} else if(code==HC_ACTION) {
		CWPRETSTRUCT *hook_info = (CWPRETSTRUCT *)long_param;
		
		switch(hook_info->message) {
		case WM_INITMENU:
		case WM_INITMENUPOPUP:
			SendMessage(st_server_window, st_menu_inited_message, (WPARAM)(HMENU)hook_info->wParam, 0);
			break;
		case WM_CREATE:
		case WM_INITDIALOG:
			SendMessage(st_server_window, st_window_created_message, (WPARAM)hook_info->hwnd, 0);
			break;
		}
	}
	
	return CallNextHookEx(st_hook, code, word_param, long_param);
}

EXPORT void set_checkit_menu(HWND server_window) {
	FmoData fmo_data;
	
	st_fmo = CreateFileMapping((HANDLE)-1, NULL, PAGE_READWRITE, 0, sizeof(*fmo_data), FMO_NAME);
	fmo_data = MapViewOfFile(st_fmo, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(*fmo_data));
	fmo_data->hook = SetWindowsHookEx(WH_CALLWNDPROCRET, hook_proc, st_instance, 0);
	fmo_data->server_window = server_window;
	UnmapViewOfFile(fmo_data);
}

EXPORT void reset_checkit_menu(void) {
	FmoData fmo_data;
	
	fmo_data = MapViewOfFile(st_fmo, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(*fmo_data));
	UnhookWindowsHookEx(fmo_data->hook);
	UnmapViewOfFile(fmo_data);
	CloseHandle(st_fmo);
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
	st_instance = instance;
	st_window_created_message = RegisterWindowMessage(WINDOW_CREATED_MESSAGE_NAME);
	st_menu_inited_message = RegisterWindowMessage(MENU_INITED_MESSAGE_NAME);
	return TRUE;
}

/* end of file */