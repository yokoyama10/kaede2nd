/*****************************************
  file: chitcap.c
  purpose: �L���v�V�������`�F�L!!��DLL��
 *****************************************/

#include <windows.h>
#include "../include/checkit_caption_common.h"

#define EXPORT _declspec(dllexport)
#pragma pack(1)
#pragma pack()

#define FMO_NAME "hogege fmo - checkit caption"

typedef struct {
	HHOOK hook;
	HWND server_window;
} * FmoData;

static HANDLE st_fmo;
static HINSTANCE st_instance;
static HHOOK st_hook;
static HWND st_server_window;

static UINT st_window_created_message, st_window_destroyed_message;
static UINT st_text_changed_message, st_focus_set_message;


static LRESULT CALLBACK hook_proc(int code, WPARAM word_param, LPARAM long_param) {
	if(st_hook==NULL) {
		HANDLE fmo;
		FmoData fmo_data;
		
		fmo = OpenFileMapping(PAGE_READWRITE, FALSE, FMO_NAME);
		if(fmo==NULL) {
			return CallNextHookEx(st_hook, code, word_param, long_param);
		}
		fmo_data = MapViewOfFile(fmo, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(*fmo_data));
		st_hook = fmo_data->hook;
		st_server_window = fmo_data->server_window;
		UnmapViewOfFile(fmo_data);
		CloseHandle(fmo);
	}
	
	if(code<0) {
		return CallNextHookEx(st_hook, code, word_param, long_param);
	}
	if(code==HC_ACTION) {
		CWPRETSTRUCT *hook_info = (CWPRETSTRUCT *)long_param;
		
		switch(hook_info->message) {
		case WM_CREATE:
			SendMessage(st_server_window, st_window_created_message, (WPARAM) hook_info->hwnd, 0);
			break;
		case WM_SETTEXT:
			SendMessage(st_server_window, st_text_changed_message, (WPARAM) hook_info->hwnd, hook_info->wParam);
			break;
		case WM_SETFOCUS:
			SendMessage(st_server_window, st_focus_set_message, (WPARAM) hook_info->hwnd, 0);
			break;
		case WM_DESTROY:
			SendMessage(st_server_window, st_window_destroyed_message, (WPARAM) hook_info->hwnd, 0);
			break;
		}
	}
	
	return CallNextHookEx(st_hook, code, word_param, long_param);
}


EXPORT void set_checkit_captions(HWND server_window) {
	FmoData fmo_data;
	HHOOK hook;
	
	hook = SetWindowsHookEx(WH_CALLWNDPROCRET, hook_proc, st_instance, 0);
	st_fmo = CreateFileMapping((HANDLE)-1, NULL, PAGE_READWRITE, 0, sizeof(*fmo_data), FMO_NAME);
	fmo_data = MapViewOfFile(st_fmo, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(*fmo_data));
	fmo_data->hook = hook;
	fmo_data->server_window = server_window;
	UnmapViewOfFile(fmo_data);
}

EXPORT void reset_checkit_captions(void) {
	FmoData fmo_data;
	
	fmo_data = (FmoData) MapViewOfFile(st_fmo, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(*fmo_data));
	UnhookWindowsHookEx(fmo_data->hook);
	UnmapViewOfFile(fmo_data);
	CloseHandle(st_fmo);
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
	st_instance = instance;
	st_window_created_message = RegisterWindowMessage(WINDOW_CREATED_MESSAGE_NAME);
	st_window_destroyed_message = RegisterWindowMessage(WINDOW_DESTROYED_MESSAGE_NAME);
	st_focus_set_message = RegisterWindowMessage(FOCUS_SET_MESSAGE_NAME);
	st_text_changed_message = RegisterWindowMessage(TEXT_CHANGED_MESSAGE_NAME);
	return TRUE;
}

/* end of file */