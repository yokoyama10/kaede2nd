/***************************************************
  file: chitmenu_common.h
  purpose: RegisterWindowMessage�ɓ����镶���񂽂�
 ***************************************************/

#ifndef _CHITMENU_COMMON_H_INCLUDED
#define _CHITMENU_COMMON_H_INCLUDED

#define WINDOW_CREATED_MESSAGE_NAME "checkit menu window created message name"
#define MENU_INITED_MESSAGE_NAME "checkit menu inited message name"

#endif /* _CHITMENU_COMMON_H_INCLUDED */

/* end of file */