/*********************************
  file: checkit_caption_common.h
  purpose: ���b�Z�[�W�̖��O�Ƃ�
 *********************************/

#ifndef _CHECKITCAPTIONCOMMON_H_INCLUDED
#define _CHECKITCAPTIONCOMMON_H_INCLUDED

#define FOCUS_SET_MESSAGE_NAME "checkit caption - focus set message name"
#define TEXT_CHANGED_MESSAGE_NAME "checkit caption - text changed message name"
#define WINDOW_CREATED_MESSAGE_NAME "checkit caption - window created message name"
#define WINDOW_DESTROYED_MESSAGE_NAME "checkit caption - window destroyed message name"

#define MAGIC_WORD 34812

#endif /* _CHECKITCAPTIONCOMMON_H_INCLUDED */
/* end of file */