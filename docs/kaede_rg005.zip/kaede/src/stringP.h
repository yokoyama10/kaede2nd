/*
 * file: stringP.h
 * purpose: private header file for String
 */

#ifndef _PRIVATE_STRINGP_H_INCLUDED
#define _PRIVATE_STRINGP_H_INCLUDED

#include "string.h"

struct tagString {
	char *data;
};

#endif /* _PRIVATE_STRINGP_H_INCLUDED */
/* end of file */
