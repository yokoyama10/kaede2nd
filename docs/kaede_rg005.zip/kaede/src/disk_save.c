/*
 * file: disk_save.c
 * purpose: .kae�t�@�C����save
 */

#include <string.h>
#include <dbcsstr.h>
#include <stdlib.h>
#include "seqFile.h"
#include "application.h"
#include "debug.h"
#include "document.h"
#include "itemList.h"
#include "vipList.h"
#include "shapeList.h"
#include "genreList.h"
#include "shapeList.h"
#include "item.h"

#include "diskP.h"

static void write_header_text(SeqFile file) {
	int i;

	for(i = 0; i < (int)strlen(HEADER_TEXT); i++) {
		SeqFile_write_S8b(file, HEADER_TEXT[i]);
	}
}

static void write_version(SeqFile file) {
	SeqFile_write_U32b(file, Application_VERSION_NUM);
}

static void write_file_version(SeqFile file) {
	SeqFile_write_U32b(file, CURRENT_FILE_VERSION);
}

static void write_crc(SeqFile file) {
	SeqFile_write_U32b(file, SeqFile_crc(file));
}

static void write_item(int id, Item item, void *param) {
	SeqFile file = (SeqFile) param;

	/* write id */
	SeqFile_write_S32b(file, id);

	/* write item */
	SeqFile_write_S32b(file, (SeqFile_S32b)Item_seller_id(item));

	SeqFile_write_string(file, Item_name(item));
	SeqFile_write_string(file, Item_comment(item));

	SeqFile_write_S32b(file, Item_list_price(item));
	SeqFile_write_S32b(file, Item_real_price(item));

	SeqFile_write_S16b(file, (SeqFile_S16b)Item_major_genre(item));
	SeqFile_write_S16b(file, (SeqFile_S16b)Item_minor_genre(item));
	SeqFile_write_S16b(file, (SeqFile_S16b)Item_extra_genre(item));
	SeqFile_write_S16b(file, (SeqFile_S16b)Item_shape(item));

	SeqFile_write_S8b(file, (SeqFile_S8b)Item_is_sold(item));
	SeqFile_write_S8b(file, (SeqFile_S8b)Item_is_returned(item));
	SeqFile_write_S8b(file, (SeqFile_S8b)Item_is_to_be_returned(item));
	SeqFile_write_S8b(file, (SeqFile_S8b)Item_is_to_be_discounted(item));

	SeqFile_write_U32b(file, (SeqFile_U32b) Item_receipt_time(item));
	SeqFile_write_U32b(file, (SeqFile_U32b) Item_sold_time(item));

	SeqFile_write_S8b(file, (SeqFile_S8b) Item_scheduled_date(item));
	SeqFile_write_S8b(file, (SeqFile_S8b) Item_is_by_auction(item));

	SeqFile_write_S32b(file, (SeqFile_S32b) Item_refund_rate(item));
}

typedef struct {
	ConstGenreList genre_list;
	SeqFile file;
} WriteGenre;

static void write_genre_aux(int tag, void *param) {
	WriteGenre *heke = param;

	SeqFile_write_S32b(heke->file, tag);
	SeqFile_write_S32b(heke->file, GenreList_parent(heke->genre_list, tag));
	SeqFile_write_S32b(heke->file, GenreList_order(heke->genre_list, tag));
	SeqFile_write_string(heke->file, GenreList_name(heke->genre_list, tag));
}

static void write_hoge_name_aux(int id, const char * name, void * param) {
	SeqFile file = (SeqFile) param;

	SeqFile_write_string(file, name);
}

static void write_all(SeqFile file, Document document) {
	WriteGenre heke;

	write_header_text(file);
	/* ���Ԃ������܂���! */
	write_file_version(file);
	write_version(file);

	/* write obs */
	SeqFile_write_S32b(file, VipList_count(Document_ob_list(document)));
	VipList_enum(Document_ob_list(document), write_hoge_name_aux, file);

	/* write teachers */
	SeqFile_write_S32b(file, VipList_count(Document_teacher_list(document)));
	VipList_enum(Document_teacher_list(document), write_hoge_name_aux, file);

	/* write genres */
	SeqFile_write_S32b(file, GenreList_count_all(Document_genre_list(document)));
	heke.file = file;
	heke.genre_list = Document_genre_list(document);
	GenreList_enum_all(Document_genre_list(document), write_genre_aux, &heke);

	/* write shapes */
	SeqFile_write_S32b(file, ShapeList_count(Document_shape_list(document)));
	ShapeList_enum(Document_shape_list(document), write_hoge_name_aux, file);

	/* write items */
	SeqFile_write_S32b(file, ItemList_count(Document_item_list(document)));
	ItemList_enum(Document_item_list(document), write_item, file);

	/* write cash */
	SeqFile_write_S32b(file, Document_cash(document));

	/* write refund_rate */
	SeqFile_write_S32b(file, Document_refund_rate(document));

	write_crc(file);
}

Disk_Boolean Disk_save(Document document, const char *path, Disk_ErrorType *error_type) {
	SeqFile file;

	file = SeqFile_create(path, SeqFile_WRITE);
	if(file == NULL) {
		*error_type = Disk_NO_FILE;
		return FALSE;
	}

	write_all(file, document);

	if(SeqFile_is_error(file)) {
		*error_type = Disk_UNKNOWN_SAVE_ERROR;
		SeqFile_destroy(file);
		return FALSE;
	}

	SeqFile_destroy(file);
	*error_type = Disk_SUCCESS;
	return TRUE;
}

/* end of file */
