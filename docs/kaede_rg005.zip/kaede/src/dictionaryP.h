/*
 * file: dictionaryP.h
 * purpose: private header file for Dictionary
 */

#ifndef _PRIVATE_DICTIONARYP_H_INCLUDED
#define _PRIVATE_DICTIONARYP_H_INCLUDED

#define MAX_LEVEL 20

#include "dictionary.h"

typedef struct tagNode * Node;

struct tagNode {
	Dictionary_Key  key;
	Dictionary_Data data;
	int  level;
	Node *forward;
	Node *backward;
};

struct tagDictionary {
	Dictionary_Data default_data;
	Dictionary_Comparer comp_func;
	Node tip_node;
};


#endif /* _PRIVATE_DICTIONARYP_H_INCLUDED */

/* end of file */
