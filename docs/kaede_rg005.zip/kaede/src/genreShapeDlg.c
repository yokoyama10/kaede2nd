/*
 * file: genreShapeDlg.c
 * purpose: �W������/�`��̕ҏW�v���p�e�B
 */

#include <windows.h>
#include "debug.h"
#include "memory.h"
#include "genrePage.h"
#include "shapePage.h"

#include "genreShapeDlgP.h"

GenreShapeDlg_Boolean GenreShapeDlg_is_shapes_cleared(GenreShapeDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));
	
	return ShapePage_is_cleared(dialog->shape_page) ? GenreShapeDlg_TRUE : GenreShapeDlg_FALSE;
}

GenreShapeDlg_Boolean GenreShapeDlg_is_genres_cleared(GenreShapeDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));
	
	return GenrePage_is_cleared(dialog->genre_page) ? GenreShapeDlg_TRUE : GenreShapeDlg_FALSE;
}

const ShapeList GenreShapeDlg_shape_list(GenreShapeDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));
	
	return ShapePage_shape_list(dialog->shape_page);
}

const GenreList GenreShapeDlg_genre_list(GenreShapeDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));
	
	return GenrePage_genre_list(dialog->genre_page);
}

GenreShapeDlg_Boolean GenreShapeDlg_dialogue(GenreShapeDlg dialog, HWND parent_window) {
	HPROPSHEETPAGE pages[2];
	PROPSHEETHEADER sheet;
	HINSTANCE instance;
	
	Debug_assert(Memory_is_on_heap(dialog));
	
	
	instance = (HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE);
	pages[0] = GenrePage_create_page(dialog->genre_page, instance);
	pages[1] = ShapePage_create_page(dialog->shape_page, instance);
	
	sheet.dwSize = sizeof(sheet);
	sheet.dwFlags = PSH_NOAPPLYNOW;
	sheet.hInstance = instance;
	sheet.hwndParent = parent_window;
	sheet.nPages = sizeof(pages) / sizeof(pages[0]);
	sheet.u3.phpage = pages;
	sheet.pszCaption = "�W������/�`��̃��X�g";
	PropertySheet(&sheet);
	if(GenrePage_is_applied(dialog->genre_page) || ShapePage_is_applied(dialog->shape_page)) {
		return GenreShapeDlg_TRUE;
	} else {
		return GenreShapeDlg_FALSE;
	}
}

GenreShapeDlg GenreShapeDlg_create(ConstGenreList genre_list, ShapeList shape_list, ItemList item_list) {
	GenreShapeDlg dialog;
	
	dialog = Memory_malloc(sizeof(*dialog));
	dialog->genre_page = GenrePage_create(genre_list, item_list);
	dialog->shape_page = ShapePage_create(shape_list);
	return dialog;
}

void GenreShapeDlg_destroy(GenreShapeDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));
	
	GenrePage_destroy(dialog->genre_page);
	ShapePage_destroy(dialog->shape_page);
	Memory_free(dialog);
}

/* end of file */
