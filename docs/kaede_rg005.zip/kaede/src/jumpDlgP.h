/*
 * file: jumpDlgP.h
 * purpose: private header file for JumpDlg
 */

#ifndef _PRIVATE_JUMPDLGP_H_INCLUDED
#define _PRIVATE_JUMPDLGP_H_INCLUDED

#include <windows.h>

#include "jumpDlg.h"

#define IDD_JUMP 1011

#define IDC_ITEM_ID 101

struct tagJumpDlg {
	HWND window;
	int item_id;
	JumpDlg_Mode mode;
};

#endif /* _PRIVATE_JUMPDLGP_H_INCLUDED */

/* end of file */
