/*
 * file: sellerMngPanelType.h
 * purpose: public header file for SellerMngPanel
 */

#ifndef _PUBLIC_SELLERMNGPANELTYPE_H_INCLUDED
#define _PUBLIC_SELLERMNGPANELTYPE_H_INCLUDED

typedef struct tagSellerMngPanel *SellerMngPanel;

#endif /* _PUBLIC_SELLERMNGPANELTYPE_H_INCLUDED */

/* end of file */
