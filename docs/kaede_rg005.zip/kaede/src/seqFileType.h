/*
 * file: seqFileType.h
 * purpose: public header file for SeqFile, declaring SeqFile
 */
#ifndef _PUBLIC_SEQFILETYPE_H_INCLUDED
#define _PUBLIC_SEQFILETYPE_H_INCLUDED

typedef struct tagSeqFile *SeqFile;

#endif /* _PUBLIC_SEQFILETYPE_H_INCLUDED */
/* end of file */
