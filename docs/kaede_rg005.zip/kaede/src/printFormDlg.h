/*
 * file: printFormDlg.h
 * purpose: public header file for PrintFormDlg
 */

#ifndef _PUBLIC_PRINTFORMDLG_H_INCLUDED
#define _PUBLIC_PRINTFORMDLG_H_INCLUDED

typedef struct tagPrintFormDlg *PrintFormDlg;

typedef enum {
	PrintFormDlg_TRUE = 1,
	PrintFormDlg_FALSE = 0
} PrintFormDlg_Boolean;


extern int PrintFormDlg_index(PrintFormDlg dialog);
extern PrintFormDlg_Boolean PrintFormDlg_dialogue(PrintFormDlg dialog, HWND parent_window);
extern PrintFormDlg PrintFormDlg_create(int form_count, const char * const * form_names);
extern void PrintFormDlg_destroy(PrintFormDlg dialog);

#endif /* _PUBLIC_PRINTFORMDLG_H_INCLUDED */

/* end of file */
