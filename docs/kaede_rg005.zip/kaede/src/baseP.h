/*
 * file: baseP.h
 * purpose: private header file for Base
 */

#ifndef _PRIVATE_BASEP_H_INCLUDED
#define _PRIVATE_BASEP_H_INCLUDED

#include <windows.h>
#include <commctrl.h>
#include "documentType.h"
#include "sellerMngPanelType.h"
#include "sellerListType.h"

#include "base.h"


#define IDR_MAIN_MENU 1001
#define IDI_MAIN 1001

#define ID_ITEM_ID 1001
#define ID_SELLER 1002
#define ID_ITEM_NAME 1003
#define ID_IS_TO_BE_RETURNED 1004
#define ID_IS_TO_BE_DISCOUNTED 1005
#define ID_LIST_PRICE 1006
#define ID_GENRE 1007
#define ID_SHAPE 1008
#define ID_RECEIPT_TIME 1009
#define ID_SCHEDULED_DATE 1010
#define ID_COMMENT 1011
#define ID_SOLD_TIME 1012
#define ID_IS_SOLD 1013
#define ID_REAL_PRICE 1014
#define ID_IS_BY_AUCTION 1015
#define ID_REFUND_RATE 1017

#define IDS_NO_TITLE_NAME 1021
#define IDS_INVALID_ITEM_ID 1051

#define IDM_NEW_DOCUMENT 101
#define IDM_OPEN_FILE 102
#define IDM_SAVE_FILE 103
#define IDM_SAVE_FILE_AS 104
#define IDM_EXPORT_CSV 105
#define IDM_IMPORT_KAEDE 106
#define IDM_PRINT 107
#define IDM_EXIT 108

#define IDM_EDIT_VIPS_LIST 201
#define IDM_EDIT_GENRES_SHAPES 202
#define IDM_SET_REFUND_RATE 203
#define IDM_DEPOSIT 204
#define IDM_IS_BOOK 205
#define IDM_MODE_COLLECT 211
#define IDM_MODE_SELL 212
#define IDM_MODE_RETURN 213

#define IDM_JUMP 401
#define IDM_SELL 402
#define IDM_SEARCH_ITEM 403
#define IDM_SEARCH_PREV_ITEM 404
#define IDM_SEARCH_NEXT_ITEM 405
#define IDM_GENRE_STATISTICS 406
#define IDM_MONEY_UNIT 407

#define IDM_LEFT_SHEET 501
#define IDM_RIGHT_SHEET 502

#define IDM_CHECKIT_CAPTIONS 601
#define IDM_CHECKIT_MENUS 602
#define IDM_USAGE 603
#define IDM_ABOUT_APPLICATION 604


#define IDS_NO_FILE 1501
#define IDS_UNKNOWN_FILE 1502
#define IDS_DATA_ERROR 1503
#define IDS_CRC_UNMATCH 1504
#define IDS_GET_NEW_VERSION 1505
#define IDS_TOO_OLD_FILE 1506
#define IDS_UNKNOWN_SAVE_ERROR 1507

#define IDS_ASK_SAVE_MODIFIED_FILE 1511

#define IDS_KAE_EXTENSION 1551
#define IDS_KAE_TYPE_NAME 1552
#define IDS_CSV_EXTENSION 1553
#define IDS_CSV_TYPE_NAME 1554
#define IDS_MAKE_SURE_DELETE 1555
#define IDS_HAPPY_BIRTHDAY_KAEDE 1556

#define ID_LIST_VIEW 0
#define ID_STATUS_BAR 1

#define IDD_SELLER 1016


#define CLASS_NAME_MAIN "kaede_main_window"

#define NIL_ITEM -1

typedef enum {
	MODE_COLLECT = 1,
	MODE_SELL,
	MODE_RETURN
} Mode;

typedef struct {
	int column_id;
	Base_Boolean ascend_flag;
} SortDirection;

typedef struct {
	int id;
	Base_Boolean right_allign_flag;
	const char *name;
} ColumnInfo;

struct tagBase {
	HWND main_window;
	HWND list_window;
	HWND status_window;
	
	HINSTANCE instance;
	
	Document document;
	char *file_name;
	Base_Boolean is_document_modified;
	Base_Boolean is_document_new;
	
	unsigned int timer;
	
	SortDirection *sort_directions;
	
	char *search_text;
	Base_Boolean is_first_search;
	
	int total_proceeds;
	int todays_proceeds;
	
	int total_sold_count;
	int todays_sold_count;
	
	Base_Boolean is_book;
	
	Mode mode;
	
	SellerMngPanel seller_mng_panel;
	SellerList seller_list;
};

/* implemented in base_export.c */
extern void bASE_on_export_csv(Base base);

/* implemented in base_proceeds.c */
extern void bASE_modify_proceeds(Base base, int id, ConstItem new_item);
extern void bASE_calc_proceeds(Base base);

/* implemented in base_sort.c */
extern void bASE_sort(Base base, int column_id);

/* implemented in base_display.c */
extern void bASE_display_file_name(Base base);
extern void bASE_display_new_item(Base base, int item_id);
extern void bASE_update_display(Base base);
extern void bASE_display_item_count(Base base);
extern void bASE_display_cash(Base base);
extern void bASE_display_refunder_sum(Base base);
extern void bASE_display_mode(Base base);
extern void bASE_display(Base base);
extern void bASE_on_get_display_info(Base base, NMLVDISPINFO *display_info);

/* implemented in base_coins.c */
extern void bASE_on_money_unit(Base base);


#endif /* _PRIVATE_BASEP_H_INCLUDED */

/* end of file */
