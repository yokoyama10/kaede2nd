/*
 * file: debug.c
 * purpose: debug codes
 */

#include <windows.h>
#include <stdio.h>
#include <stdarg.h>

#include "debug.h"

#define LOG_FILE_NAME "debuglog.txt"

static FILE *st_debug_log;

void Debug_error_func(const char *message) {
	MessageBox(NULL, message, "Kaede", MB_OK | MB_ICONSTOP);
}

void Debug_printf_func(const char *form, ...) {
	va_list marker;
	
	va_start(marker, form);
	vfprintf(st_debug_log, form, marker);
	fflush(st_debug_log);
}

void Debug_initialize_func(void) {
	st_debug_log = fopen(LOG_FILE_NAME, "w");
}

void Debug_finalize_func(void) {
	fclose(st_debug_log);
}

/* end of file */
