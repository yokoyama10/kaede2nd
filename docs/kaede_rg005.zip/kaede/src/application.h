/*
 * file: application.h
 * purpose: version�Ƃ����O�Ƃ�
 */

#ifndef _PUBLIC_APPLICATION_H_INCLUDED
#define _PUBLIC_APPLICATION_H_INCLUDED

#define Application_VERSION_NUM 1005
#define Application_VERSION_INFO "rosa gigantea 005"
#define Application_VERSION_INFO_NULL "rosa gigantea 005\0"

extern void Application_set_name(const char *name);
extern const char *Application_name(void);

#endif /* _PUBLIC_APPLICATION_H_INCLUDED */
/* end of file */
