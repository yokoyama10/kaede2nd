/*
 * file: printP.h
 * purpose: private header file for Print
 */

#ifndef _PRIVATE_PRINTP_H_INCLUDED
#define _PRIVATE_PRINTP_H_INCLUDED

#include "print.h"

typedef struct tagForm {
	char *name;
	
	int text_height; /* 0.1mm */
	int line_margin; /* percent */
	int top_margin;  /* percent */
	int bottom_margin; /* percent */
	int column_width; /* 0.1mm */
	
	int line_count;
	char **lines;
} Form;

#undef TRUE
#undef FALSE

typedef enum {
	TRUE = 1,
	FALSE = 0
} Boolean;

#endif /* _PRIVATE_PRINTP_H_INCLUDED */

/* end of file */
