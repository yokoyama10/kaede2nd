/*
 * file: diskP.h
 * purpose: private header file for Disk
 */

#ifndef _PRIVATE_DISKP_H_INCLUDED
#define _PRIVATE_DISKP_H_INCLUDED

#include "disk.h"

#define HEADER_TEXT "Kaede chan moemoe software by 51st. ennichi han"
#define CURRENT_FILE_VERSION 1003

typedef Disk_Boolean Boolean;
#undef TRUE
#undef FALSE
#define TRUE Disk_TRUE
#define FALSE Disk_FALSE

extern Boolean dISK_read_1001_file(SeqFile file, Document document, Disk_ErrorType *error_type);
extern Boolean dISK_read_1002_file(SeqFile file, Document document, Disk_ErrorType *error_type);

#endif /* _PRIVATE_DISKP_H_INCLUDED */
/* end of file */
