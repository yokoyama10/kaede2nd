/*
 * file: genreListType.h
 * purpose: public header file for GenreList, declaring data type
 */

#ifndef _PUBLIC_GENRETYPE_H_INCLUDED
#define _PUBLIC_GENRETYPE_H_INCLUDED

typedef struct tagGenreList * GenreList;
typedef const struct tagGenreList * ConstGenreList;

#endif /* _PUBLIC_GENRETYPE_H_INCLUDED */
/* end of file */
