/*
 * file: seqFileP.h
 * purpose: private header file for SeqFile
 */

#ifndef _PRIVATE_SEQFILEP_H_INCLUDED
#define _PRIVATE_SEQFILEP_H_INCLUDED

#include <stdio.h>

#include "seqFile.h"

typedef SeqFile_S8b S8b;
typedef SeqFile_S16b S16b;
typedef SeqFile_S32b S32b;
typedef SeqFile_U8b U8b;
typedef SeqFile_U16b U16b;
typedef SeqFile_U32b U32b;
typedef unsigned char Byte;

typedef SeqFile_Boolean Boolean;
#undef TRUE
#undef FALSE
#define TRUE SeqFile_TRUE
#define FALSE SeqFile_FALSE

struct tagSeqFile {
	FILE *file_pointer;
	SeqFile_Mode mode;
	Boolean is_error;
	U32b not_crc;
};

#endif /* _PRIVATE_SEQFILEP_H_INCLUDED */
/* end of file */
