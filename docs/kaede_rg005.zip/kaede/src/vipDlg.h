/*
 * file: vipDlg.h
 * purpose: public header file for VipDlg
 */

#ifndef _PUBLIC_VIPDLG_H_INCLUDED
#define _PUBLIC_VIPDLG_H_INCLUDED

#include "vipListType.h"

typedef enum {
	VipDlg_TRUE = 1,
	VipDlg_FALSE = 0
} VipDlg_Boolean;

typedef struct tagVipDlg *VipDlg;

extern const VipList VipDlg_ob_list(VipDlg dialog);
extern const VipList VipDlg_teacher_list(VipDlg dialog);
extern VipDlg_Boolean VipDlg_dialogue(VipDlg dialog, HWND parent_window);
extern VipDlg VipDlg_create(VipList ob_list, VipList teacher_list);
extern void VipDlg_destroy(VipDlg dialog);

#endif /* _PUBLIC_VIPDLG_H_INCLUDED */
/* end of file */
