/*
 * file: genreList.c
 * purpose: �W�������̊Ǘ�
 */

#include <string.h>
#include "string.h"
#include "memory.h"
#include "debug.h"

#include "genreListP.h"

static int search_genre(ConstGenreList genre_list, int tag) {
	int i;
	
	for(i = 0; i < genre_list->genre_count; i++) {
		if(genre_list->genres[i]->tag == tag) {
			return i;
		}
	}
	return -1;
}

static Genre genre_create(void) {
	Genre genre;

	genre = Memory_malloc(sizeof(*genre));
	genre->name = String_make(NULL, "");
	return genre;
}

static void genre_destroy(Genre genre) {
	Memory_free(genre->name);
	Memory_free(genre);
}

GenreList_Boolean GenreList_including(ConstGenreList genre_list, int tag) {
	if(search_genre(genre_list, tag) != -1) {
		return GenreList_TRUE;
	} else {
		return GenreList_FALSE;
	}
}

int GenreList_count_all(ConstGenreList genre_list) {
	Debug_assert(Memory_is_on_heap(genre_list));

	return genre_list->genre_count;
}

void GenreList_enum_all(ConstGenreList genre_list, void (*proc)(int tag, void *param), void *param) {
	int i;

	Debug_assert(Memory_is_on_heap(genre_list));
	for(i = 0; i < genre_list->genre_count; i++) {
		proc(genre_list->genres[i]->tag, param);
	}
}

void GenreList_enum(ConstGenreList genre_list, int parent, void (*proc)(int tag, void *param), void *param) {
	int i;

	Debug_assert(Memory_is_on_heap(genre_list));
	Debug_assert(parent != NIL_GENRE_TAG);

	for(i = 0; i < genre_list->genre_count; i++) {
		if(genre_list->genres[i]->parent == parent) {
			proc(genre_list->genres[i]->tag, param);
		}
	}
}

int GenreList_index2tag(ConstGenreList genre_list, int parent, int index) {
	int i, count;

	Debug_assert(Memory_is_on_heap(genre_list));
	if(index == 0) {
		return GenreList_UNDEFINED;
	}
	for(i = 0, count = 0; count < index; i++) {
		if(genre_list->genres[i]->parent == parent) {
			count += 1;
		}
	}
	return genre_list->genres[i - 1]->tag;
}

int GenreList_index(ConstGenreList genre_list, int tag) {
	int parent;
	int index;
	int i, j;

	if(tag == GenreList_UNDEFINED) {
		return 0;
	}
	Debug_assert(Memory_is_on_heap(genre_list));
	Debug_assert(tag != GenreList_NIL);
	j = search_genre(genre_list, tag);
	Debug_assert(j >= 0);
	parent = genre_list->genres[j]->parent;
	for(i = 0, index = 1; genre_list->genres[i]->tag != tag; i++) {
		if(genre_list->genres[i]->parent == parent) {
			index += 1;
		}
	}
	return index;
}

const char *GenreList_order_text(ConstGenreList genre_list, int tag, char *text) {
	int index, order;

	Debug_assert(Memory_is_on_heap(genre_list));
	index = search_genre(genre_list, tag);
	if(index < 0) {
		strcpy(text, "*");
		return text;
	}

	order = (genre_list->genres[index]->order - 1) % 52 + 1;
	if(order <= 26) {
		text[0] = 'a' - 1 + order;
	} else {
		text[0] = 'A' - 1 + order - 26;
	}
	text[1] ='\0';
	return text;
}

int GenreList_order(ConstGenreList genre_list, int tag) {
	int index;

	Debug_assert(genre_list);
	index = search_genre(genre_list, tag);
	Debug_assert(index >= 0);
	return genre_list->genres[index]->order;
}

int GenreList_parent(ConstGenreList genre_list, int tag) {
	int index;
	
	Debug_assert(Memory_is_on_heap(genre_list));
	Debug_assert(tag != NIL_GENRE_TAG);
	
	index = search_genre(genre_list, tag);
	Debug_assert(index >= 0);
	return genre_list->genres[index]->parent;
}

const char *GenreList_name(ConstGenreList genre_list, int tag) {
	int index;

	Debug_assert(Memory_is_on_heap(genre_list));
	Debug_assert(tag != NIL_GENRE_TAG);

	if(tag == GenreList_UNDEFINED) {
		return "����";
	}
	index = search_genre(genre_list, tag);
	Debug_assert(index >= 0);

	return genre_list->genres[index]->name;
}

void GenreList_set_name(GenreList genre_list, int tag, const char *name) {
	int index;

	Debug_assert(Memory_is_on_heap(genre_list));
	Debug_assert(tag != NIL_GENRE_TAG);

	index = search_genre(genre_list, tag);
	Debug_assert(index >= 0);
	genre_list->genres[index]->name = String_make(genre_list->genres[index]->name, name);
}

int GenreList_add(GenreList genre_list, int parent) {
	int i, order, tag;

	Debug_assert(Memory_is_on_heap(genre_list));
	Debug_assert(parent!=NIL_GENRE_TAG);

	order = 1;
	for(i = 0; i < genre_list->genre_count; i++) {
		if(genre_list->genres[i]->parent == parent) {
			order = genre_list->genres[i]->order + 1;
		}
	}
	if(genre_list->genre_count == 0) {
		tag = 1;
	} else {
		tag = genre_list->genres[genre_list->genre_count - 1]->tag + 1;
	}

	genre_list->genres = Memory_realloc(genre_list->genres,
			sizeof(Genre) * (genre_list->genre_count + 1));
	genre_list->genres[genre_list->genre_count] = genre_create();
	genre_list->genres[genre_list->genre_count]->tag = tag;
	genre_list->genres[genre_list->genre_count]->parent = parent;
	genre_list->genres[genre_list->genre_count]->order = order;
	genre_list->genre_count += 1;
	return tag;
}

static void delete(GenreList genre_list, int tag) {
	int i, index;

	for(i = 0; i < genre_list->genre_count; i++) {
		if(genre_list->genres[i]->parent == tag) {
			delete(genre_list, genre_list->genres[i]->tag);
			i--;
		}
	}

	index = search_genre(genre_list, tag);
	genre_destroy(genre_list->genres[index]);
	for(i = index + 1; i < genre_list->genre_count; i++) {
		genre_list->genres[i - 1] = genre_list->genres[i];
	}
	genre_list->genres = Memory_realloc(genre_list->genres,
			sizeof(Genre) * (genre_list->genre_count - 1));
	genre_list->genre_count -= 1;
}

void GenreList_delete(GenreList genre_list, int tag) {
	delete(genre_list, tag);
}

void GenreList_insert(GenreList genre_list, int tag, int parent, int order, const char *name) {
	genre_list->genres = Memory_realloc(genre_list->genres,
			sizeof(Genre) * (genre_list->genre_count + 1));
	genre_list->genres[genre_list->genre_count] = genre_create();
	genre_list->genres[genre_list->genre_count]->tag = tag;
	genre_list->genres[genre_list->genre_count]->parent = parent;
	genre_list->genres[genre_list->genre_count]->order = order;
	genre_list->genres[genre_list->genre_count]->name =
		String_make(genre_list->genres[genre_list->genre_count]->name, name);
	genre_list->genre_count += 1;
}

void GenreList_clear(GenreList genre_list) {
	int i;
	
	Debug_assert(Memory_is_on_heap(genre_list));
	
	for(i = 0; i < genre_list->genre_count; i++) {
		genre_destroy(genre_list->genres[i]);
	}
	Memory_free(genre_list->genres);
	genre_list->genres = NULL;
	genre_list->genre_count = 0;
}

static void copy_data(GenreList dest, ConstGenreList src) {
	int i;
	
	dest->genres = Memory_malloc(sizeof(Genre)*src->genre_count);
	for(i = 0; i < src->genre_count; i++) {
		dest->genres[i] = genre_create();
		dest->genres[i]->order = src->genres[i]->order;
		dest->genres[i]->tag = src->genres[i]->tag;
		dest->genres[i]->parent = src->genres[i]->parent;
		dest->genres[i]->name = String_make(dest->genres[i]->name, src->genres[i]->name);
	}
	dest->genre_count = src->genre_count;
	dest->next_tag = src->next_tag;
}

GenreList GenreList_clone(ConstGenreList genre_list) {
	GenreList clone;
	
	clone = GenreList_create();
	copy_data(clone, genre_list);
	return clone;
}

GenreList GenreList_create(void) {
	GenreList genre_list;
	
	genre_list = Memory_malloc(sizeof(*genre_list));
	genre_list->next_tag = 0;
	genre_list->genre_count = 0;
	genre_list->genres = NULL;
	return genre_list;
}

void GenreList_destroy(GenreList genre_list) {
	int i;
	
	Debug_assert(Memory_is_on_heap(genre_list));
	
	for(i = 0; i < genre_list->genre_count; i++) {
		genre_destroy(genre_list->genres[i]);
	}
	
	Memory_free(genre_list->genres);
	Memory_free(genre_list);
}

/* end of file */
