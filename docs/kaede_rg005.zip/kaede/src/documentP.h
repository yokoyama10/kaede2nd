/*
 * file: documentP.h
 * purpose: private header file for Document
 */

#ifndef _PRIVATE_DOCUMENTP_H_INCLUDED
#define _PRIVATE_DOCUMENTP_H_INCLUDED

#include "itemListType.h"
#include "vipListType.h"
#include "shapeListType.h"
#include "genreListType.h"

#include "document.h"

struct tagDocument {
	ItemList item_list;
	VipList ob_list;
	VipList teacher_list;
	GenreList genre_list;
	ShapeList shape_list;

	int cash;

	int refund_rate;
};

#endif /* _PRIVATE_DOCUMENTP_H_INCLUDED */
/* end of file */
