/*
 * file: refundRateDlg.h
 * purpose: public header file for RefundRateDlg
 */

#ifndef _PUBLIC_REFUNDRATEDLG_H_INCLUDED
#define _PUBLIC_REFUNDRATEDLG_H_INCLUDED

typedef enum {
	RefundRateDlg_TRUE = 1,
	RefundRateDlg_FALSE = 0
} RefundRateDlg_Boolean;

typedef struct tagRefundRateDlg * RefundRateDlg;


extern int RefundRateDlg_refund_rate(RefundRateDlg dialog);
extern RefundRateDlg_Boolean RefundRateDlg_dialogue(RefundRateDlg dialog, HWND parent_window);
extern RefundRateDlg RefundRateDlg_create(int refund_rate);
extern void RefundRateDlg_destroy(RefundRateDlg dialog);

#endif /* _PUBLIC_REFUNDRATEDLG_H_INCLUDED */

/* end of file */
