/*
 * file: shapeListType.h
 * purpose: public header file for ShapeList
 */

#ifndef _PUBLIC_SHAPELISTTYPE_H_INCLUDED
#define _PUBLIC_SHAPELISTTYPE_H_INCLUDED

typedef struct tagShapeList *ShapeList;

#endif /* _PUBLIC_SHAPELISTTYPE_H_INCLUDED */

/* end of file */
