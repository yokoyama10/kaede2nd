/*
 * file: string.h
 * purpose: public header file for String
 */

#ifndef _PUBLIC_STRING_H_INCLUDED
#define _PUBLIC_STRING_H_INCLUDED

extern char *String_make(char *block, const char *src);

#endif /* _PUBLIC_STRING_H_INCLUDED */
/* end of file */
