/*
 * file: genreListP.h
 * purpose: private header file for GenreList
 */

#ifndef _PRIVATE_GENREP_H_INCLUDED
#define _PRIVATE_GENREP_H_INCLUDED

#include "genreList.h"

#define NIL_GENRE_TAG GenreList_NIL
#define TOP_GENRE_TAG GenreList_TOP

typedef struct tagGenre * Genre;

struct tagGenre {
	int order;
	int tag;
	char *name;
	int parent;
};

struct tagGenreList {
	Genre *genres;
	int genre_count;
	int next_tag;
};

#endif /* _PRIVATE_GENREP_H_INCLUDED */
/* end of file */
