/*
 * file: genreShapeDlgP.h
 * purpose: private header file for GenreShapeDlg
 */

#ifndef _PRIVATE_GENRESHAPEDLGP_H_INCLUDED
#define _PRIVATE_GENRESHAPEDLGP_H_INCLUDED

#include <windows.h>
#include "genreListType.h"
#include "shapeListType.h"
#include "genrePageType.h"
#include "shapePageType.h"

#include "genreShapeDlg.h"

#undef TRUE
#undef FALSE
#define TRUE GenreShapeDlg_TRUE
#define FALSE GenreShapeDlg_FALSE
typedef GenreShapeDlg_Boolean Boolean;

struct tagGenreShapeDlg {
	GenrePage genre_page;
	ShapePage shape_page;
};


/*---------------------------------------*
   defined in genreShapeDlg_shapePage.c
 *---------------------------------------*/
extern HPROPSHEETPAGE genreShapeDlg_ShapePage_create_page(ShapePage page, HINSTANCE instance);
extern ShapePage genreShapeDlg_ShapePage_create(GenreShapeDlg dialog, ShapeList shape_list);
extern void genreShapeDlg_ShapePage_destroy(ShapePage page);

/*---------------------------------------
   defined in genreShapeDlg_genrePage.c
 *---------------------------------------*/
extern HPROPSHEETPAGE genreShapeDlg_GenrePage_create_page(GenrePage page, HINSTANCE instance);
extern GenrePage genreShapeDlg_GenrePage_create(GenreShapeDlg dialog, ConstGenreList genre_list);
extern void genreShapeDlg_GenrePage_destroy(GenrePage page);

#endif _PRIVATE_GENRESHAPEDLGP_H_INCLUDED
/* end of file */
