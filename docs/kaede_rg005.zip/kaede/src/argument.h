/*
 * file: argument.h
 * purpose: public header file for Argument
 */

#ifndef _PUBLIC_ARGUMENT_H_INCLUDED
#define _PUBLIC_ARGUMENT_H_INCLUDED

extern void Argument_split_command_line(const char *command_line, int *argc_ref, char ***argv_ref);

#endif /* _PUBLIC_ARGUMENT_H_INCLUDED */
/* end of file */
