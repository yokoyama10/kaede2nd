/********************************************
  file: itemListType.h
  purpose: public header file for ItemList
 ********************************************/

#ifndef _PUBLIC_ITEMLISTTYPE_H_INCLUDED
#define _PUBLIC_ITEMLISTTYPE_H_INCLUDED

typedef struct tagItemList * ItemList;

#endif /* _PUBLIC_ITEMLISTTYPE_H_INCLUDED */
/* end of file */