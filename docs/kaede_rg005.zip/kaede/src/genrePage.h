/*
 * file: genrePage.h
 * purpose: public header file for GenrePage
 */

#ifndef _PUBLIC_GENREPAGE_H_INCLUDED
#define _PUBLIC_GENREPAGE_H_INCLUDED

#include "genreListType.h"
#include "itemListType.h"

#include "genrePageType.h"

typedef enum {
	GenrePage_TRUE = 1,
	GenrePage_FALSE = 0
} GenrePage_Boolean;

extern HPROPSHEETPAGE GenrePage_create_page(GenrePage page, HINSTANCE instance);
extern GenreList GenrePage_genre_list(GenrePage page);
extern GenrePage_Boolean GenrePage_is_cleared(GenrePage page);
extern GenrePage_Boolean GenrePage_is_applied(GenrePage page);
extern GenrePage GenrePage_create(ConstGenreList genre_list, ItemList item_list);
extern void GenrePage_destroy(GenrePage page);

#endif /* _PUBLIC_GENREPAGE_H_INCLUDED */

/* end of file */
