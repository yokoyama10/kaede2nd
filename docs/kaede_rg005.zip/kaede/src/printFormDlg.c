/*
 * file: printFormDlg.c
 * purpose: �v�����g�̏����I���̃_�C�A���O
 */

#include <windows.h>
#include "memory.h"
#include "debug.h"

#include "printFormDlgP.h"

#define TOUCH(a) ((void)(a))


int PrintFormDlg_index(PrintFormDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	return dialog->index;
}

static void on_init_dialog(PrintFormDlg dialog) {
	int i;

	dialog->ctrls.forms = GetDlgItem(dialog->window, IDC_FORMS);
	for(i = 0; i < dialog->form_count; i++) {
		SendMessage(dialog->ctrls.forms, CB_ADDSTRING, 0, (LPARAM)dialog->form_names[i]);
	}
	SendMessage(dialog->ctrls.forms, CB_SETCURSEL, 0, 0);
}

static void on_ok(PrintFormDlg dialog) {
	dialog->index = SendMessage(dialog->ctrls.forms, CB_GETCURSEL, 0, 0);
	EndDialog(dialog->window, IDOK);
}

static BOOL on_command(PrintFormDlg dialog, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDOK:
		on_ok(dialog);
		break;
	case IDCANCEL:
		EndDialog(dialog->window, IDCANCEL);
		break;
	}
	TOUCH(notify_code);
	TOUCH(ctrl_window);
	return TRUE;
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	PrintFormDlg dialog;

	if(message == WM_INITDIALOG) {
		dialog = (PrintFormDlg)long_param;
		SetWindowLong(dialog_window, DWL_USER, (LONG)dialog);
		dialog->window = dialog_window;
	}
	dialog = (PrintFormDlg)GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_INITDIALOG:
		on_init_dialog(dialog);
		break;
	case WM_COMMAND:
		on_command(dialog, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

PrintFormDlg_Boolean PrintFormDlg_dialogue(PrintFormDlg dialog, HWND parent_window) {
	int return_value;
	HINSTANCE instance = (HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE);

	Debug_assert(Memory_is_on_heap(dialog));

	return_value = DialogBoxParam(instance, MAKEINTRESOURCE(IDD_PRINT_FORM), parent_window, dialog_proc, (long)dialog);
	if(return_value == IDOK) {
		return PrintFormDlg_TRUE;
	} else {
		return PrintFormDlg_FALSE;
	}
}

PrintFormDlg PrintFormDlg_create(int form_count, const char * const * form_names) {
	PrintFormDlg dialog;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->form_count = form_count;
	dialog->form_names = form_names;
	return dialog;
}

void PrintFormDlg_destroy(PrintFormDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	Memory_free(dialog);
}

/* end of file */
