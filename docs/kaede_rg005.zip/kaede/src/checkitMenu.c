/*
 * file: checkitMenu.c
 * purpose: ���j���[��������`�F�L�`�F�L�`�F�L�[�b!
 */

#include <windows.h>
#include "debug.h"
#include "../include/checkit_menu_common.h"

#include "checkitMenuP.h"

#define SERVER_WINDOW_CLASS_NAME "checkit menu window class"
#define DLL_NAME "chitmenu.dll"

static HINSTANCE st_instance;

static Boolean st_initialized = FALSE;

static HMODULE st_dll;
static Boolean st_is_checkiting;
static HWND st_server_window;

static UINT st_window_created_message, st_menu_inited_message;

typedef void (*SetCheckitMenu)(HWND);
typedef void (*ResetCheckitMenu)(void);


static void checkit_menu_text(char *dest, const char *source) {
	char *foot;

	foot = strstr(source, "(&");
	if(foot == NULL) {
		foot = strstr(source, "...");
	}
	if(foot == NULL) {
		foot = strstr(source, "\t");
	}


	if(foot != NULL) {
		strncpy(dest, source, foot-source);
		dest[foot-source] = 0;
	} else {
		strcpy(dest, source);
	}

	if(strlen(dest) <= strlen("�ɂ�") ||
			strcmp(dest + strlen(dest) - strlen("�ɂ�"), "�ɂ�") != 0) {
		strcat(dest, "�ɂ�");
	}

	if(foot != NULL) {
		strcat(dest, foot);
	}
}

static void checkit_menu(HMENU menu) {
	int menu_item_count = GetMenuItemCount(menu);
	int i;
	MENUITEMINFO item_info;

	if(menu == NULL) {
		return;
	}
	for(i = 0; i < menu_item_count; i++) {
		char org_text[256];

		item_info.cbSize = sizeof(item_info);
		item_info.fMask = MIIM_TYPE;
		item_info.dwTypeData = org_text;
		item_info.cch = sizeof(org_text) - 1;
		GetMenuItemInfo(menu, i, TRUE, &item_info);

		if(!(item_info.fType&(MFT_BITMAP | MFT_SEPARATOR | MFT_OWNERDRAW))) {
			char new_text[256];

			checkit_menu_text(new_text, org_text);
			item_info.cbSize = sizeof(item_info);
			item_info.fMask = MIIM_TYPE;
			item_info.dwTypeData = new_text;
			item_info.cch = strlen(new_text);
			SetMenuItemInfo(menu, i, TRUE, &item_info);
		}
	}
}

static void on_menu_inited(HMENU menu) {
	checkit_menu(menu);
}

static void on_window_created(HWND window) {
	checkit_menu(GetMenu(window));
}

static LRESULT CALLBACK server_window_proc(HWND window,UINT message,WPARAM word_param,LPARAM long_param) {
	if(message == st_window_created_message) {
		on_window_created((HWND)word_param);
	} else if(message == st_menu_inited_message) {
		on_menu_inited((HMENU)word_param);
	} else {
		return DefWindowProc(window, message, word_param, long_param);
	}
	return 0L;
}

static HWND create_server_window(void) {
	return CreateWindow(SERVER_WINDOW_CLASS_NAME, "checkit menu", WS_POPUP,
			-30, -30, 20, 20, NULL, NULL, st_instance, NULL);
}

static void regist_window_class(void) {
	WNDCLASS window_class;

	window_class.style = CS_HREDRAW|CS_VREDRAW;
	window_class.lpfnWndProc = server_window_proc;
	window_class.cbClsExtra = 0;
	window_class.cbWndExtra = 0;
	window_class.hInstance = st_instance;
	window_class.hIcon = NULL;
	window_class.hCursor = LoadCursor(0,IDC_ARROW);
	window_class.hbrBackground = GetStockObject(WHITE_BRUSH);
	window_class.lpszMenuName = (LPSTR)NULL;
	window_class.lpszClassName = SERVER_WINDOW_CLASS_NAME;
	RegisterClass(&window_class);
}

static BOOL CALLBACK enum_proc(HWND window, LPARAM long_param) {
	checkit_menu(GetMenu(window));
	EnumChildWindows(window, enum_proc, 0);
	return (BOOL)TRUE;
}

static void checkit_all_menus(void) {
	EnumWindows(enum_proc, 0);
}

CheckitMenu_Boolean CheckitMenu_checkit(void) {
	SetCheckitMenu set_checkit_menu;

	Debug_assert(st_initialized);

	if(st_dll==NULL || st_is_checkiting) {
		return FALSE;
	}

	checkit_all_menus();
	st_server_window = create_server_window();
	set_checkit_menu = (SetCheckitMenu) GetProcAddress(st_dll, "_set_checkit_menu");
	set_checkit_menu(st_server_window);
	st_is_checkiting = TRUE;

	return TRUE;
}

void CheckitMenu_uncheckit(void) {
	ResetCheckitMenu reset_checkit_menu;

	Debug_assert(st_initialized);

	if(st_dll==NULL || !st_is_checkiting) {
		return;
	}

	reset_checkit_menu = (ResetCheckitMenu) GetProcAddress(st_dll, "_reset_checkit_menu");
	st_is_checkiting = FALSE;
	reset_checkit_menu();
	DestroyWindow(st_server_window);
}

CheckitMenu_Boolean CheckitMenu_is_checkiting(void) {
	Debug_assert(st_initialized);

	return st_is_checkiting;
}

void CheckitMenu_initialize(HINSTANCE instance) {
	Debug_assert(!st_initialized);

	st_instance = instance;

	st_initialized = TRUE;

	st_dll = LoadLibrary(DLL_NAME);
	st_is_checkiting = FALSE;
	regist_window_class();
	st_menu_inited_message = RegisterWindowMessage(MENU_INITED_MESSAGE_NAME);
	st_window_created_message = RegisterWindowMessage(WINDOW_CREATED_MESSAGE_NAME);
}

void CheckitMenu_finalize(void) {
	Debug_assert(st_initialized);

	if(st_is_checkiting) {
		CheckitMenu_uncheckit();
	}
	FreeLibrary(st_dll);

	st_initialized = FALSE;
}

/* end of file */
