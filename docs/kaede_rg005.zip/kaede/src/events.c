/*
 * file: events.c
 * purpose: �o�[�W�������_�C�A���O�ŕ\�����鎞�����e�̊Ǘ�
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <dbcsstr.h>
#include <time.h>
#include <stdlib.h>
#include "memory.h"
#include "debug.h"
#include "config.h"
#include "string.h"

#include "eventsP.h"

static int st_event_count;
static Event *st_events;
Boolean st_is_initialized = FALSE;

static void load_event(Event *event, int index) {
	char config_file_name[512];
	char section_name[128];
	struct tm from, to;
	char name1[128], name2[128];
	
	strcpy(config_file_name, Config_file_name());
	
	sprintf(section_name, "EventForm%d", index + 1);
	
	GetPrivateProfileString(section_name, "name1", "", name1, sizeof(name1), config_file_name);
	GetPrivateProfileString(section_name, "name2", "", name2, sizeof(name2), config_file_name);
	
	event->name1 = String_make(NULL, name1);
	event->name2 = String_make(NULL, name2);
	
	from.tm_year = GetPrivateProfileInt(section_name, "from_year", 0, config_file_name);
	from.tm_mon = GetPrivateProfileInt(section_name, "from_month", 0, config_file_name);
	from.tm_mday = GetPrivateProfileInt(section_name, "from_day", 0, config_file_name);
	from.tm_hour = GetPrivateProfileInt(section_name, "from_hour", 0, config_file_name);
	from.tm_min = GetPrivateProfileInt(section_name, "from_minute", 0, config_file_name);
	from.tm_isdst = 0;
	from.tm_year -= 1900;
	from.tm_mon -= 1;
	from.tm_sec = 0;
	event->from = mktime(&from);
	
	to.tm_year = GetPrivateProfileInt(section_name, "to_year", 0, config_file_name);
	to.tm_mon = GetPrivateProfileInt(section_name, "to_month", 0, config_file_name);
	to.tm_mday = GetPrivateProfileInt(section_name, "to_day", 0, config_file_name);
	to.tm_hour = GetPrivateProfileInt(section_name, "to_hour", 0, config_file_name);
	to.tm_min = GetPrivateProfileInt(section_name, "to_minute", 0, config_file_name);
	to.tm_isdst = 0;
	to.tm_year -= 1900;
	to.tm_mon -= 1;
	to.tm_sec = 0;
	event->to = mktime(&to);
	
	if(event->from == (time_t)-1L || event->to == (time_t)-1L) {
		event->to = 0L;
		event->from = 0L;
	}
}

/* �Ō�ɔԕ���u�� */
/* ���N�Ɨ��N�́A������񂲐��a�L�O�����j���Ƃ��΁A�ǂ������Ɉ����|���邾�낤 */
static void add_kaede_birthday(void) {
	time_t date_aux;
	struct tm from, to;
	
	date_aux = time(NULL);
	from = *localtime(&date_aux);
	
	from.tm_mon = 11 - 1;
	from.tm_mday = 15;
	from.tm_hour = 0;
	from.tm_min = 0;
	
	to = from;
	to.tm_mday = 16;
	
	st_events[st_event_count].name1 = String_make(NULL, "�������̒a����");
	st_events[st_event_count].name2 = String_make(NULL, "���ؕ�����A��a�������߂łƂ�!");
	st_events[st_event_count].from = mktime(&from);
	st_events[st_event_count].to = mktime(&to);
	
	from.tm_year += 1;
	to.tm_year += 1;
	
	st_events[st_event_count+1].name1 = String_make(NULL, "�������̒a����");
	st_events[st_event_count+1].name2 = String_make(NULL, "���ؕ�����A��a�������߂łƂ�!");
	st_events[st_event_count+1].from = mktime(&from);
	st_events[st_event_count+1].to = mktime(&to);
	
	st_event_count += 2;
}

void Events_time_bomb_text(char *text, time_t now) {
	int i;
	
	Debug_assert(st_is_initialized);
	
	for(i = 0; i < st_event_count; i++) {
		/* �ԕ���u���Ă���̂ŁA�K���q�b�g���� */
		if(now < st_events[i].from) {
			time_t diff;
			diff = st_events[i].from - time(NULL);
			sprintf(text, "%s�܂ŁA����%d����%.2d:%.2d:%.2d", st_events[i].name1,
				diff / (60 * 60 * 24), (diff / (60 * 60)) % 24, (diff / 60) % 60, diff % 60);
			return;
		} else if(now<st_events[i].to) {
			strcpy(text, st_events[i].name2);
			return;
		}
	}
}

static int event_cmp(const void *p1, const void *p2) {
	Event *event1 = (Event*)p1;
	Event *event2 = (Event*)p2;
	
	if(event1->from == event2->from) {
		return 0;
	} else if(event1->from < event2->from) {
		return -1;
	} else {
		return 1;
	}
}

void Events_initialize(void) {
	int i;
	
	Debug_assert(!st_is_initialized);
	st_is_initialized = TRUE;
	
	st_event_count = GetPrivateProfileInt("Events", "event_count", 0, Config_file_name());
	st_events = Memory_malloc(sizeof(*st_events)*(st_event_count+2));
	for(i = 0; i < st_event_count; i++) {
		load_event(&st_events[i], i);
	}
	qsort(st_events, st_event_count, sizeof(*st_events), event_cmp);
	add_kaede_birthday();
}

void Events_finalize(void) {
	int i;
	
	Debug_assert(st_is_initialized);
	st_is_initialized = FALSE;
	
	for(i = 0; i < st_event_count; i++) {
		Memory_free(st_events[i].name1);
		Memory_free(st_events[i].name2);
	}
	Memory_free(st_events);
}

/* end of file */
