/*
 * file: statisticsDlg.c
 * purpose: �����̓��v�_�C�A���O
 */

#include <windows.h>
#include <commctrl.h>
#include <string.h>
#include <dbcsstr.h>
#include <stdio.h>
#include "memory.h"
#include "debug.h"
#include "document.h"
#include "genreList.h"
#include "itemList.h"
#include "item.h"

#include "statisticsDlgP.h"

#define TOUCH(a) ((void)(a))

static const char *major_genre_name(GenreList genre_list, int major) {
	if(major == 0) {
		return "����";
	} else {
		int tag;

		tag = GenreList_tag(genre_list, GenreList_TOP, major);
		return GenreList_name(genre_list, tag);
	}
}

static const char *minor_genre_name(GenreList genre_list, int major, int minor) {
	if(major == 0 || minor == 0) {
		return "����";
	} else {
		int major_tag, minor_tag;

		major_tag = GenreList_tag(genre_list, GenreList_TOP, major);
		minor_tag = GenreList_tag(genre_list, major_tag, minor);
		return GenreList_name(genre_list, minor_tag);
	}
}

static const char *extra_genre_name(GenreList genre_list, int major, int minor, int extra) {
	if(major == 0 || minor == 0 || extra == 0) {
		return "����";
	} else {
		int major_tag, minor_tag, extra_tag;

		major_tag = GenreList_tag(genre_list, GenreList_TOP, major);
		minor_tag = GenreList_tag(genre_list, major_tag, minor);
		extra_tag = GenreList_tag(genre_list, minor_tag, extra);
		return GenreList_name(genre_list, extra_tag);
	}
}

static void on_init_dialog(StatisticsDlg dialog) {
	int day;
	GenreList genre_list = Document_genre_list(dialog->document);

	dialog->ctrls.tree = GetDlgItem(dialog->window, IDC_TREE);

	TreeView_DeleteAllItems(dialog->ctrls.tree);

	for(day = 0; day < 4; day++) {
		TVINSERTSTRUCT item;
		HTREEITEM day_node;
		int major, minor;
		char text[128];
		char temp_text[64];

		if(day == 0) {
			sprintf(text, "%s: ", "��������");
		} else {
			sprintf(text, "%d����: ", day);
		}
		sprintf(temp_text, "%d(���� %d)", dialog->statistics.count[day],
				dialog->statistics.auction_count[day]);
		strcat(text, temp_text);

		item.hInsertAfter = TVI_LAST;
		item.hParent = TVI_ROOT;
		item.u.item.mask = TVIF_TEXT;
		item.u.item.pszText = text;
		day_node = TreeView_InsertItem(dialog->ctrls.tree, &item);

		for(major = 0; major<dialog->statistics.jg_count; major++) {
			HTREEITEM major_node;

			sprintf(text, "%s: %d(���� %d)",
					major == 0 ? "����" : major_genre_name(genre_list, major),
					dialog->statistics.jg[major].count[day],
					dialog->statistics.jg[major].auction_count[day]);
			item.hInsertAfter = TVI_LAST;
			item.hParent = day_node;
			item.u.item.mask = TVIF_TEXT;
			item.u.item.pszText = text;
			major_node = TreeView_InsertItem(dialog->ctrls.tree, &item);

			for(minor = 0; minor < dialog->statistics.jg[major].ig_count; minor++) {
				sprintf(text, "%s: %d(���� %d)",
						major == 0 || minor == 0 ? "����" : minor_genre_name(genre_list, major, minor),
						dialog->statistics.jg[major].ig[minor].count[day],
						dialog->statistics.jg[major].ig[minor].auction_count[day]);
				item.hInsertAfter = TVI_LAST;
				item.hParent = major_node;
				item.u.item.mask = TVIF_TEXT;
				item.u.item.pszText = text;
				TreeView_InsertItem(dialog->ctrls.tree, &item);
			}
		}
	}

	SetFocus(dialog->ctrls.tree);
}

static void on_command(StatisticsDlg dialog, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDOK:
		EndDialog(dialog->window, IDOK);
		break;
	case IDCANCEL:
		EndDialog(dialog->window, IDCANCEL);
		break;
	}
	TOUCH(notify_code);
	TOUCH(ctrl_window);
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	StatisticsDlg dialog;

	if(message == WM_INITDIALOG) {
		dialog = (StatisticsDlg)long_param;
		SetWindowLong(dialog_window, DWL_USER, (LONG)dialog);
		dialog->window = dialog_window;
	}
	dialog = (StatisticsDlg)GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_INITDIALOG:
		on_init_dialog(dialog);
		break;
	case WM_COMMAND:
		on_command(dialog, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

StatisticsDlg_Boolean StatisticsDlg_dialogue(StatisticsDlg dialog, HWND parent_window) {
	int return_value;
	HINSTANCE instance = (HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE);

	Debug_assert(Memory_is_on_heap(dialog));

	return_value = DialogBoxParam(instance, MAKEINTRESOURCE(IDD_STATISTICS), parent_window, dialog_proc, (LONG)dialog);

	if(return_value == IDOK) {
		return StatisticsDlg_TRUE;
	} else {
		return StatisticsDlg_FALSE;
	}
}

static void statistics_aux(int id, Item item, void *param) {
	Statistics *statistics = (Statistics*)param;

	statistics->jg[Item_major_genre(item)].ig[Item_minor_genre(item)].count[Item_scheduled_date(item)] += 1;
	statistics->jg[Item_major_genre(item)].count[Item_scheduled_date(item)] += 1;
	statistics->count[Item_scheduled_date(item)] += 1;
	if(Item_is_by_auction(item)) {
		statistics->jg[Item_major_genre(item)].ig[Item_minor_genre(item)].auction_count[Item_scheduled_date(item)] += 1;
		statistics->jg[Item_major_genre(item)].auction_count[Item_scheduled_date(item)] += 1;
		statistics->auction_count[Item_scheduled_date(item)] += 1;
	}
	TOUCH(id);
}

static void do_statistics(StatisticsDlg dialog, Document document) {
	int major, day;
	GenreList genre_list;

	genre_list = Document_genre_list(document);
	dialog->statistics.jg = Memory_malloc(sizeof(*dialog->statistics.jg) * (GenreList_count(genre_list, GenreList_TOP) + 1));
	dialog->statistics.jg_count = GenreList_count(genre_list, GenreList_TOP) + 1;
	dialog->statistics.jg[0].ig = Memory_malloc(sizeof(*dialog->statistics.jg[0].ig) * 1);
	dialog->statistics.jg[0].ig_count = 1;
	for(day = 0; day < 4; day++) {
		dialog->statistics.jg[0].ig[0].count[day] = 0;
		dialog->statistics.jg[0].ig[0].auction_count[day] = 0;
		dialog->statistics.jg[0].count[day] = 0;
		dialog->statistics.jg[0].auction_count[day] = 0;
		dialog->statistics.count[day] = 0;
		dialog->statistics.auction_count[day] = 0;
	}

	for(major = 1; major<=GenreList_count(genre_list, GenreList_TOP); major++) {
		int tag;
		int minor;
		int day;

		tag = GenreList_tag(genre_list, GenreList_TOP, major);
		dialog->statistics.jg[major].ig = Memory_malloc(sizeof(*dialog->statistics.jg[major].ig) * (GenreList_count(genre_list, tag) + 1));
		dialog->statistics.jg[major].ig_count = GenreList_count(genre_list, tag) + 1;
		for(day = 0; day < 4; day++) {
			dialog->statistics.jg[major].ig[0].count[day] = 0;
			dialog->statistics.jg[major].ig[0].auction_count[day] = 0;
			dialog->statistics.jg[major].count[day] = 0;
			dialog->statistics.jg[major].auction_count[day] = 0;
		}
		for(minor = 0; minor <= GenreList_count(genre_list, tag); minor++) {
			int day;

			for(day = 0; day < 4; day++) {
				dialog->statistics.jg[major].ig[minor].count[day] = 0;
				dialog->statistics.jg[major].ig[minor].auction_count[day] = 0;
			}
		}
	}

	ItemList_enum(Document_item_list(document), statistics_aux, &dialog->statistics);
}

StatisticsDlg StatisticsDlg_create(Document document) {
	StatisticsDlg dialog;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->document = document;

	do_statistics(dialog, document);

	return dialog;
}

void StatisticsDlg_destroy(StatisticsDlg dialog) {
	GenreList genre_list;
	int major;

	Debug_assert(Memory_is_on_heap(dialog));
	for(major = 0; major < dialog->statistics.jg_count; major++) {
		Memory_free(dialog->statistics.jg[major].ig);
	}
	Memory_free(dialog->statistics.jg);

	Memory_free(dialog);
}

/* end of file */
