/*
 * file: item.h
 * purpose: public header file for Item
 */

#ifndef _PUBLIC_ITEM_H_INCLUDED
#define _PUBLIC_ITEM_H_INCLUDED

#include <time.h>
#include "documentType.h"

#include "itemType.h"

#ifdef DEBUG
#define Item_p(item) Item_p_func(item)
#else
#define Item_p(item) ((void)0)
#endif


typedef enum {
	Item_TRUE = 1,
	Item_FALSE = 0
} Item_Boolean;

typedef enum {
	Item_STUDENT,
	Item_OB,
	Item_TEACHER,
	Item_LEGACY,
	Item_DONATION
} Item_SellerType;


extern int Item_seller_id(ConstItem item);
extern void Item_set_seller_id(Item item, int seller_id);
extern const char *Item_name(ConstItem item);
extern void Item_set_name(Item item, const char *name);
extern const char *Item_comment(ConstItem item);
extern void Item_set_comment(Item item, const char * comment);
extern int Item_list_price(ConstItem item);
extern void Item_set_list_price(Item item, int list_price);
extern int Item_real_price(ConstItem item);
extern void Item_set_real_price(Item item, int real_price);
extern Item_Boolean Item_is_sold(ConstItem item);
extern void Item_set_is_sold(Item item, Item_Boolean is_sold);
extern Item_Boolean Item_is_returned(ConstItem item);
extern void Item_set_is_returned(Item item, Item_Boolean is_returned);
extern Item_Boolean Item_is_to_be_returned(ConstItem item);
extern void Item_set_is_to_be_returned(Item item, Item_Boolean is_to_be_returned);
extern Item_Boolean Item_is_to_be_discounted(ConstItem item);
extern void Item_set_is_to_be_discounted(Item item, Item_Boolean is_to_be_discounted);
extern int Item_scheduled_date(ConstItem item);
extern void Item_set_scheduled_date(Item item, int scheduled_date);
extern Item_Boolean Item_is_by_auction(ConstItem item);
extern void Item_set_is_by_auction(Item item, Item_Boolean is_by_auction);
extern time_t Item_receipt_time(ConstItem item);
extern void Item_set_receipt_time(Item item, time_t receipt_time);
extern time_t Item_sold_time(ConstItem item);
extern void Item_set_sold_time(Item item, time_t sold_time);
extern int Item_refund_rate(ConstItem item);
extern void Item_set_refund_rate(Item item, int refund_rate);
extern int Item_major_genre(ConstItem item);
extern void Item_set_major_genre(Item item, int major_genre);
extern int Item_minor_genre(ConstItem item);
extern void Item_set_minor_genre(Item item, int minor_genre);
extern int Item_extra_genre(ConstItem item);
extern void Item_set_extra_genre(Item item, int extra_genre);
extern int Item_shape(ConstItem item);
extern void Item_set_shape(Item item, int shape);
extern Item Item_create(void);
extern void Item_destroy(Item item);
extern void Item_p_func(ConstItem item);

#endif /* _PUBLIC_ITEM_H_INCLUDED */
/* end of file */
