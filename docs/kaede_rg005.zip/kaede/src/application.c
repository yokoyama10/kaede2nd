/*
 * file: application.c
 * purpose: �u���v�̖��O
 */

#include <windows.h>
#include <string.h>
#include <dbcsstr.h>

static char st_name[128];

void Application_set_name(const char * name) {
	strcpy(st_name, name);
}

const char * Application_name(void) {
	return st_name;
}

/* end of file */
