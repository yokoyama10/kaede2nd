/*
 * file: disk_load.c
 * purpose: .kae�t�@�C����load
 */

#include <string.h>
#include <dbcsstr.h>
#include "debug.h"
#include "seqFile.h"
#include "document.h"
#include "itemList.h"
#include "item.h"
#include "vipList.h"
#include "genreList.h"
#include "shapeList.h"

#include "diskP.h"

static Boolean read_header_text(SeqFile file) {
	int i;

	for(i = 0; i < (int)strlen(HEADER_TEXT); i++) {
		int ch;
		ch = SeqFile_read_S8b(file);
		if(ch!=HEADER_TEXT[i]) {
			return FALSE;
		}
	}

	if(SeqFile_is_error(file)) {
		return FALSE;
	} else {
		return TRUE;
	}
}

static int read_version(SeqFile file) {
	return SeqFile_read_S32b(file);
}

static int read_file_version(SeqFile file) {
	return SeqFile_read_S32b(file);
}

static Boolean read_crc(SeqFile file) {
	SeqFile_U32b real_crc, wrote_crc;

	real_crc = SeqFile_crc(file);
	wrote_crc = SeqFile_read_U32b(file);

	if(SeqFile_is_error(file) || real_crc!=wrote_crc) {
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_item(SeqFile file, int * id, Item item) {
	char text[256];

	*id = SeqFile_read_S32b(file);

	Item_set_seller_id(item, SeqFile_read_S32b(file));

	SeqFile_read_string(file, text, sizeof(text));
	Item_set_name(item, text);
	SeqFile_read_string(file, text, sizeof(text));
	Item_set_comment(item, text);

	Item_set_list_price(item, SeqFile_read_S32b(file));
	Item_set_real_price(item, SeqFile_read_S32b(file));

	Item_set_major_genre(item, SeqFile_read_S16b(file));
	Item_set_minor_genre(item, SeqFile_read_S16b(file));
	Item_set_extra_genre(item, SeqFile_read_S16b(file));
	Item_set_shape(item, SeqFile_read_S16b(file));

	Item_set_is_sold(item, SeqFile_read_S8b(file));
	Item_set_is_returned(item, SeqFile_read_S8b(file));
	Item_set_is_to_be_returned(item, SeqFile_read_S8b(file));
	Item_set_is_to_be_discounted(item, SeqFile_read_S8b(file));

	Item_set_receipt_time(item, SeqFile_read_U32b(file));
	Item_set_sold_time(item, (time_t) SeqFile_read_U32b(file));

	Item_set_scheduled_date(item, SeqFile_read_S8b(file));
	Item_set_is_by_auction(item, SeqFile_read_S8b(file));

	Item_set_refund_rate(item, SeqFile_read_S32b(file));

	if(SeqFile_is_error(file)) {
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_item_list(SeqFile file, ItemList item_list, Disk_ErrorType * error_type) {
	int i, size;
	Item item;

	size = SeqFile_read_S32b(file);
	if(size < 0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}

	item = Item_create();

	for(i = 0; i < size; i++) {
		int id;

		if(!read_item(file, &id, item)) {
			*error_type = Disk_DATA_ERROR;
			Item_destroy(item);
			return FALSE;
		} else {
			ItemList_set(item_list, id, item);
		}
	}

	Item_destroy(item);

	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_vip_list(SeqFile file, VipList vip_list, Disk_ErrorType * error_type) {
	int i, size;

	size = SeqFile_read_S32b(file);
	if(size < 0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}

	for(i = 0; i < size; i++) {
		char name[256];

		SeqFile_read_string(file, name, sizeof(name));
		VipList_set(vip_list, VipList_ID_NEW, name);
	}

	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_genre_list(SeqFile file, GenreList genre_list, Disk_ErrorType *error_type) {
	int i;
	int size;
	int tag, parent, order;
	char name[256];

	size = SeqFile_read_S32b(file);
	if(size < 0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}

	for(i = 0; i < size; i++) {
		tag = SeqFile_read_S32b(file);
		parent = SeqFile_read_S32b(file);
		order = SeqFile_read_S32b(file);
		SeqFile_read_string(file, name, sizeof(name));
		GenreList_insert(genre_list, tag, parent, order, name);
	}

	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_shape_list(SeqFile file, ShapeList shape_list, Disk_ErrorType * error_type) {
	int i, size;

	size = SeqFile_read_S32b(file);
	if(size<0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}

	for(i=0; i<size; i++) {
		char name[256];

		SeqFile_read_string(file, name, sizeof(name));
		ShapeList_set(shape_list, ShapeList_ID_NEW, name);
	}

	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_body(SeqFile file, Document document, Disk_ErrorType *error_type) {
	/* read obs */
	if(!read_vip_list(file, Document_ob_list(document), error_type)) {
		return FALSE;
	}

	/* read teachers */
	if(!read_vip_list(file, Document_teacher_list(document), error_type)) {
		return FALSE;
	}

	/* read genres */
	if(!read_genre_list(file, Document_genre_list(document), error_type)) {
		return FALSE;
	}

	/* read shapes */
	if(!read_shape_list(file, Document_shape_list(document), error_type)) {
		return FALSE;
	}

	/* read items */
	if(!read_item_list(file, Document_item_list(document), error_type)) {
		return FALSE;
	}

	/* read cash */
	Document_set_cash(document, SeqFile_read_S32b(file));

	/* read refund_rate */
	Document_set_refund_rate(document, SeqFile_read_S32b(file));


	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_old_file(SeqFile file, int file_version, Document document, Disk_ErrorType * error_type) {
	switch(file_version) {
	case 1001:
		return dISK_read_1001_file(file, document, error_type);
	case 1002:
		return dISK_read_1002_file(file, document, error_type);
	default:
		*error_type = Disk_TOO_OLD_FILE;
		return FALSE;
	}
}

Document Disk_load(const char * path, Disk_ErrorType * error_type) {
	SeqFile file = NULL;
	Document document = NULL;
	int version;
	int file_version;
	int temp;

	file = SeqFile_create(path, SeqFile_READ);
	if(file==NULL) {
		*error_type = Disk_NO_FILE;
		goto error;
	}

	if(!read_header_text(file)) {
		*error_type = Disk_UNKNOWN_FILE;
		goto error;
	}

	document = Document_create();

	temp = SeqFile_read_S32b(file);
	if(temp<=20) {
		/* build 20 �ȑO�́Aversion,file_version�̏� */
		version = temp;
		file_version = SeqFile_read_S32b(file);
	} else {
		version = SeqFile_read_S32b(file);
		file_version = temp;
	}

	if(file_version < CURRENT_FILE_VERSION) {
		if(!read_old_file(file, file_version, document, error_type)) {
			goto error;
		}
	} else if(file_version > CURRENT_FILE_VERSION) {
		*error_type = Disk_GET_NEW_VERSION;
		goto error;
	} else {
		if(!read_body(file, document, error_type)) {
			goto error;
		}
	}

	if(!read_crc(file)) {
		*error_type = Disk_CRC_UNMATCH;
		goto error;
	}

	SeqFile_destroy(file);
	*error_type = Disk_SUCCESS;

	return document;

error:
	if(file!=NULL) {
		SeqFile_destroy(file);
	}
	if(document!=NULL) {
		Document_destroy(document);
	}
	return NULL;
}

/* end of file */
