/*
 * file: dictionaryType.h
 * purpose: public header file for Dictionary
 */

#ifndef _PUBLIC_DICTIONARYTYPE_H_INCLUDED
#define _PUBLIC_DICTIONARYTYPE_H_INCLUDED

typedef struct tagDictionary *Dictionary;

#endif /* _PUBLIC_DICTIONARYTYPE_H_INCLUDED */

/* end of file */
