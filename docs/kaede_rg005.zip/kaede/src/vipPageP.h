/*
 * file: vipPageP.h
 * purpose: private header file for VipPage
 */

#ifndef _PRIVATE_VIPPAGEP_H_INCLUDED
#define _PRIVATE_VIPPAGEP_H_INCLUDED

#define IDD_VIP_PAGE 1009

#define IDC_NAME 101
#define IDC_VIPS 102
#define IDC_APPEND 103
#define IDC_VIPS_TITLE 104

#undef TRUE
#undef FALSE
#define TRUE VipPage_TRUE
#define FALSE VipPage_FALSE

#include "vipPage.h"

typedef VipPage_Boolean Boolean;

struct tagVipPage {
	HWND window;
	char *title;
	VipList vip_list;
	int selected_item;
	Boolean is_name_changed;
	Boolean is_applied;
	struct {
		HWND vips;
	} ctrls;
};

#endif /* _PRIVATE_VIPPAGEP_H_INCLUDED */
/* end of file */
