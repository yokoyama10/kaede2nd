/*
 * file: itemType.h
 * purpose: public header file for Item, declaring Item
 */

#ifndef _PUBLIC_ITEMTYPE_H_INCLUDED
#define _PUBLIC_ITEMTYPE_H_INCLUDED

typedef struct tagItem *Item;
typedef const struct tagItem *ConstItem;

#endif /* _PUBLIC_ITEMTYPE_H_INCLUDED */
/* end of file */
