/*
 * file: shapeListP.h
 * purpose: private header file for ShapeList
 */

#ifndef _PRIVATE_SHAPELISTP_H_INCLUDED
#define _PRIVATE_SHAPELISTP_H_INCLUDED

#include "shapeList.h"

struct tagShapeList {
	char **names;
	int count;
};

#endif /* _PRIVATE_SHAPELISTP_H_INCLUDED */

/* end of file */
