/*
 * file: document.c
 * purpose: ���̃f�[�^�\���B�w�ǎd�������Ȃ��B
 */

#include "debug.h"
#include "memory.h"
#include "vipList.h"
#include "itemList.h"
#include "genreList.h"
#include "shapeList.h"

#include "documentP.h"

ItemList Document_item_list(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	return document->item_list;
}

VipList Document_teacher_list(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	return document->teacher_list;
}

void Document_set_teacher_list(Document document, VipList teacher_list) {
	Debug_assert(Memory_is_on_heap(document));
	Debug_assert(teacher_list != NULL);

	VipList_destroy(document->teacher_list);
	document->teacher_list = VipList_clone(teacher_list);
}

VipList Document_ob_list(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	return document->ob_list;
}

void Document_set_ob_list(Document document, VipList ob_list) {
	Debug_assert(Memory_is_on_heap(document));

	VipList_destroy(document->ob_list);
	document->ob_list = VipList_clone(ob_list);
}

GenreList Document_genre_list(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	return document->genre_list;
}

void Document_set_genre_list(Document document, GenreList genre_list) {
	Debug_assert(Memory_is_on_heap(document));

	GenreList_destroy(document->genre_list);
	document->genre_list = GenreList_clone(genre_list);
}

ShapeList Document_shape_list(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	return document->shape_list;
}

void Document_set_shape_list(Document document, ShapeList shape_list) {
	Debug_assert(Memory_is_on_heap(document));

	ShapeList_destroy(document->shape_list);
	document->shape_list = ShapeList_clone(shape_list);
}

int Document_cash(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	return document->cash;
}

void Document_set_cash(Document document, int cash) {
	Debug_assert(Memory_is_on_heap(document));

	document->cash = cash;
}

int Document_refund_rate(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	return document->refund_rate;
}

void Document_set_refund_rate(Document document, int refund_rate) {
	Debug_assert(Memory_is_on_heap(document));
	Debug_assert(0 <= refund_rate && refund_rate <= 100);

	if(0 <=refund_rate && refund_rate <= 100) {
		document->refund_rate = refund_rate;
	}
}

Document Document_create(void) {
	Document document;

	document = Memory_malloc(sizeof(*document));

	document->item_list = ItemList_create();
	document->teacher_list = VipList_create();
	document->ob_list = VipList_create();
	document->genre_list = GenreList_create();
	document->shape_list = ShapeList_create();
	document->cash = 0;
	document->refund_rate = 100;

	return document;
}

void Document_destroy(Document document) {
	Debug_assert(Memory_is_on_heap(document));

	ShapeList_destroy(document->shape_list);
	GenreList_destroy(document->genre_list);
	VipList_destroy(document->ob_list);
	VipList_destroy(document->teacher_list);
	ItemList_destroy(document->item_list);

	Memory_free(document);
}

/* end of file */
