/*
 * file: base_export.c
 * purpose: csv�ɃG�N�X�|�[�g
 */

#include <stdio.h>
#include "document.h"
#include "shapeList.h"
#include "genreList.h"
#include "itemList.h"
#include "vipList.h"
#include "item.h"
#include "application.h"
#include "fileNameDlg.h"
#include "seller.h"

#include "baseP.h"

struct Export {
	FILE * file;
	Base base;
};


static void get_seller_name(Base base, char * text, ConstItem item) {
	int seller_id;
	
	seller_id = Item_seller_id(item);
	
	switch(Seller_type(seller_id)) {
	case Seller_STUDENT:
		if(Seller_grade(seller_id) <= 3) {
			/* ���V */
			sprintf(text, "%d�N%c�g %d��", Seller_grade(seller_id), Seller_class(seller_id) + 'A' - 1, Seller_number(seller_id));
		} else {
			/* ���Z�� */
			sprintf(text, "%d�N%d�g %d��", Seller_grade(seller_id) - 3, Seller_class(seller_id), Seller_number(seller_id));
		}
		break;
	case Seller_TEACHER:
		sprintf(text, "%s����", VipList_name(Document_teacher_list(base->document), Seller_vip_id(seller_id)));
		break;
	case Seller_OB:
		sprintf(text, "%s��", VipList_name(Document_ob_list(base->document), Seller_vip_id(seller_id)));
		break;
	case Seller_LEGACY:
		strcpy(text, "��Y");
		break;
	case Seller_DONATION:
		strcpy(text, "��t");
		break;
	}
}

static void export_aux(int id, Item item, void * param) {
	struct Export * export = (struct Export*) param;
	char seller_name[256];
	int shape;
	GenreList genre_list;
	
	genre_list = Document_genre_list(export->base->document);
	
	shape = Item_shape(item);
	
	get_seller_name(export->base, seller_name, item);
	
	fprintf(export->file, "%.5d,\"%s\",\"%s\",%d,%d,\"%s\",\"%s\",\"%s\",\"%s : %s : %s\",\"%s\",%d,\"%s\"\n",
		id, seller_name, Item_name(item), Item_list_price(item), Item_is_sold(item)?Item_real_price(item):0,
		Item_is_to_be_returned(item) ? "��" : "�s��",
		Item_is_to_be_discounted(item) ? "�@" : "�s�@",
		Item_is_sold(item) ? "����" : "����",
		GenreList_name(genre_list, Item_major_genre(item)),
		GenreList_name(genre_list, Item_minor_genre(item)),
		GenreList_name(genre_list, Item_extra_genre(item)),
		shape == 0 ? "����" : ShapeList_name(Document_shape_list(export->base->document), shape),
		Item_scheduled_date(item),
		Item_comment(item));
}

void bASE_on_export_csv(Base base) {
	struct Export export;
	FileNameDlg dialog;
	char extension[64];
	char type_name[128];
	
	LoadString(base->instance, IDS_CSV_EXTENSION, extension, sizeof(extension));
	LoadString(base->instance, IDS_CSV_TYPE_NAME, type_name, sizeof(type_name));
	dialog = FileNameDlg_create(NULL, extension, type_name, FileNameDlg_SAVE);
	if(FileNameDlg_dialogue(dialog, base->main_window)) {
		export.file = fopen(FileNameDlg_file_name(dialog), "w");
		if(export.file == NULL) {
			char message[256];
			
			LoadString(base->instance, IDS_NO_FILE, message, sizeof(message));
			MessageBox(base->main_window, Application_name(), message, MB_OK | MB_ICONWARNING);
			return;
		}
		export.base = base;
		fputs("id,�o�i��,���i��,�艿,���l,�Ԃ�?,�@��?,���ꂽ?,�W������,�`��,�����,�R�����g\n", export.file);
		ItemList_enum(Document_item_list(base->document), export_aux, &export);
		fclose(export.file);
	}
	FileNameDlg_destroy(dialog);
}

/* end of file */
