/*
 * file: import.c
 * purpose: ���̃t�@�C�����C���|�[�g
 */

#include "debug.h"
#include "document.h"
#include "genreList.h"
#include "shapeList.h"
#include "vipList.h"
#include "item.h"
#include "itemList.h"

#include "import.h"

typedef struct {
	ConstGenreList inner;
	ConstGenreList outer;
	Import_Boolean including;
} GenreIncluding;

static void genre_including_aux(int tag, void *param) {
	GenreIncluding *heke;

	heke = param;
	if(!GenreList_including(heke->outer, tag)) {
		heke->including = Import_FALSE;
	} else if(GenreList_parent(heke->outer, tag) != GenreList_parent(heke->inner, tag) ||
			GenreList_order(heke->outer, tag) != GenreList_order(heke->inner, tag)) {
		heke->including = Import_FALSE;
	}
}

static Import_Boolean genre_including(ConstGenreList outer, ConstGenreList inner) {
	GenreIncluding heke;

	heke.inner = inner;
	heke.outer = outer;
	heke.including = Import_TRUE;
	GenreList_enum_all(inner, genre_including_aux, &heke);
	return heke.including;
}

static Import_Boolean shape_including(ShapeList outer, ShapeList inner) {
	if(ShapeList_count(outer) >= ShapeList_count(inner)) {
		return Import_TRUE;
	} else {
		return Import_FALSE;
	}
}

static Import_Boolean vip_including(VipList outer, VipList inner) {
	if(VipList_count(outer) >= VipList_count(inner)) {
		return Import_TRUE;
	} else {
		return Import_FALSE;
	}
}

static void add_item(int id, Item item, void *param) {
	ItemList dest;

	dest = param;
	ItemList_set(dest, ItemList_ID_NEW, item);
}

Import_Boolean Import_import(Document dest, Document src) {
	if(!genre_including(Document_genre_list(dest), Document_genre_list(src)) ||
			!shape_including(Document_shape_list(dest), Document_shape_list(src)) ||
			!vip_including(Document_ob_list(dest), Document_ob_list(src)) ||
			!vip_including(Document_teacher_list(dest), Document_teacher_list(src))) {
		return Import_FALSE;
	}

	ItemList_enum(Document_item_list(src), add_item, Document_item_list(dest));
	return Import_TRUE;
}

/* end of file */
