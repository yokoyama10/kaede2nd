/*
 * file: base_proceeds.c
 * purpose: ���㍂�̌v�Z
 */

#include <time.h>
#include "itemList.h"
#include "item.h"
#include "document.h"

#include "baseP.h"

void bASE_modify_proceeds(Base base, int id, ConstItem new_item) {
	ConstItem org_item;
	int cash;

	if(id == ItemList_ID_NEW) {
		/* �V�K���i���͔͂̔����[�h�ł͂��肦�Ȃ� */
		return;
	}

	org_item = ItemList_item(Document_item_list(base->document), id);
	if(!Item_is_sold(org_item) && Item_is_sold(new_item)) {
		base->total_sold_count += 1;
		base->todays_sold_count += 1;
		base->total_proceeds += Item_real_price(new_item);
		base->todays_proceeds += Item_real_price(new_item);

		Document_set_cash(base->document,
				Document_cash(base->document) + Item_real_price(new_item));
	} else if(Item_is_sold(org_item) && !Item_is_sold(new_item)) {
		base->total_sold_count -= 1;
		base->todays_sold_count -= 1;
		base->total_proceeds -= Item_real_price(org_item);
		base->todays_proceeds -= Item_real_price(org_item);

		Document_set_cash(base->document,
				Document_cash(base->document) - Item_real_price(org_item));
	} else if(Item_is_sold(org_item) && Item_is_sold(new_item)) {
		int cash;

		base->total_proceeds += Item_real_price(new_item) - Item_real_price(org_item);
		base->todays_proceeds += Item_real_price(new_item) - Item_real_price(org_item);

		cash = Document_cash(base->document);
		cash += Item_real_price(new_item) - Item_real_price(org_item);
		Document_set_cash(base->document, cash);
	}
}

typedef struct {
	int total_proceeds;
	int total_sold_count;
	int todays_proceeds;
	int todays_sold_count;
	struct tm today;
} Proceeds;

static void calc_proceeds_aux(int id, Item item, void * param) {
	Proceeds *proceeds = (Proceeds*) param;

	if(Item_is_sold(item)) {
		time_t sold_time_aux;
		struct tm sold_time;

		proceeds->total_sold_count += 1;
		proceeds->total_proceeds += Item_real_price(item);

		sold_time_aux = Item_sold_time(item);
		sold_time = *localtime(&sold_time_aux);

		if(proceeds->today.tm_year == sold_time.tm_year &&
				proceeds->today.tm_mon == sold_time.tm_mon &&
				proceeds->today.tm_mday == sold_time.tm_mday) {
			proceeds->todays_sold_count += 1;
			proceeds->todays_proceeds += Item_real_price(item);
		}
	}
}

void bASE_calc_proceeds(Base base) {
	Proceeds proceeds;
	time_t now_aux;
	struct tm now;

	proceeds.total_proceeds = 0;
	proceeds.total_sold_count = 0;
	proceeds.todays_proceeds = 0;
	proceeds.todays_sold_count = 0;

	now_aux = time(NULL);
	proceeds.today = *localtime(&now_aux);

	ItemList_enum(Document_item_list(base->document), calc_proceeds_aux, &proceeds);

	base->total_proceeds = proceeds.total_proceeds;
	base->total_sold_count = proceeds.total_sold_count;
	base->todays_proceeds = proceeds.todays_proceeds;
	base->todays_sold_count = proceeds.todays_sold_count;
}

/* end of file */
