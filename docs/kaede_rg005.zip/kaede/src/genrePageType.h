/*
 * file: genrePageType.h
 * purpose: public header file for GenrePage
 */

#ifndef _PUBLIC_GENREPAGETYPE_H_INCLUDED
#define _PUBLIC_GENREPAGETYPE_H_INCLUDED

typedef struct tagGenrePage *GenrePage;

#endif /* _PUBLIC_GENREPAGETYPE_H_INCLUDED */

/* end of file */
