/************************
  file: seller.c
  purpose: ����l
 ************************/

#include "debug.h"

#include "seller.h"

/* ****  ????  ++++  0000  &&&&  &&&&  &&&&  &&&& */
/* type  grade class ***   number                 */
/* type                    vip_id */

int Seller_make_student_id(int grade, int class, int number) {
	Debug_assert(1<=grade && grade<=6);
	Debug_assert(1<=class && class<=0xf);
	Debug_assert(1<=number && number<=0xffff);
	
	return ((int)Seller_STUDENT<<28) | (grade<<24) | (class<<20) | number;
}

int Seller_make_teacher_id(int vip_id) {
	Debug_assert(vip_id>=0);
	
	return ((int)Seller_TEACHER<<28) | vip_id;
}

int Seller_make_ob_id(int vip_id) {
	Debug_assert(vip_id>=0);
	
	return ((int)Seller_OB<<28) | vip_id;
}

int Seller_make_legacy_id(void) {
	return (int)Seller_LEGACY<<28;
}

int Seller_make_donation_id(void) {
	return (int)Seller_DONATION<<28;
}

Seller_Type Seller_type(int id) {
	return (Seller_Type)((id&0xf0000000)>>28);
}

int Seller_grade(int id) {
	Debug_assert((Seller_Type)((id&0xf0000000)>>28) == Seller_STUDENT);
	
	return (id&0x0f000000)>>24;
}

int Seller_class(int id) {
	Debug_assert((Seller_Type)((id&0xf0000000)>>28) == Seller_STUDENT);
	
	return (id&0x00f00000)>>20;
}

int Seller_number(int id) {
	Debug_assert((Seller_Type)((id&0xf0000000)>>28) == Seller_STUDENT);
	
	return id&0x0000ffff;
}

int Seller_vip_id(int id) {
	Debug_assert((Seller_Type)((id&0xf0000000)>>28) == Seller_TEACHER ||
		(Seller_Type)((id&0xf0000000)>>28) == Seller_OB);
	return id&0x0000ffff;
}

/* end of file */