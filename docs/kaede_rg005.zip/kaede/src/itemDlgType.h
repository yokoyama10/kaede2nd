/*
 * file: itemDlgType.h
 * purpose public header file for ItemDlg
 */

#ifndef _PUBLIC_ITEMDLGTYPE_H_INCLUDED
#define _PUBLIC_ITEMDLGTYPE_H_INCLUDED

typedef struct tagItemDlg *ItemDlg;

#endif /* _PUBLIC_ITEMDLGTYPE_H_INCLUDED */
/* end of file */
