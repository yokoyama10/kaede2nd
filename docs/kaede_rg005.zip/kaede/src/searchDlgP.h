/*
 * file: searchDlgP.h
 * purpose: private header file for SearchDlg
 */

#ifndef _PRIVATE_SEARCHDLGP_H_INCLUDED
#define _PRIVATE_SEARCHDLGP_H_INCLUDED

#include <windows.h>
#include "string.h"

#include "searchDlg.h"

#define IDD_FIND_ITEM 1010

#define IDC_ITEM_NAME 101

struct tagSearchDlg {
	HWND window;
	char *item_name;
};

#endif /* _PRIVATE_SEARCHDLGP_H_INCLUDED */

/* end of file */
