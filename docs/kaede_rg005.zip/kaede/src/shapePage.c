/*
 * file: ShapePage.c
 * purpose: �W�������ƌ`��̕ҏW�v���p�e�B�̌`��y�[�W
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <dbcsstr.h>
#include "application.h"
#include "shapeList.h"
#include "memory.h"
#include "debug.h"

#include "shapePageP.h"

#define TOUCH(a) ((void)(a))

static void display_shapes_list_aux(int id, const char *name, void *param) {
	ShapePage page = (ShapePage) param;
	char text[256];
	char buf[16];

	sprintf(text, "%s: %s", ShapeList_id_text(page->shape_list, id, buf), name);
	SendMessage(page->ctrls.shapes, LB_ADDSTRING, 0, (LPARAM) text);
}

static void display_shapes_list(ShapePage page) {
	int i;

	SendMessage(page->ctrls.shapes, LB_RESETCONTENT, 0, 0);
	ShapeList_enum(page->shape_list, display_shapes_list_aux, page);
}

static void display_shape_name(ShapePage page) {
	SetDlgItemText(page->window, IDC_SHAPE_NAME, ShapeList_name(page->shape_list, page->selected_item + 1));
}

static void select_item(ShapePage page) {
	if(page->selected_item >= 0) {
		SendMessage(page->ctrls.shapes, LB_SETCURSEL, page->selected_item, 0);
	}
}

static void init_dialog(ShapePage page) {
	page->ctrls.shapes = GetDlgItem(page->window, IDC_SHAPES_LIST);

	display_shapes_list(page);
	if(ShapeList_count(page->shape_list) >= 1) {
		page->selected_item = 0;
		select_item(page);
		display_shape_name(page);
	}
}

static void set_shape_name(ShapePage page) {
	char text[256];

	if(ShapeList_count(page->shape_list) > 0 && page->is_shape_name_changed) {
		GetDlgItemText(page->window, IDC_SHAPE_NAME, text, sizeof(text) - 1);
		if(strlen(text) != 0) {
			ShapeList_set(page->shape_list, page->selected_item + 1, text);
			display_shapes_list(page);
		}
	}
	page->is_shape_name_changed = FALSE;
}

static void on_shapes_list_sel_change(ShapePage page) {
	int index;

	index = SendMessage(page->ctrls.shapes, LB_GETCURSEL, 0, 0);
	set_shape_name(page);
	SendMessage(page->ctrls.shapes, LB_SETCURSEL, index, 0);
	page->selected_item = index;
	display_shape_name(page);
}

static void on_append_shape(ShapePage page) {
	set_shape_name(page);
	/* !! */
	ShapeList_set(page->shape_list, ShapeList_ID_NEW, "�V�����`��");
	SendMessage(page->ctrls.shapes, LB_SETCURSEL, ShapeList_count(page->shape_list) - 1, 0);
	page->selected_item = ShapeList_count(page->shape_list) - 1;
	display_shapes_list(page);
	display_shape_name(page);
	select_item(page);
}

static void on_clear_all(ShapePage page) {
	HINSTANCE instance;
	char message[128];

	instance = (HINSTANCE) GetWindowLong(page->window, GWL_HINSTANCE);
	LoadString(instance, IDS_ASK_CLEAR, message, sizeof(message));
	if(MessageBox(page->window, message, Application_name(), MB_YESNO | MB_ICONQUESTION)==IDYES &&
			MessageBox(page->window, message, Application_name(), MB_YESNO | MB_ICONQUESTION) == IDYES) {
		int i;

		SendMessage(page->ctrls.shapes, LB_RESETCONTENT, 0, 0);
		ShapeList_destroy(page->shape_list);
		page->shape_list = ShapeList_create();
		page->is_cleared = TRUE;
		page->selected_item = -1;
	}
}

static BOOL on_command(ShapePage page, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDC_SHAPE_NAME:
		if(notify_code == EN_UPDATE && page->selected_item >= 0) {
			page->is_shape_name_changed = TRUE;
		}
		break;
	case IDC_SHAPES_LIST:
		if(notify_code == LBN_SELCHANGE) {
			on_shapes_list_sel_change(page);
		}
		break;
	case IDC_CLEAR_ALL_SHAPE:
		on_clear_all(page);
		break;
	case IDC_APPEND_SHAPE:
		on_append_shape(page);
		break;
	}
	TOUCH(ctrl_window);
	TOUCH(notify_code);
	return (BOOL) TRUE;
}

static void on_set_active(ShapePage page) {
	select_item(page);
}

static void on_kill_active(ShapePage page) {
	if(page->selected_item >= 0) {
		set_shape_name(page);
		display_shape_name(page);
	}
}

static BOOL on_notify(ShapePage page, int id, LPNMHDR notify_info) {
	switch(notify_info->code) {
	case PSN_SETACTIVE:
		on_set_active(page);
		break;
	case PSN_KILLACTIVE:
		on_kill_active(page);
		break;
	case PSN_APPLY:
		on_kill_active(page);
		page->is_applied = TRUE;
		break;
	}
	return (BOOL)FALSE;
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	ShapePage page;
	if(message == WM_INITDIALOG) {
		PROPSHEETPAGE *page_info;
		page_info = (PROPSHEETPAGE *)long_param;
		page = (ShapePage)page_info->lParam;
		SetWindowLong(dialog_window, DWL_USER, (LONG)page);
		page->window = dialog_window;
	}
	page = (ShapePage)GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_NOTIFY:
		on_notify(page, (int)word_param, (LPNMHDR)long_param);
		break;
	case WM_INITDIALOG:
		init_dialog(page);
		break;
	case WM_COMMAND:
		return on_command(page, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
	default:
		return (BOOL) FALSE;
	}
	return (BOOL) TRUE;
}

HPROPSHEETPAGE ShapePage_create_page(ShapePage page, HINSTANCE instance) {
	PROPSHEETPAGE page_info;
	Debug_assert(Memory_is_on_heap(page));

	page_info.dwSize = sizeof(page_info);
	page_info.dwFlags = PSP_DEFAULT;
	page_info.hInstance = instance;
	page_info.u.pszTemplate = MAKEINTRESOURCE(IDD_SHAPE_PAGE);
	page_info.pfnDlgProc = (DLGPROC)dialog_proc;
	page_info.lParam = (LPARAM) page;
	return CreatePropertySheetPage(&page_info);
}

ShapePage_Boolean ShapePage_is_cleared(ShapePage page) {
	Debug_assert(Memory_is_on_heap(page));

	return page->is_cleared;
}

ShapePage_Boolean ShapePage_is_applied(ShapePage page) {
	Debug_assert(Memory_is_on_heap(page));

	return page->is_applied;
}

ShapeList ShapePage_shape_list(ShapePage page) {
	Debug_assert(Memory_is_on_heap(page));

	return page->shape_list;
}

ShapePage ShapePage_create(ShapeList shape_list) {
	int i;
	ShapePage page;

	page = Memory_malloc(sizeof(*page));

	page->shape_list = ShapeList_clone(shape_list);
	page->is_shape_name_changed = FALSE;
	page->selected_item = -1;
	page->is_cleared = FALSE;
	page->is_applied = FALSE;
	return page;
}

void ShapePage_destroy(ShapePage page) {
	int i;

	Debug_assert(Memory_is_on_heap(page));

	ShapeList_destroy(page->shape_list);
	Memory_free(page);
}

/* end of file */
