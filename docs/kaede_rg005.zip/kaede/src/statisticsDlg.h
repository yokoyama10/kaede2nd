/*
 * file: statisticsDlg.h
 * purpose: public header file for StatisticsDlg
 */

#ifndef _PUBLIC_STATISTICSDLG_H_INCLUDED
#define _PUBLIC_STATISTICSDLG_H_INCLUDED

typedef struct tagStatisticsDlg *StatisticsDlg;

typedef enum {
	StatisticsDlg_TRUE = 1,
	StatisticsDlg_FALSE = 0
} StatisticsDlg_Boolean;

extern StatisticsDlg_Boolean StatisticsDlg_dialogue(StatisticsDlg dialog, HWND paren_window);
extern StatisticsDlg StatisticsDlg_create(Document document);
extern void StatisticsDlg_destroy(StatisticsDlg dialog);

#endif /* _PUBLIC_STATISTICSDLG_H_INCLUDED */

/* end of file */
