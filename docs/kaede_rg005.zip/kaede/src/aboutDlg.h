/*
 * file: aboutDlg.h
 * purpose: public header file for AboutDlg
 */

#ifndef _PUBLIC_ABOUTDLG_H_INCLUDED
#define _PUBLIC_ABOUTDLG_H_INCLUDED

#include <windows.h>

typedef struct tagAboutDlg * AboutDlg;

typedef enum {
	AboutDlg_TRUE = 1,
	AboutDlg_FALSE = 0
} AboutDlg_Boolean;

extern AboutDlg_Boolean AboutDlg_dialogue(AboutDlg dialog, HWND parent_window);
extern void AboutDlg_destroy(AboutDlg dialog);
extern AboutDlg AboutDlg_create(void);

#endif /* _PUBLIC_ABOUTDLG_H_INCLUDED */
/* end of file */
