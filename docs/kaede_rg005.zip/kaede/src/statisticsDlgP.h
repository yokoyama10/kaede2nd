/*
 * file: statisticsDlgP.h
 * purpose: private header file for StatisticsDlg
 */

#ifndef _PRIVATE_STATISTICSDLGP_H_INCLUDED
#define _PRIVATE_STATISTICSDLGP_H_INCLUDED

#include "documentType.h"

#include "statisticsDlg.h"

#define IDD_STATISTICS 1014
#define IDC_TREE 101

#undef TRUE
#undef FALSE
#define TRUE StatisticsDlg_TRUE
#define FALSE StatisticsDlg_FALSE

typedef StatisticsDlg_Boolean Boolean;

typedef struct {
	struct {
		struct {
			int count[4];
			int auction_count[4];
		} *ig;
		int count[4];
		int auction_count[4];
		int ig_count;
	} *jg;
	int count[4];
	int auction_count[4];
	int jg_count;
} Statistics;

struct tagStatisticsDlg {
	HWND window;
	Document document;
	struct {
		HWND tree;
	} ctrls;
	Statistics statistics;
};


#endif /* _PRIVATE_STATISTICSDLGP_H_INCLUDED */

/* end of file */
