/*
 * file: sellerMngPanel.c
 * purpose: �ԕi�A�ԋ����ׂ��l��\������悤�ȃ|�b�v�A�b�v�E�B���h�E
 */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "debug.h"
#include "memory.h"
#include "dictionary.h"
#include "seller.h"
#include "sellerList.h"
#include "document.h"
#include "vipList.h"
#include "base.h"

#include "sellerMngPanelP.h"

static SellerMngPanel_Boolean st_is_initialized = SellerMngPanel_FALSE;

static void get_text_seller(SellerMngPanel panel, char *text, int seller_id) {
	switch(Seller_type(seller_id)) {
	case Seller_STUDENT:
		if(Seller_grade(seller_id) <= 3) {
			/* ���V */
			sprintf(text, "%d�N%c�g %d��", Seller_grade(seller_id), Seller_class(seller_id) + 'A' - 1, Seller_number(seller_id));
		} else {
			/* ���Z�� */
			sprintf(text, "%d�N%d�g %d��", Seller_grade(seller_id) - 3, Seller_class(seller_id), Seller_number(seller_id));
		}
		break;
	case Seller_TEACHER:
		sprintf(text, "%s����", VipList_name(Document_teacher_list(panel->document), Seller_vip_id(seller_id)));
		break;
	case Seller_OB:
		sprintf(text, "%s��", VipList_name(Document_ob_list(panel->document), Seller_vip_id(seller_id)));
		break;
	}
}

static void on_get_display_info(SellerMngPanel panel, NMLVDISPINFO *display_info) {
	LVCOLUMN lv_column;
	static char text[256];
	int seller_id;

	seller_id = display_info->item.lParam;

	lv_column.mask = LVCF_SUBITEM;
	ListView_GetColumn(panel->list_window, display_info->item.iSubItem, &lv_column);

	switch(lv_column.iSubItem) {
	case 0:
		get_text_seller(panel, text, seller_id);
		break;
	case 1:
		sprintf(text, "%d", SellerList_refunder(panel->seller_list, seller_id));
		break;
	}
	display_info->item.pszText = text;
}

typedef struct {
	SellerMngPanel panel;
	int column_id;
} SortStruct;

static int CALLBACK compare_seller(LPARAM param_1, LPARAM param_2, LPARAM param_ext) {
	SortStruct *sort_struct = (SortStruct *)param_ext;
	int result;

	switch(sort_struct->column_id) {
	case 0:
		result = param_1 - param_2;
		break;
	case 1:
		result = SellerList_refunder(sort_struct->panel->seller_list, param_1) - SellerList_refunder(sort_struct->panel->seller_list, param_2);
		break;
	}
	return result;
}

static void sort_sellers(SellerMngPanel panel, int column_id) {
	SortStruct sort_struct;

	sort_struct.panel = panel;
	sort_struct.column_id = column_id;
	ListView_SortItems(panel->list_window, compare_seller, (LPARAM)&sort_struct);
}

static void on_column_click(SellerMngPanel panel, NMLISTVIEW *info) {
	LVCOLUMN column;

	column.mask = LVCF_SUBITEM;
	ListView_GetColumn(panel->list_window, info->iSubItem, &column);

	sort_sellers(panel, column.iSubItem);
}

static void on_double_clicked(SellerMngPanel panel, LPNMLISTVIEW info) {
	LVITEM lv_item;

	if(info->iItem == -1) {
		return;
	}
	lv_item.mask = LVIF_PARAM;
	lv_item.iItem = info->iItem;
	ListView_GetItem(panel->list_window, &lv_item);
	Base_select_item_to_return(panel->base, (int)lv_item.lParam);
}

static void on_return(SellerMngPanel panel) {
	LVITEM lv_item;

	lv_item.mask = LVIF_PARAM;
	lv_item.iItem = ListView_GetNextItem(panel->list_window, -1, LVNI_ALL | LVNI_FOCUSED);
	ListView_GetItem(panel->list_window, &lv_item);
	Base_select_item_to_return(panel->base, (int)lv_item.lParam);
}

static void on_key_down(SellerMngPanel panel, LV_KEYDOWN * info) {
	switch(info->wVKey) {
	case VK_RETURN:
		on_return(panel);
		break;
	}
}

static int on_notify(SellerMngPanel panel, NMHDR *info) {
	if(info->idFrom == ID_LIST_VIEW) {
		switch(info->code) {
		case LVN_COLUMNCLICK:
			on_column_click(panel, (NMLISTVIEW *)info);
			break;
		case NM_DBLCLK:
			on_double_clicked(panel, (LPNMLISTVIEW)info);
			break;
		case LVN_GETDISPINFO:
			on_get_display_info(panel, (NMLVDISPINFO *)info);
			break;
		case LVN_KEYDOWN:
			on_key_down(panel, (LV_KEYDOWN *)info);
			break;
		}
	}
	return 0;
}

static void on_size(SellerMngPanel panel, int width, int height) {
	MoveWindow(panel->list_window, 0, 0, width, height, TRUE);
}

static LRESULT CALLBACK seller_window_proc(HWND window, UINT message, WPARAM word_param, LPARAM long_param) {
	SellerMngPanel panel;

	if(message == WM_NCCREATE) {
		LPCREATESTRUCT create_info = (LPCREATESTRUCT)long_param;

		panel = create_info->lpCreateParams;
		panel->window = window;
		SetWindowLong(window, 0, (long)panel);
	}

	panel = (SellerMngPanel)GetWindowLong(window, 0);

	switch(message) {
	case WM_CLOSE:
		break;
	case WM_NOTIFY:
		return on_notify(panel, (NMHDR *)long_param);
	case WM_SIZE:
		on_size(panel, LOWORD(long_param), HIWORD(long_param));
		break;
	default:
		return DefWindowProc(window, message, word_param, long_param);
	}
	return 0L;
}

static void register_seller_window_class(HINSTANCE instance) {
	WNDCLASSEX class;

	class.cbSize = sizeof(class);
	class.style = CS_HREDRAW|CS_VREDRAW;
	class.lpfnWndProc = seller_window_proc;
	class.cbClsExtra = 0;
	class.cbWndExtra = sizeof(Base);
	class.hInstance = instance;
	class.hIcon = NULL;
	class.hCursor = LoadCursor(0,IDC_ARROW);
	class.hbrBackground = (HBRUSH) (COLOR_MENU + 1);
	class.lpszMenuName = NULL;
	class.lpszClassName = SELLER_MNG_PANEL_CLASS_NAME;
	class.hIconSm = NULL;
	RegisterClassEx(&class);
}

static void insert_columns(HWND list_window) {
	LVCOLUMN lv_column;

	lv_column.mask = LVCF_SUBITEM  | LVCF_TEXT | LVCF_WIDTH | LVCF_FMT;
	lv_column.fmt = LVCFMT_LEFT;
	lv_column.iSubItem = 0;
	lv_column.pszText = "�o�i��";
	lv_column.cx = 80;
	ListView_InsertColumn(list_window, 0, &lv_column);

	lv_column.fmt = LVCFMT_LEFT;
	lv_column.iSubItem = 1;
	lv_column.pszText = "�ԋ��z";
	lv_column.cx = 80;
	ListView_InsertColumn(list_window, 1, &lv_column);
}

static HWND create_list_window(HWND parent_window) {
	HWND list_window;

	InitCommonControls();

	list_window = CreateWindowEx(0, WC_LISTVIEW, "",
			WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | LVS_REPORT | LVS_SINGLESEL,
			0, 0, 10, 10,
			parent_window, (HMENU)ID_LIST_VIEW, (HINSTANCE)GetWindowLong(parent_window, GWL_HINSTANCE), NULL);
	ListView_SetExtendedListViewStyle(list_window, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	ShowWindow(list_window, SW_SHOWNORMAL);
	insert_columns(list_window);
	return list_window;
}

static void display_aux(int seller_id, int refunder, void *param) {
	SellerMngPanel panel = (SellerMngPanel) param;
	LVITEM lv_item;

	lv_item.mask = LVIF_PARAM | LVIF_TEXT;
	lv_item.pszText = LPSTR_TEXTCALLBACK;
	lv_item.lParam = seller_id;
	lv_item.iSubItem = 0;
	lv_item.iItem = ListView_GetItemCount(panel->list_window);
	ListView_InsertItem(panel->list_window, &lv_item);
}

static void display(SellerMngPanel panel) {
	ListView_DeleteAllItems(panel->list_window);
	SellerList_enum(panel->seller_list, display_aux, panel);
}

void SellerMngPanel_redraw(SellerMngPanel panel) {
	display(panel);
}

void SellerMngPanel_create_window(SellerMngPanel panel, HWND parent_window) {
	RECT rect;

	Debug_assert(Memory_is_on_heap(panel));
	Debug_assert(panel->window == NULL || !IsWindow(panel->window));

	if(!st_is_initialized) {
		register_seller_window_class((HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE));
		st_is_initialized = SellerMngPanel_TRUE;
	}
	panel->window = CreateWindowEx(0, SELLER_MNG_PANEL_CLASS_NAME, "�o�i�ҒB",
			WS_CHILD | WS_POPUP | WS_SIZEBOX | WS_CAPTION | WS_VISIBLE,
			CW_USEDEFAULT, CW_USEDEFAULT, 300, 150,
			parent_window, (HMENU) 0,
			(HINSTANCE)GetWindowLong(parent_window, GWL_HINSTANCE), panel);
	panel->list_window = create_list_window(panel->window);
	display(panel);
	GetClientRect(panel->window, &rect);
	SendMessage(panel->window, WM_SIZE, 0, MAKELPARAM(rect.right, rect.bottom));
}

void SellerMngPanel_destroy_window(SellerMngPanel panel) {
	Debug_assert(Memory_is_on_heap(panel));

	DestroyWindow(panel->window);
	panel->window = NULL;
}

SellerMngPanel SellerMngPanel_create(Base base, Document document, SellerList seller_list) {
	SellerMngPanel panel;

	panel = Memory_malloc(sizeof(*panel));
	panel->window = NULL;
	panel->base = base;
	panel->document = document;
	panel->seller_list = seller_list;
	return panel;
}

void SellerMngPanel_destroy(SellerMngPanel panel) {
	Debug_assert(Memory_is_on_heap(panel));

	Memory_free(panel);
}

/* end of file */
