/*
 * file: seqFile.h
 * purpose: public header file for SeqFile
 */

#ifndef _PUBLIC_SEQFILE_H_INCLUDED
#define _PUBLIC_SEQFILE_H_INCLUDED

#include "seqFileType.h"

typedef signed char SeqFile_S8b;
typedef signed short SeqFile_S16b;
typedef signed long SeqFile_S32b;
typedef unsigned char SeqFile_U8b;
typedef unsigned short SeqFile_U16b;
typedef unsigned long SeqFile_U32b;

typedef enum {
	SeqFile_READ,
	SeqFile_WRITE
} SeqFile_Mode;

typedef enum {
	SeqFile_TRUE = 1,
	SeqFile_FALSE = 0
} SeqFile_Boolean;


extern SeqFile_U8b SeqFile_read_U8b(SeqFile file);
extern SeqFile_U16b SeqFile_read_U16b(SeqFile file);
extern SeqFile_U32b SeqFile_read_U32b(SeqFile file);
extern SeqFile_S8b SeqFile_read_S8b(SeqFile file);
extern SeqFile_S16b SeqFile_read_S16b(SeqFile file);
extern SeqFile_S32b SeqFile_read_S32b(SeqFile file);
extern void SeqFile_read_string(SeqFile file, char * text, int max_size);
extern void SeqFile_write_U8b(SeqFile file, SeqFile_U8b data);
extern void SeqFile_write_U16b(SeqFile file, SeqFile_U16b data);
extern void SeqFile_write_U32b(SeqFile file, SeqFile_U32b data);
extern void SeqFile_write_S8b(SeqFile file, SeqFile_S8b data);
extern void SeqFile_write_S16b(SeqFile file, SeqFile_S16b data);
extern void SeqFile_write_S32b(SeqFile file, SeqFile_S32b data);
extern void SeqFile_write_string(SeqFile file, const char *text);
extern SeqFile_U32b SeqFile_crc(SeqFile file);
extern long SeqFile_position(SeqFile file);
extern SeqFile_Boolean SeqFile_is_error(SeqFile file);
extern SeqFile_Boolean SeqFile_is_reading_completed(SeqFile file);
extern SeqFile SeqFile_create(const char *path, SeqFile_Mode mode);
extern void SeqFile_destroy(SeqFile file);

#endif /* _PUBLIC_SEQFILE_H_INCLUDED */
/* end of file */
