/*
 * file: itemListP.h
 * purpose: private header file for ItemList
 */

#ifndef _PRIVATE_ITEMLISTP_H_INCLUDED
#define _PRIVATE_ITEMLISTP_H_INCLUDED

#include "itemList.h"

struct tagItemList {
	struct ItemUnit {
		Item item;
		int id;
	} *s;
	int count;
};

#endif /* _PRIVATE_ITEMLISTP_H_INCLUDED */

/* end of file */
