/*
 * file: base_display.c
 * purpose: �\���Ɋւ���Ǝv���邱�Ƃǂ�
 */

#include <string.h>
#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "document.h"
#include "genreList.h"
#include "shapeList.h"
#include "itemList.h"
#include "item.h"
#include "application.h"
#include "vipList.h"
#include "seller.h"
#include "sellerList.h"

#include "baseP.h"

#define TOUCH(a) ((void)(a))

void bASE_display_file_name(Base base) {
	char caption[300];
	char file_name[MAX_PATH];
	
	if(base->is_document_new) {
		LoadString(base->instance, IDS_NO_TITLE_NAME, file_name, sizeof(file_name));
	} else {
		char name[MAX_PATH];
		char extension[MAX_PATH];
		
		_splitpath(base->file_name, NULL, NULL, name, extension);
		sprintf(file_name, "%s%s", name, extension);
	}
	sprintf(caption, "%s - %s", file_name, Application_name());
	SetWindowText(base->main_window, caption);
}

void bASE_display_new_item(Base base, int item_id) {
	LVITEM lv_item;
	
	lv_item.mask = LVIF_PARAM | LVIF_TEXT;
	lv_item.pszText = LPSTR_TEXTCALLBACK;
	lv_item.lParam = item_id;
	lv_item.iSubItem = 0;
	lv_item.iItem = ListView_GetItemCount(base->list_window)-1;
	ListView_InsertItem(base->list_window, &lv_item);
}

void bASE_update_display(Base base) {
	ListView_Update(base->list_window, -1);
}

static void display_aux(int id, Item item, void *param) {
	bASE_display_new_item((Base) param, id);
	TOUCH(item);
}

void bASE_display_item_count(Base base) {
	char message[256];
	
	sprintf(message, "%d�̏��i", ListView_GetItemCount(base->list_window) - 1);
	SendMessage(base->status_window, SB_SETTEXT, 0 | 0, (WPARAM) message);
}

void bASE_display_cash(Base base) {
	char message_proceeds[128];
	char message_cash[128];
	
	sprintf(message_proceeds, "���� \\%d(%d�_)/\\%d(%d�_)", base->todays_proceeds,
			base->todays_sold_count, base->total_proceeds, base->total_sold_count);
	SendMessage(base->status_window, SB_SETTEXT, 2 | 0, (WPARAM) message_proceeds);
	
	sprintf(message_cash, "���ݎ��� \\%d", Document_cash(base->document));
	SendMessage(base->status_window, SB_SETTEXT, 3 | 0, (WPARAM) message_cash);
}

static void calc_refunder_sum_aux(int id, int refunder, void *param) {
	int *refunder_sum = (int *)param;
	
	*refunder_sum += refunder;
}

void bASE_display_refunder_sum(Base base) {
	char message[128];
	
	if(base->mode==MODE_RETURN) {
		int refunder_sum;
		
		refunder_sum = 0;
		SellerList_enum(base->seller_list, calc_refunder_sum_aux, &refunder_sum);
		sprintf(message, "���ԋ��z \\%d", refunder_sum);
	} else {
		strcpy(message, "");
	}
	SendMessage(base->status_window, SB_SETTEXT, 4 | 0, (WPARAM) message);
}

void bASE_display_mode(Base base) {
	char * message;
	
	switch(base->mode) {
	case MODE_COLLECT:
		message = "��W���[�h";
		break;
	case MODE_SELL:
		message = "�̔����[�h";
		break;
	case MODE_RETURN:
		message = "�ԕi���[�h";
		break;
	}
	SendMessage(base->status_window, SB_SETTEXT, 1 | 0, (WPARAM) message);
}

static void display_nil_item(HWND list_window) {
	LVITEM lv_item;
	
	lv_item.mask = LVIF_PARAM|LVIF_TEXT;
	lv_item.pszText = LPSTR_TEXTCALLBACK;
	lv_item.lParam = NIL_ITEM;
	lv_item.iItem = 0;
	lv_item.iSubItem = 0;
	ListView_InsertItem(list_window, &lv_item);
}

void bASE_display(Base base) {
	ItemList items;
	int i;
	
	ListView_DeleteAllItems(base->list_window);
	
	display_nil_item(base->list_window);
	
	items = Document_item_list(base->document);
	
	ListView_SetItemCount(base->list_window, ItemList_count(items) + 1);
	ItemList_enum(items, display_aux, base);
	ListView_EnsureVisible(base->list_window, ListView_GetItemCount(base->list_window) - 2, (BOOL)TRUE);
	
	bASE_display_file_name(base);
	bASE_display_item_count(base);
	bASE_display_mode(base);
	bASE_display_cash(base);
	bASE_display_refunder_sum(base);
}

static void get_text_seller(Base base, char *text, ConstItem item) {
	int seller_id;
	
	seller_id = Item_seller_id(item);
	
	switch(Seller_type(seller_id)) {
	case Seller_STUDENT:
		if(Seller_grade(seller_id)<=3) {
			/* ���V */
			sprintf(text, "%d�N%c�g %d��", Seller_grade(seller_id),
					Seller_class(seller_id) + 'A' - 1, Seller_number(seller_id));
		} else {
			/* ���Z�� */
			sprintf(text, "%d�N%d�g %d��", Seller_grade(seller_id) - 3,
					Seller_class(seller_id), Seller_number(seller_id));
		}
		break;
	case Seller_TEACHER:
		sprintf(text, "%s����", VipList_name(Document_teacher_list(base->document),
					Seller_vip_id(seller_id)));
		break;
	case Seller_OB:
		sprintf(text, "%s��", VipList_name(Document_ob_list(base->document),
					Seller_vip_id(seller_id)));
		break;
	case Seller_LEGACY:
		strcpy(text, "��Y");
		break;
	case Seller_DONATION:
		strcpy(text, "��t");
		break;
	}
}

void bASE_on_get_display_info(Base base, NMLVDISPINFO *display_info) {
	LVCOLUMN lv_column;
	static char text[256];
	int item_id;
	ConstItem item;
	GenreList genre_list;
	int major, minor, extra, shape;
	time_t receipt_time_aux;
	
	item_id = display_info->item.lParam;
	if(item_id == NIL_ITEM) {
		display_info->item.pszText = "";
		return;
	}
	item = ItemList_item(Document_item_list(base->document), item_id);
	
	lv_column.mask = LVCF_SUBITEM;
	ListView_GetColumn(base->list_window, display_info->item.iSubItem, &lv_column);
	
	switch(lv_column.iSubItem) {
	case ID_ITEM_ID:
		sprintf(text, "%.5d", item_id);
		break;
	case ID_SELLER:
		get_text_seller(base, text, item);
		break;
	case ID_ITEM_NAME:
		strcpy(text, Item_name(item));
		break;
	case ID_LIST_PRICE:
		sprintf(text, "%d", Item_list_price(item));
		break;
	case ID_IS_TO_BE_RETURNED:
		strcpy(text, Item_is_to_be_returned(item) ? "��" : "�s��" );
		break;
	case ID_IS_TO_BE_DISCOUNTED:
		strcpy(text, Item_is_to_be_discounted(item) ? "�@" : "�s�@" );
		break;
	case ID_GENRE:
		genre_list = Document_genre_list(base->document);
		sprintf(text, "%s : %s : %s", GenreList_name(genre_list, Item_major_genre(item)),
				GenreList_name(genre_list, Item_minor_genre(item)),
				GenreList_name(genre_list, Item_extra_genre(item)));
		break;
	case ID_SHAPE:
		shape = Item_shape(item);
		strcpy(text, shape != 0 ? ShapeList_name(Document_shape_list(base->document), shape) : "����");
		break;
	case ID_RECEIPT_TIME:
		receipt_time_aux = Item_receipt_time(item);
		if(receipt_time_aux == 0L) {
			strcpy(text, "����");
		} else {
			struct tm receipt_time;
			receipt_time = *localtime(&receipt_time_aux);
			sprintf(text, "%d/%d %.2d:%.2d", receipt_time.tm_mon + 1, receipt_time.tm_mday,
				receipt_time.tm_hour, receipt_time.tm_min);
		}
		break;
	case ID_SCHEDULED_DATE:
		if(Item_scheduled_date(item) == 0) {
			strcpy(text, "����");
		} else {
			sprintf(text, "%d����", Item_scheduled_date(item));
		}
		break;
	case ID_COMMENT:
		strcpy(text, Item_comment(item) != NULL ? Item_comment(item) : "");
		break;
	case ID_IS_SOLD:
		strcpy(text, Item_is_sold(item) ? "���p��" : "����");
		break;
	case ID_SOLD_TIME:
		if(Item_is_sold(item)) {
			struct tm sold_time;
			time_t sold_time_aux;
			
			sold_time_aux = Item_sold_time(item);
			sold_time = *localtime(&sold_time_aux);
			sprintf(text, "%d/%d %.2d:%.2d", sold_time.tm_mon + 1, sold_time.tm_mday,
				sold_time.tm_hour, sold_time.tm_min);
		} else {
			strcpy(text, "����");
		}
		break;
	case ID_REAL_PRICE:
		if(Item_is_sold(item)) {
			sprintf(text, "%d", Item_real_price(item));
		} else {
			strcpy(text, "����");
		}
		break;
	case ID_IS_BY_AUCTION:
		strcpy(text, Item_is_by_auction(item) ? "��" : "�s��");
		break;
	case ID_REFUND_RATE:
		if(Item_refund_rate(item) == -1) {
			strcpy(text, "����l");
		} else {
			sprintf(text, "%d%%", Item_refund_rate(item));
		}
		break;
	}
	display_info->item.pszText = text;
}

/* end of file */
