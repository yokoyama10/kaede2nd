/*
 * file: itemList.c
 * purpose: item�̃��X�g
 */

#include <stdlib.h>
#include "memory.h"
#include "debug.h"
#include "item.h"

#include "itemListP.h"

#define NOT_FOUND (-1)

static int cmp_item_unit(const void *elem1, const void *elem2) {
	const struct ItemUnit *a = elem1;
	const struct ItemUnit *b = elem2;

	return a->id - b->id;
}

static int search_item(ItemList item_list, int id) {
	struct ItemUnit key;
	struct ItemUnit *result;

	key.id = id;
	result = bsearch(&key, item_list->s, item_list->count, sizeof(key), cmp_item_unit);
	if(result) {
		return result - item_list->s;
	} else {
		return NOT_FOUND;
	}
}

static void copy_item(Item dest, ConstItem source) {
	Item_set_seller_id(dest, Item_seller_id(source));
	Item_set_name(dest, Item_name(source));
	Item_set_list_price(dest, Item_list_price(source));
	Item_set_real_price(dest, Item_real_price(source));
	Item_set_is_sold(dest, Item_is_sold(source));
	Item_set_is_returned(dest, Item_is_returned(source));
	Item_set_is_to_be_returned(dest, Item_is_to_be_returned(source));
	Item_set_is_to_be_discounted(dest, Item_is_to_be_discounted(source));
	Item_set_major_genre(dest, Item_major_genre(source));
	Item_set_minor_genre(dest, Item_minor_genre(source));
	Item_set_extra_genre(dest, Item_extra_genre(source));
	Item_set_shape(dest, Item_shape(source));
	Item_set_receipt_time(dest, Item_receipt_time(source));
	Item_set_sold_time(dest, Item_sold_time(source));
	Item_set_scheduled_date(dest, Item_scheduled_date(source));
	Item_set_is_by_auction(dest, Item_is_by_auction(source));
	Item_set_refund_rate(dest, Item_refund_rate(source));
	Item_set_comment(dest, Item_comment(source));
}

static void insert_item(ItemList item_list, int id, ConstItem org_item) {
	item_list->s = Memory_realloc(item_list->s, sizeof(*item_list->s) * (item_list->count + 1));
	item_list->s[item_list->count].id = id;
	item_list->s[item_list->count].item = Item_create();
	copy_item(item_list->s[item_list->count].item, org_item);
	item_list->count += 1;
}

int ItemList_set(ItemList item_list, int id, ConstItem org_item) {
	int result_id;

	Debug_assert(Memory_is_on_heap(item_list));

	if(id == ItemList_ID_NEW) {
		int new_id;

		if(item_list->count == 0) {
			new_id = 0;
		} else {
			new_id = item_list->s[item_list->count-1].id + 1;
		}
		insert_item(item_list, new_id, org_item);
		result_id = new_id;
	} else {
		int order;

		order = search_item(item_list, id);
		if(order == NOT_FOUND) {
			insert_item(item_list, id, org_item);
		} else {
			copy_item(item_list->s[order].item, org_item);
		}
		result_id = id;
	}
	return result_id;
}

int ItemList_count(ItemList item_list) {
	Debug_assert(Memory_is_on_heap(item_list));

	return item_list->count;
}

int ItemList_first_id(ItemList item_list) {
	Debug_assert(Memory_is_on_heap(item_list));
	Debug_assert(item_list->count > 0);

	return item_list->s[0].id;
}

int ItemList_last_id(ItemList item_list) {
	Debug_assert(Memory_is_on_heap(item_list));
	Debug_assert(item_list->count > 0);

	return item_list->s[item_list->count - 1].id;
}

void ItemList_enum(ItemList item_list, void(*proc)(int id, Item, void *param), void *param) {
	int i;

	Debug_assert(Memory_is_on_heap(item_list));

	for(i = 0; i < item_list->count; i++) {
		proc(item_list->s[i].id, item_list->s[i].item, param);
	}
}

ConstItem ItemList_item(ItemList item_list, int id) {
	int order;

	Debug_assert(Memory_is_on_heap(item_list));

	order = search_item(item_list, id);
	Debug_assert(order != NOT_FOUND);

	return item_list->s[order].item;
}

void ItemList_delete(ItemList item_list, int id) {
	int order;
	int i;

	Debug_assert(Memory_is_on_heap(item_list));

	order = search_item(item_list, id);
	Debug_assert(order!=NOT_FOUND);

	Item_destroy(item_list->s[order].item);
	for(i = order + 1; i < item_list->count; i++) {
		item_list->s[i - 1] = item_list->s[i];
	}
	item_list->s = Memory_realloc(item_list->s, sizeof(*item_list->s) * (item_list->count - 1));
	item_list->count -= 1;
}

ItemList ItemList_create(void) {
	ItemList item_list;

	item_list = Memory_malloc(sizeof(*item_list));

	item_list->s = NULL;
	item_list->count = 0;

	return item_list;
}

void ItemList_destroy(ItemList item_list) {
	int i;

	Debug_assert(Memory_is_on_heap(item_list));

	for(i = 0; i < item_list->count; i++) {
		Item_destroy(item_list->s[i].item);
	}

	Memory_free(item_list->s);
	Memory_free(item_list);
}

/* end of file */
