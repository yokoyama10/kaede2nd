/*
 * file: dictionary.c
 * purpose: Skip Lists��p�����A�z�z��BKey�̏�����ێ�����
 */

#include <stdlib.h>
#include "debug.h"
#include "memory.h"

#include "dictionaryP.h"

static Dictionary_Boolean coin_toss(void) {
	if(rand() > RAND_MAX / 2) {
		return Dictionary_TRUE;
	} else {
		return Dictionary_FALSE;
	}
}

static int rand_level(int level_max) {
	int level;

	for(level = 0; level <= level_max; level++) {
		if(coin_toss()) {
			return level;
		}
	}
	return 0;
}

static Node create_node(Dictionary_Key key, Dictionary_Data data) {
	Node node;

	node = (Node) Memory_malloc(sizeof(*node));

	node->level = rand_level(MAX_LEVEL);
	node->forward = (Node *) Memory_malloc(sizeof(Node) * (node->level + 1));
	node->backward = (Node *) Memory_malloc(sizeof(Node) * (node->level + 1));
	node->key = key;
	node->data = data;
	return node;
}

static void destroy_node(Node node) {
	Memory_free(node->backward);
	Memory_free(node->forward);
	Memory_free(node);
}

static void chain_together(Node first, Node second, int level) {
	first->forward[level] = second;
	second->backward[level] = first;
}

static void chain_in(Dictionary dictionary, Node node, Node left) {
	int  count_level;
	Node target;

	target = left;
	for(count_level = 0; count_level <= node->level; count_level++) {
		while(target->level < count_level) {
			/* when count_level is 0, this code does not run */
			target = target->backward[count_level - 1];
		}
		chain_together(node, target->forward[count_level], count_level);
		chain_together(target, node, count_level);
	}
}

static void unchain(Dictionary dictionary, Node node) {
	int  level;

	for(level = 0; level <= node->level; level++) {
		chain_together(node->backward[level], node->forward[level], level);
	}
}

static compare(Dictionary_Comparer comp_func, Dictionary_Key key1, Dictionary_Key key2) {
	if(comp_func != NULL) {
		return comp_func(key1, key2);
	} else {
		if((long)key1 == (long)key2) {
			return 0;
		} else if((long)key1 < (long)key2) {
			return -1;
		} else {
			return 1;
		}
	}
}

static Node search_node(Dictionary dictionary, Dictionary_Key key, Node *left_ref, Node *right_ref) {
	Node left_bound,right_bound;
	Node cur;
	int  level;
	int  ret;

	left_bound = dictionary->tip_node;
	right_bound = dictionary->tip_node;
	for(level = MAX_LEVEL; level >= 0; level--) {
		cur = left_bound;
		do {
			cur = cur->forward[level];
			if(cur == right_bound) {
				break;
			}
			ret = compare(dictionary->comp_func, cur->key, key);
			if(ret == 0) {
				*left_ref = cur->backward[0];
				*right_ref = cur->forward[0];
				return cur;
			}
		} while(ret < 0);
		right_bound = cur;
		left_bound = cur->backward[level];
	} /* end of the level loop */
	*left_ref = left_bound;
	*right_ref = right_bound;
	return NULL;
}

static void enum_aux(Node from, Node to, Dictionary_Iterator iterator, void *param) {
	Node cur;

	for(cur = from; cur != to; cur = cur->forward[0]) {
		iterator(cur->key, cur->data, param);
	}
}

void Dictionary_enum_from(Dictionary dictionary, Dictionary_Key from, Dictionary_Iterator iterator, void *param) {
	Node from_node, from_left, from_right;

	Debug_assert(Memory_is_on_heap(dictionary));

	from_node = search_node(dictionary, from, &from_left, &from_right);
	enum_aux(from_node ? from_node : from_right, dictionary->tip_node, iterator, param);
}

void Dictionary_enum_to(Dictionary dictionary, Dictionary_Key to, Dictionary_Iterator iterator, void *param) {
	Node to_left, to_right;

	Debug_assert(Memory_is_on_heap(dictionary));

	search_node(dictionary, to, &to_left, &to_right);
	enum_aux(dictionary->tip_node->forward[0], to_right, iterator, param);
}

void Dictionary_enum_range(Dictionary dictionary, Dictionary_Key from, Dictionary_Key to, Dictionary_Iterator iterator, void *param) {
	Node from_node, from_left, from_right;
	Node to_left, to_right;

	Debug_assert(Memory_is_on_heap(dictionary));

	from_node = search_node(dictionary, from, &from_left, &from_right);
	search_node(dictionary, to, &to_left, &to_right);
	enum_aux(from_node?from_node:from_right, to_right, iterator, param);
}

void Dictionary_enum(Dictionary dictionary, Dictionary_Iterator iterator, void * param) {
	Node cur;

	Debug_assert(Memory_is_on_heap(dictionary));
	Debug_assert(iterator != NULL);

	enum_aux(dictionary->tip_node->forward[0], dictionary->tip_node, iterator, param);
}

Dictionary_Boolean Dictionary_delete(Dictionary dictionary, Dictionary_Key key) {
	Node node, left, right;

	Debug_assert(Memory_is_on_heap(dictionary));
	node = search_node(dictionary, key, &left, &right);

	if(node != NULL) {
		unchain(dictionary, node);
		destroy_node(node);
		return Dictionary_TRUE;
	} else {
		return Dictionary_FALSE;
	}
}

Dictionary_Data Dictionary_data(Dictionary dictionary, Dictionary_Key key) {
	Node node, left, right;

	Debug_assert(Memory_is_on_heap(dictionary));

	node = search_node(dictionary, key, &left, &right);
	if(node != NULL) {
		return node->data;
	} else {
		return dictionary->default_data;
	}
}

void Dictionary_set(Dictionary dictionary, Dictionary_Key key, Dictionary_Data data) {
	Node node, left, right;

	Debug_assert(Memory_is_on_heap(dictionary));

	node = search_node(dictionary, key, &left, &right);
	if(node != NULL) {
		node->data = data;
	} else {
		node = create_node(key, data);
		chain_in(dictionary, node, left);
	}
}

Dictionary Dictionary_create(Dictionary_Data default_data, Dictionary_Comparer comp_func) {
	Dictionary dictionary;
	int i;

	dictionary = Memory_malloc(sizeof(*dictionary));
	dictionary->comp_func = comp_func;
	dictionary->default_data = default_data;
	dictionary->tip_node = (Node) Memory_malloc(sizeof(*dictionary->tip_node));
	dictionary->tip_node->level = MAX_LEVEL;
	dictionary->tip_node->forward = (Node *) Memory_malloc(sizeof(Node *) * (MAX_LEVEL + 1));
	dictionary->tip_node->backward = (Node *) Memory_malloc(sizeof(Node *) * (MAX_LEVEL + 1));
	dictionary->tip_node->key = 0L;
	dictionary->tip_node->data = 0L;
	for(i = 0; i <= MAX_LEVEL; i++) {
		dictionary->tip_node->forward[i] = dictionary->tip_node;
		dictionary->tip_node->backward[i] = dictionary->tip_node;
	}
	return dictionary;
}

void Dictionary_destroy(Dictionary dictionary) {
	Node cur,next;

	Debug_assert(Memory_is_on_heap(dictionary));

	cur = dictionary->tip_node->forward[0];
	while(cur != dictionary->tip_node) {
		next = cur->forward[0];
		destroy_node(cur);
		cur = next;
	}

	/* destroy tip_node */
	Memory_free(dictionary->tip_node->forward);
	Memory_free(dictionary->tip_node->backward);
	Memory_free(dictionary->tip_node);

	Memory_free(dictionary);
}

/* end of file */
