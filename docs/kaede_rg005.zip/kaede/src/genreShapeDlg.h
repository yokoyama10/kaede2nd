/*
 * file: genreShapeDlg.h
 * purpose: public header file for GenreShapeDlg
 */

#ifndef _PUBLIC_GENRESHAPEDLG_H_INCLUDED
#define _PUBLIC_GENRESHAPEDLG_H_INCLUDED

#include <windows.h>
#include "genreListType.h"
#include "shapeListType.h"
#include "itemListType.h"

typedef struct tagGenreShapeDlg * GenreShapeDlg;
typedef enum {
	GenreShapeDlg_TRUE = 1,
	GenreShapeDlg_FALSE = 0
} GenreShapeDlg_Boolean;

extern GenreShapeDlg_Boolean GenreShapeDlg_is_shapes_cleared(GenreShapeDlg dialog);
extern GenreShapeDlg_Boolean GenreShapeDlg_is_genres_cleared(GenreShapeDlg dialog);
extern const ShapeList GenreShapeDlg_shape_list(GenreShapeDlg dialog);
extern const GenreList GenreShapeDlg_genre_list(GenreShapeDlg dialog);
extern GenreShapeDlg_Boolean GenreShapeDlg_dialogue(GenreShapeDlg dialog, HWND parent_window);
extern GenreShapeDlg GenreShapeDlg_create(ConstGenreList genre_list, ShapeList shape_list, ItemList item_list);
extern void GenreShapeDlg_destroy(GenreShapeDlg dialog);

#endif /* _PUBLIC_GENRESHAPEDLG_H_INCLUDED */
/* end of file */
