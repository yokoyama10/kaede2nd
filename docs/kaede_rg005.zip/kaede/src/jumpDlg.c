/*
 * file: jumpDlg.c
 * purpose: �w��s��Jump!�_�C�A���O
 */

#include <windows.h>
#include "memory.h"
#include "debug.h"

#include "jumpDlgP.h"

#define TOUCH(a) ((void)(a))

static void on_ok(JumpDlg dialog) {
	BOOL is_translated;

	dialog->item_id = GetDlgItemInt(dialog->window, IDC_ITEM_ID, &is_translated, FALSE);
	if(is_translated) {
		EndDialog(dialog->window, IDOK);
	} else {
		EndDialog(dialog->window, IDCANCEL);
	}
}

static void on_cancel(JumpDlg dialog) {
	EndDialog(dialog->window, IDCANCEL);
}

static void on_command(JumpDlg dialog, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDOK:
		on_ok(dialog);
		break;
	case IDCANCEL:
		on_cancel(dialog);
		break;
	}
	TOUCH(notify_code);
	TOUCH(ctrl_window);
}

static void on_init_dialog(JumpDlg dialog) {
	HIMC imc;

	imc = ImmGetContext(dialog->window);
	ImmSetOpenStatus(imc, FALSE);
	ImmReleaseContext(dialog->window, imc);
	if(dialog->mode==JumpDlg_HASTE) {
		SetWindowText(dialog->window, "���p���鏤�i�ԍ�");
	}
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	JumpDlg dialog;
	if(message == WM_INITDIALOG) {
		dialog = (JumpDlg) long_param;
		SetWindowLong(dialog_window, DWL_USER, (LONG)dialog);
		dialog->window = dialog_window;
	}
	dialog = (JumpDlg)GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_INITDIALOG:
		on_init_dialog(dialog);
		break;
	case WM_COMMAND:
		on_command(dialog, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}


JumpDlg_Boolean JumpDlg_dialogue(JumpDlg dialog, HWND parent_window) {
	int return_value;
	HINSTANCE instance = (HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE);

	Debug_assert(Memory_is_on_heap(dialog));

	return_value = DialogBoxParam(instance, MAKEINTRESOURCE(IDD_JUMP), parent_window, dialog_proc, (LONG)dialog);
	if(return_value == IDOK) {
		return JumpDlg_TRUE;
	} else {
		return JumpDlg_FALSE;
	}
}

int JumpDlg_item_id(JumpDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	return dialog->item_id;
}

JumpDlg JumpDlg_create(JumpDlg_Mode mode) {
	JumpDlg dialog;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->mode = mode;
	return dialog;
}

void JumpDlg_destroy(JumpDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	Memory_free(dialog);
}

/* end of file */
