/*
 * file: print.c
 * purpose: ���
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <dbcsstr.h>
#include "debug.h"
#include "document.h"
#include "itemList.h"
#include "item.h"
#include "memory.h"
#include "config.h"
#include "string.h"
#include "printFormDlg.h"
#include "genreList.h"
#include "shapeList.h"

#include "printP.h"

#define MAX(a, b) (((a)>(b))?(a):(b))

#define ESC '\x1b'

#define MAJOR 'j'
#define MINOR 'i'
#define EXTRA 'e'
#define SHAPE 's'
#define ID 'd'
#define NAME 'n'
#define LIST_PRICE 'p'
#define TATAKI_FLAG 't'
#define HENPIN_FLAG 'h'
#define AUCTION_FLAG 'a'
#define COMMENT 'c'


static Form * st_forms;
static int st_form_count;
static Boolean st_initialized;


static void expand_line(char *line, const char *form, int id, ConstItem item, GenreList genre_list, ShapeList shape_list) {
	const char * form_p;
	char buf[16];

	form_p = form;
	line[0] = 0;
	while(1) {
		const char *esc;
		char text[128];
		char temp[128];

		esc = strchr(form_p, ESC);
		if(esc == NULL) {
			strcat(line, form_p);
			break;
		}

		switch(*(esc + 1)) {
		case MAJOR:
			sprintf(text, "%s", GenreList_order_text(genre_list,
						Item_major_genre(item), buf));
			break;
		case MINOR:
			sprintf(text, "%s", GenreList_order_text(genre_list,
						Item_minor_genre(item), buf));
			break;
		case EXTRA:
			sprintf(text, "%s", GenreList_order_text(genre_list,
						Item_extra_genre(item), buf));
			break;
		case SHAPE:
			sprintf(text, "%s", ShapeList_id_text(shape_list, Item_shape(item), buf));
			break;
		case ID:
			sprintf(text, "%d", id);
			break;
		case NAME:
			strcpy(text, Item_name(item));
			break;
		case LIST_PRICE:
			sprintf(text, "%d", Item_list_price(item));
			break;
		case TATAKI_FLAG:
			strcpy(text, Item_is_to_be_discounted(item) ? "��" : "�~");
			break;
		case HENPIN_FLAG:
			strcpy(text, Item_is_to_be_returned(item) ? "��" : "�~");
			break;
		case AUCTION_FLAG:
			strcpy(text, Item_is_by_auction(item) ? "��" : "�~");
			break;
		case COMMENT:
			strcpy(text, Item_comment(item));
			break;
		default:
			strcpy(text, "");
			esc -= 1;
			break;
		}
		strncpy(temp, form_p, esc-form_p);
		temp[esc-form_p] = 0;
		strcat(line, temp);
		strcat(line, text);
		form_p = esc + 2;
	}
}

static void print_item(HDC dc, int id, ConstItem item, int start_x, int start_y, Form * form, GenreList genre_list, ShapeList shape_list) {
	TEXTMETRIC text_metric;
	int font_height, font_width;
	int i;

	GetTextMetrics(dc, &text_metric);
	font_height = text_metric.tmHeight;
	font_width = text_metric.tmHeight;

	for(i = 0; i < form->line_count; i++) {
		char line[256];
		int y;

		y = start_y - font_height*(form->top_margin + (100 + form->line_margin) * i) / 100;

		expand_line(line, form->lines[i], id, item, genre_list, shape_list);
		TextOut(dc, start_x+font_width, y, line, strlen(line));
	}
}

static int column_height(HDC dc, Form *form) {
	TEXTMETRIC text_metric;
	int text_height;

	GetTextMetrics(dc, &text_metric);

	return text_metric.tmHeight*(form->top_margin + 100 * form->line_count +
			form->line_margin * (form->line_count - 1) + form->bottom_margin) / 100;
}

static void print_page(HDC dc, Document document, const int *printed_items_ids, int count, Form *form) {
	int row_count, col_count;
	SIZE paper_size;
	int i;
	ItemList item_list;

	item_list = Document_item_list(document);

	paper_size.cx = GetDeviceCaps(dc, HORZSIZE) * 10;
	paper_size.cy = GetDeviceCaps(dc, VERTSIZE) * 10;

	col_count = MAX(1, paper_size.cx / form->column_width);
	row_count = MAX(1, paper_size.cy / column_height(dc, form));

	StartPage(dc);

	/* �c�g�������� */
	for(i = 1; i <= col_count; i++) {
		MoveToEx(dc, i * form->column_width, 0, NULL);
		LineTo(dc, i * form->column_width, -paper_size.cy);
	}

	/* ���g�������� */
	for(i = 1; i <= row_count; i++) {
		MoveToEx(dc, 0, -i * column_height(dc, form), NULL);
		LineTo(dc, paper_size.cx, -i * column_height(dc, form));
	}

	/* �`�[������ */
	for(i = 0; i < count; i++) {
		ConstItem item;
		int row, col;

		item = ItemList_item(item_list, printed_items_ids[i]);
		row = i / col_count;
		col = i % col_count;
		print_item(dc, printed_items_ids[i], item,
				col * form->column_width, -row * column_height(dc, form), form,
				Document_genre_list(document), Document_shape_list(document));
	}

	EndPage(dc);
}

static HFONT create_font(Form *form) {
	LOGFONT logfont;
	HFONT font;

	logfont.lfHeight = form->text_height;
	logfont.lfWidth = 0;
	logfont.lfEscapement = 0;
	logfont.lfOrientation = 0;
	logfont.lfWeight = FW_REGULAR;
	logfont.lfItalic = 0;
	logfont.lfUnderline = 0;
	logfont.lfStrikeOut = 0;
	logfont.lfCharSet = SHIFTJIS_CHARSET;
	logfont.lfOutPrecision = OUT_DEFAULT_PRECIS;
	logfont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	logfont.lfQuality = PROOF_QUALITY;
	logfont.lfPitchAndFamily = FIXED_PITCH | FF_MODERN;
	sprintf(logfont.lfFaceName, "�l�r �S�V�b�N");

	font = CreateFontIndirect(&logfont);
	return font;
}

static void print(HDC dc, Document document, const int *printed_items_ids, int printed_item_count, const char *doc_name, Form *form) {
	HFONT font, old_font;
	DOCINFO doc_info;
	int i;
	SIZE paper_size;
	int row_count, col_count;

	doc_info.cbSize = sizeof(doc_info);
	doc_info.lpszDocName = doc_name;
	doc_info.lpszOutput = NULL;
	doc_info.lpszDatatype = NULL;
	doc_info.fwType = 0;

	SetMapMode(dc, MM_LOMETRIC);

	StartDoc(dc, &doc_info);

	font = create_font(form);
	old_font = SelectObject(dc, font);

	paper_size.cx = GetDeviceCaps(dc, HORZSIZE) * 10;
	paper_size.cy = GetDeviceCaps(dc, VERTSIZE) * 10;

	col_count = MAX(1, paper_size.cx / form->column_width);
	row_count = MAX(1, paper_size.cy / column_height(dc, form));

	i = 0;
	while(i < printed_item_count) {
		print_page(dc, document, printed_items_ids + i,
				min(row_count * col_count, printed_item_count - i), form);
		i += row_count * col_count;
	}

	SelectObject(dc, old_font);
	EndDoc(dc);
	DeleteObject(font);
}

static UINT CALLBACK hook_proc(HWND window, UINT message, WPARAM word_param, LPARAM long_param) {
	char text[128];
	switch(message) {
	case WM_INITDIALOG:
		SetDlgItemText(window, rad1, "�S���i(&A)");
		SetDlgItemText(window, rad3, "�i�Ԏw��(&G)");
		SetDlgItemText(window, stc2, "�Ԃ���(&F)");
		SetDlgItemText(window, stc3, "�Ԃ܂�(&T)");
		break;
	}
	return FALSE;
}

struct Aux {
	int count;
	int *item_ids;
	int from;
	int to;
};

static void print_aux(int id, Item item, void *param) {
	struct Aux *aux = (struct Aux *)param;

	if(id >= aux->from && id <= aux->to) {
		aux->item_ids = Memory_realloc(aux->item_ids, sizeof(int) * (aux->count + 1));
		aux->item_ids[aux->count] = id;
		aux->count += 1;
	}
}

void Print_print(Document document, const int *selected_ids, int selected_count, const char *doc_name, HWND parent_window) {
	int form_index;
	PRINTDLG print_dialog;
	const ConstItem *items;
	int item_count;
	int first_id;
	int last_id;
	ItemList item_list;
	PrintFormDlg form_dialog;
	const char **form_names;
	int i;

	item_list = Document_item_list(document);

	if(ItemList_count(item_list) == 0) {
		return;
	}

	form_names = Memory_malloc(sizeof(*form_names) * st_form_count);
	for(i = 0; i < st_form_count; i++) {
		form_names[i] = st_forms[i].name;
	}
	form_dialog = PrintFormDlg_create(st_form_count, form_names);
	if(!PrintFormDlg_dialogue(form_dialog, parent_window)) {
		PrintFormDlg_destroy(form_dialog);
		Memory_free(form_names);
		return;
	}
	form_index = PrintFormDlg_index(form_dialog);
	PrintFormDlg_destroy(form_dialog);
	Memory_free(form_names);

	first_id = ItemList_first_id(item_list);
	last_id = ItemList_last_id(item_list);

	print_dialog.lStructSize = sizeof(print_dialog);
	print_dialog.hwndOwner = parent_window;
	print_dialog.hDevMode = NULL;
	print_dialog.hDevNames = NULL;
	print_dialog.Flags = PD_USEDEVMODECOPIESANDCOLLATE | PD_RETURNDC |
		PD_HIDEPRINTTOFILE | PD_ENABLEPRINTHOOK;
	print_dialog.nCopies = 1;
	print_dialog.nFromPage = first_id;
	print_dialog.nToPage = last_id;
	print_dialog.nMinPage = first_id;
	print_dialog.nMaxPage = last_id;
	print_dialog.lpfnPrintHook = hook_proc;

	if(PrintDlg(&print_dialog)) {
		if(print_dialog.Flags & PD_SELECTION) {
			print(print_dialog.hDC, document, selected_ids, selected_count, doc_name, &st_forms[form_index]);
		} else {
			struct Aux aux;

			aux.count = 0;
			aux.item_ids = NULL;
			aux.from = print_dialog.nFromPage;
			aux.to = print_dialog.nToPage;
			ItemList_enum(item_list, print_aux, &aux);
			print(print_dialog.hDC, document, aux.item_ids, aux.count, doc_name, &st_forms[form_index]);
			Memory_free(aux.item_ids);
		}
		DeleteDC(print_dialog.hDC);
	}
}

static void compile_line(char *dest, const char *src) {
	int si;

	si = 0;

	dest[0] = 0;
	while(1) {
		const char *val_start, *val_end;
		char val_text[128];
		int val;
		char temp[10];

		val_start = strchr(src + si, '%');
		if(val_start == NULL) {
			strcat(dest, src + si);
			break;
		}

		val_end = strchr(val_start + 1, '%');
		if(val_end == NULL) {
			strcat(dest, src + si);
			break;
		}

		strncpy(val_text, val_start + 1, val_end - val_start - 1);
		val_text[val_end-val_start - 1] = 0;

		if(strcmp(val_text, "major") == 0) {
			val = MAJOR;
		} else if(strcmp(val_text, "minor") == 0) {
			val = MINOR;
		} else if(strcmp(val_text, "extra") == 0) {
			val = EXTRA;
		} else if(strcmp(val_text, "shape") == 0) {
			val = SHAPE;
		} else if(strcmp(val_text, "id") == 0) {
			val = ID;
		} else if(strcmp(val_text, "name") == 0) {
			val = NAME;
		} else if(strcmp(val_text, "list_price") == 0) {
			val = LIST_PRICE;
		} else if(strcmp(val_text, "tataki_flag") == 0) {
			val = TATAKI_FLAG;
		} else if(strcmp(val_text, "henpin_flag") == 0) {
			val = HENPIN_FLAG;
		} else if(strcmp(val_text, "auction_flag") == 0) {
			val = AUCTION_FLAG;
		} else if(strcmp(val_text, "comment") == 0) {
			val = COMMENT;
		} else {
			strcat(dest, src + si);
			break;
		}

		strncpy(temp, src+si, val_start-(src+si));
		temp[val_start - (src + si)] = 0;
		strcat(dest, temp);
		sprintf(temp, "%c%c", ESC, val);
		strcat(dest, temp);
		si = (val_end - src) + 1;
	}
}

void Print_initialize(void) {
	int i;
	char section_name[64];
	char config_file_name[512];

	Debug_assert(!st_initialized);
	st_initialized = TRUE;

	strcpy(config_file_name, Config_file_name());
	st_form_count = GetPrivateProfileInt("Print", "form_count", 1, config_file_name);
	st_forms = Memory_malloc(sizeof(*st_forms)*st_form_count);

	for(i = 0; i < st_form_count; i++) {
		int j;
		char name[128];

		sprintf(section_name, "PrintForm%d", i + 1);

		GetPrivateProfileString(section_name, "name", "default", name, sizeof(name), config_file_name);
		st_forms[i].name = String_make(NULL, name);
		st_forms[i].text_height = GetPrivateProfileInt(section_name, "text_height", 35, config_file_name);
		st_forms[i].line_margin = GetPrivateProfileInt(section_name, "line_margin", 50, config_file_name);
		st_forms[i].top_margin = GetPrivateProfileInt(section_name, "top_margin", 100, config_file_name);
		st_forms[i].bottom_margin = GetPrivateProfileInt(section_name, "bottom_margin", 100, config_file_name);
		st_forms[i].column_width = GetPrivateProfileInt(section_name, "column_width", 850, config_file_name);

		st_forms[i].line_count = GetPrivateProfileInt(section_name, "line_count", 3, config_file_name);
		st_forms[i].lines = Memory_malloc(sizeof(*st_forms[i].lines)*st_forms[i].line_count);
		for(j = 0; j < st_forms[i].line_count; j++) {
			char key_name[64];
			char default_line[64];
			char line[128];
			char line2[128];

			sprintf(key_name, "line%d", j + 1);

			switch(j) {
			case 0:
				strcpy(default_line, "�i��: %major%-%minor%-%extra%-%id%");
				break;
			case 1:
				strcpy(default_line, "�i��: %name%");
				break;
			case 2:
				strcpy(default_line, "���i: \\%list_price%    �l��: %tataki_flag%");
				break;
			default:
				strcpy(default_line, "");
				break;
			}
			GetPrivateProfileString(section_name, key_name, default_line, line, sizeof(line), config_file_name);
			compile_line(line2, line);
			st_forms[i].lines[j] = String_make(NULL, line2);
		}
	}
}

void Print_finalize(void) {
	int i;

	Debug_assert(st_initialized);
	st_initialized = FALSE;

	for(i = 0; i < st_form_count; i++) {
		int j;

		Memory_free(st_forms[i].name);
		for(j = 0; j < st_forms[i].line_count; j++) {
			Memory_free(st_forms[i].lines[j]);
		}
		Memory_free(st_forms[i].lines);
	}
	Memory_free(st_forms);
}

/* end of file */
