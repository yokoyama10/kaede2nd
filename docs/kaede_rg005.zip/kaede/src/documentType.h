/*
 * file: documentType.h
 * purpose: public header file for Document
 */

#ifndef _PUBLIC_DOCUMENTTYPE_H_INCLUDED
#define _PUBLIC_DOCUMENTTYPE_H_INCLUDED

typedef struct tagDocument *Document;

#endif /* _PUBLIC_DOCUMENTTYPE_H_INCLUDED */
/* end of file */
