/*
 * file: item.c
 * purpose: �X�̏��i���
 */

#include "memory.h"
#include "debug.h"
#include "string.h"

#include "itemP.h"

int Item_seller_id(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->seller_id;
}

void Item_set_seller_id(Item item, int seller_id) {
	Debug_assert(Memory_is_on_heap(item));
	item->seller_id = seller_id;
}

const char *Item_name(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->name;
}

void Item_set_name(Item item, const char *name) {
	Debug_assert(Memory_is_on_heap(item));
	item->name = String_make(item->name, name);
}

const char *Item_comment(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->comment;
}

void Item_set_comment(Item item, const char *comment) {
	Debug_assert(Memory_is_on_heap(item));
	item->comment = String_make(item->comment, comment);
}

int Item_list_price(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->list_price;
}

void Item_set_list_price(Item item, int list_price) {
	Debug_assert(Memory_is_on_heap(item));
	item->list_price = list_price;
}

int Item_real_price(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->real_price;
}

void Item_set_real_price(Item item, int real_price) {
	Debug_assert(Memory_is_on_heap(item));
	item->real_price = real_price;
}

Item_Boolean Item_is_sold(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->is_sold;
}

void Item_set_is_sold(Item item, Item_Boolean is_sold) {
	Debug_assert(Memory_is_on_heap(item));
	item->is_sold = is_sold;
}

Item_Boolean Item_is_returned(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->is_returned;
}

void Item_set_is_returned(Item item, Item_Boolean is_returned) {
	Debug_assert(Memory_is_on_heap(item));
	item->is_returned = is_returned;
}

Item_Boolean Item_is_to_be_returned(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->is_to_be_returned;
}

void Item_set_is_to_be_returned(Item item, Item_Boolean is_to_be_returned) {
	Debug_assert(Memory_is_on_heap(item));
	item->is_to_be_returned = is_to_be_returned;
}

Item_Boolean Item_is_to_be_discounted(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->is_to_be_discounted;
}

void Item_set_is_to_be_discounted(Item item, Item_Boolean is_to_be_discounted) {
	Debug_assert(Memory_is_on_heap(item));
	item->is_to_be_discounted = is_to_be_discounted;
}

int Item_scheduled_date(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->scheduled_date;
}

void Item_set_scheduled_date(Item item, int scheduled_date) {
	Debug_assert(Memory_is_on_heap(item));
	item->scheduled_date = (unsigned char) scheduled_date;
}

Item_Boolean Item_is_by_auction(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->is_by_auction;
}

void Item_set_is_by_auction(Item item, Item_Boolean is_by_auction) {
	Debug_assert(Memory_is_on_heap(item));
	item->is_by_auction = is_by_auction;
}

time_t Item_receipt_time(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->receipt_time;
}

void Item_set_receipt_time(Item item, time_t receipt_time) {
	Debug_assert(Memory_is_on_heap(item));
	item->receipt_time = receipt_time;
}

time_t Item_sold_time(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->sold_time;
}

void Item_set_sold_time(Item item, time_t sold_time) {
	Debug_assert(Memory_is_on_heap(item));
	item->sold_time = sold_time;
}

int Item_refund_rate(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->refund_rate;
}

void Item_set_refund_rate(Item item, int refund_rate) {
	Debug_assert(Memory_is_on_heap(item));
	item->refund_rate = refund_rate;
}

int Item_major_genre(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->major_genre;
}

void Item_set_major_genre(Item item, int major_genre) {
	Debug_assert(Memory_is_on_heap(item));
	item->major_genre = (unsigned char) major_genre;
}

int Item_minor_genre(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->minor_genre;
}

void Item_set_minor_genre(Item item, int minor_genre) {
	Debug_assert(Memory_is_on_heap(item));
	item->minor_genre = (unsigned char) minor_genre;
}

int Item_extra_genre(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->extra_genre;
}

void Item_set_extra_genre(Item item, int extra_genre) {
	Debug_assert(Memory_is_on_heap(item));
	item->extra_genre = (unsigned char) extra_genre;
}

int Item_shape(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	return item->shape;
}

void Item_set_shape(Item item, int shape) {
	Debug_assert(Memory_is_on_heap(item));
	item->shape = (unsigned char) shape;
}

Item Item_create(void) {
	Item item;
	item = Memory_malloc(sizeof(*item));
	item->name = String_make(NULL, "");
	item->comment = String_make(NULL, "");
	return item;
}

void Item_destroy(Item item) {
	Debug_assert(Memory_is_on_heap(item));
	
	Memory_free(item->name);
	Memory_free(item->comment);
	Memory_free(item);
}

#ifdef DEBUG

void Item_p_func(ConstItem item) {
	Debug_assert(Memory_is_on_heap(item));
	
	Debug_printf("\nItem: %p\n", item);
	Debug_printf("name: %s\n", item->name);
	Debug_printf("list_price: %d\n", item->list_price);
	Debug_printf("real_price: %d\n", item->real_price);
	Debug_printf("major_genre: %d\n", item->major_genre);
	Debug_printf("minor_genre: %d\n", item->minor_genre);
	Debug_printf("extra_genre: %d\n", item->extra_genre);
	Debug_printf("comment: %s\n", item->comment);
}
#endif

/* end of file */
