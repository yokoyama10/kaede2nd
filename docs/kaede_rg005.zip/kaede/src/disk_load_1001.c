/*
 * file: disk_load_1001.c
 * purpose: rosa gigantea 001�ō��ꂽ�t�@�C�����J��
 */

#include <string.h>
#include <dbcsstr.h>
#include "debug.h"
#include "seqFile.h"
#include "document.h"
#include "itemList.h"
#include "item.h"
#include "vipList.h"
#include "genreList.h"
#include "shapeList.h"
#include "seller.h"

#include "diskP.h"

static Boolean read_item(SeqFile file, int * id, Item item, GenreList genre_list) {
	char text[256];
	int major_order, minor_order, extra_order;

	*id = SeqFile_read_S32b(file);

	Item_set_seller_id(item, SeqFile_read_S32b(file));

	SeqFile_read_string(file, text, sizeof(text));
	Item_set_name(item, text);
	SeqFile_read_string(file, text, sizeof(text));
	Item_set_comment(item, text);

	Item_set_list_price(item, SeqFile_read_S32b(file));
	Item_set_real_price(item, SeqFile_read_S32b(file));

	major_order = SeqFile_read_S8b(file);
	minor_order = SeqFile_read_S8b(file);
	extra_order = SeqFile_read_S8b(file);
	Item_set_major_genre(item, GenreList_index2tag(genre_list,
				GenreList_TOP, major_order));
	Item_set_minor_genre(item, GenreList_index2tag(genre_list,
				Item_major_genre(item), minor_order));
	Item_set_extra_genre(item, GenreList_index2tag(genre_list,
				Item_minor_genre(item), extra_order));

	Item_set_shape(item, SeqFile_read_S8b(file));

	Item_set_is_sold(item, SeqFile_read_S8b(file));
	Item_set_is_returned(item, SeqFile_read_S8b(file));
	Item_set_is_to_be_returned(item, SeqFile_read_S8b(file));
	Item_set_is_to_be_discounted(item, SeqFile_read_S8b(file));

	Item_set_receipt_time(item, SeqFile_read_U32b(file));
	Item_set_sold_time(item, (time_t) SeqFile_read_U32b(file));

	Item_set_scheduled_date(item, SeqFile_read_S8b(file));
	Item_set_is_by_auction(item, SeqFile_read_S8b(file));

	Item_set_refund_rate(item, SeqFile_read_S32b(file));

	if(SeqFile_is_error(file)) {
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_item_list(SeqFile file, ItemList item_list, GenreList genre_list, Disk_ErrorType * error_type) {
	int i, size;
	Item item;

	size = SeqFile_read_S32b(file);
	if(size < 0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}

	item = Item_create();

	for(i = 0; i < size; i++) {
		int id;

		if(!read_item(file, &id, item, genre_list)) {
			*error_type = Disk_DATA_ERROR;
			Item_destroy(item);
			return FALSE;
		} else {
			ItemList_set(item_list, id, item);
		}
	}

	Item_destroy(item);

	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_vip_list(SeqFile file, VipList vip_list, Disk_ErrorType * error_type) {
	int i, size;

	size = SeqFile_read_S32b(file);
	if(size < 0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}

	for(i = 0; i < size; i++) {
		char name[256];

		SeqFile_read_string(file, name, sizeof(name));
		VipList_set(vip_list, VipList_ID_NEW, name);
	}

	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

static Boolean read_genre_list(SeqFile file, GenreList genre_list, int parent, Disk_ErrorType *error_type) {
	int size;
	int i;

	size = SeqFile_read_S32b(file);
	if(size < 0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}
	for(i = 0; i < size; i++) {
		int genre;
		char text[256];

		genre = GenreList_add(genre_list, parent);
		SeqFile_read_string(file, text, sizeof(text));
		GenreList_set_name(genre_list, genre, text);
		read_genre_list(file, genre_list, genre, error_type);
	}
	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}
	return TRUE;
}

static Boolean read_shape_list(SeqFile file, ShapeList shape_list, Disk_ErrorType * error_type) {
	int i, size;

	size = SeqFile_read_S32b(file);
	if(size<0) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	}

	for(i=0; i<size; i++) {
		char name[256];

		SeqFile_read_string(file, name, sizeof(name));
		ShapeList_set(shape_list, ShapeList_ID_NEW, name);
	}

	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

Boolean dISK_read_1001_file(SeqFile file, Document document, Disk_ErrorType *error_type) {
	/* read obs */
	if(!read_vip_list(file, Document_ob_list(document), error_type)) {
		return FALSE;
	}

	/* read teachers */
	if(!read_vip_list(file, Document_teacher_list(document), error_type)) {
		return FALSE;
	}

	/* read genres */
	if(!read_genre_list(file, Document_genre_list(document), GenreList_TOP, error_type)) {
		return FALSE;
	}

	/* read shapes */
	if(!read_shape_list(file, Document_shape_list(document), error_type)) {
		return FALSE;
	}

	/* read items */
	if(!read_item_list(file, Document_item_list(document),
				Document_genre_list(document), error_type)) {
		return FALSE;
	}

	/* read cash */
	Document_set_cash(document, SeqFile_read_S32b(file));

	/* read refund_rate */
	Document_set_refund_rate(document, SeqFile_read_S32b(file));


	if(SeqFile_is_error(file)) {
		*error_type = Disk_DATA_ERROR;
		return FALSE;
	} else {
		return TRUE;
	}
}

/* end of file */
