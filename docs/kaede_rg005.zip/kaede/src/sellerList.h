/*
 * file: sellerList.h
 * purpose: public header file for SellerList
 */

#ifndef _PUBLIC_SELLERLIST_H_INCLUDED
#define _PUBLIC_SELLERLIST_H_INCLUDED

#include "sellerListType.h"

typedef enum {
	SellerList_TRUE = 1,
	SellerList_FALSE = 0
} SellerList_Boolean;

extern void SellerList_enum(SellerList seller_list, void(*proc)(int id, int refunder, void *param), void *param);
extern void SellerList_set(SellerList seller_list, int id, int refunder);
extern int SellerList_refunder(SellerList seller_list, int id);
extern SellerList_Boolean SellerList_is_including(SellerList seller_list, int id);
extern SellerList SellerList_create(void);
extern void SellerList_destroy(SellerList seller_list);

#endif /* _PUBLIC_SELLERLIST_H_INCLUDED */

/* end of file */
