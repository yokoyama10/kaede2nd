/*
 * file: shapeList.h
 * purpose: public header file for ShapeList
 */

#ifndef _PUBLIC_SHAPELIST_H_INCLUDED
#define _PUBLIC_SHAPELIST_H_INCLUDED

#include "shapeListType.h"

#define ShapeList_ID_NEW (-1)

extern int ShapeList_count(ShapeList shape_list);
extern const char * ShapeList_name(ShapeList shape_list, int id);
extern char *ShapeList_id_text(ShapeList shape_list, int id, char *text);
extern int ShapeList_set(ShapeList shape_list, int id, const char *name);
extern void ShapeList_enum(ShapeList shape_list, void(*proc)(int id, const char *name, void *param), void *param);
extern ShapeList ShapeList_clone(ShapeList shape_list);
extern ShapeList ShapeList_create(void);
extern void ShapeList_destroy(ShapeList shape_list);

#endif /* _PUBLIC_SHAPELIST_H_INCLUDED */

/* end of file */
