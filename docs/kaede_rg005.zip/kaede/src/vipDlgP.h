/*
 * file: vipDlgP.h
 * purpose: private header file for VipDlg
 */

#ifndef _PRIVATE_VIPDLGP_H_INCLUDED
#define _PRIVATE_VIPDLGP_H_INCLUDED

#include "vipPageType.h"

#include "vipDlg.h"

struct tagVipDlg {
	VipPage teacher_page;
	VipPage ob_page;
};

#endif /* _PRIVATE_VIPDLGP_H_INCLUDED */
/* end of file */
