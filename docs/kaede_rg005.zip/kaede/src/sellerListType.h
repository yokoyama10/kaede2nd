/*
 * file: sellerListType.h
 * purpose: public header file for SellerList
 */

#ifndef _PUBLIC_SELLERLISTTYPE_H_INCLUDED
#define _PUBLIC_SELLERLISTTYPE_H_INCLUDED

typedef struct tagSellerList *SellerList;

#endif /* _PUBLIC_SELLERLISTTYPE_H_INCLUDED */

/* end of file */
