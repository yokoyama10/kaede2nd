/*
 * file: itemP.h
 * purpose: private header file for Item
 */

#ifndef _PRIVATE_ITEMP_H_INCLUDED
#define _PRIVATE_ITEMP_H_INCLUDED

#include <time.h>

#include "item.h"

typedef Item_Boolean Boolean;
#undef TRUE
#undef FALSE
#define TRUE Item_TRUE
#define FALSE Item_FALSE

typedef struct tagStudent {
	unsigned char seller_grade;
	unsigned char seller_class;
	unsigned char seller_number;
} Student;

struct tagItem {
	int seller_id;
	char *name;
	char *comment;

	int list_price;
	int real_price;

	unsigned short major_genre;
	unsigned short minor_genre;
	unsigned short extra_genre;
	unsigned short shape;

	Boolean is_sold;
	Boolean is_returned;
	Boolean is_to_be_returned;
	Boolean is_to_be_discounted;

	unsigned char scheduled_date;
	Boolean is_by_auction;

	time_t receipt_time;
	time_t sold_time;

	int refund_rate;
};

#endif /* _PRIVATE_ITEMP_H_INCLUDED */
/* end of file */
