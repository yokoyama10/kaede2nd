/*
 * file: jumpDlg.h
 * purpose: public header file for JumpDlg
 */

#ifndef _PUBLIC_JUMPDLG_H_INCLUDED
#define _PUBLIC_JUMPDLG_H_INCLUDED

#include <windows.h>

typedef enum {
	JumpDlg_HASTE,
	JumpDlg_CALM
} JumpDlg_Mode;

typedef enum {
	JumpDlg_TRUE = 1,
	JumpDlg_FALSE = 0
} JumpDlg_Boolean;

typedef struct tagJumpDlg * JumpDlg;

extern JumpDlg_Boolean JumpDlg_dialogue(JumpDlg dialog, HWND parent_window);
extern int JumpDlg_item_id(JumpDlg dialog);
extern JumpDlg JumpDlg_create(JumpDlg_Mode mode);
extern void JumpDlg_destroy(JumpDlg dialog);

#endif /* _PUBLIC_JUMPDLG_H_INCLUDED */

/* end of file */
