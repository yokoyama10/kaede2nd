/*
 * file: depositDlg.h
 * purpose: public header for DepositDlg
 */

#ifndef _PUBLIC_DEPOSITDLG_H_INCLUDED
#define _PUBLIC_DEPOSITDLG_H_INCLUDED

#include <windows.h>

typedef struct tagDepositDlg *DepositDlg;

typedef enum {
	DepositDlg_TRUE = 1,
	DepositDlg_FALSE = 0
} DepositDlg_Boolean;


extern DepositDlg_Boolean DepositDlg_dialogue(DepositDlg dialog, HWND parent_window);
extern int DepositDlg_cash(DepositDlg dialog);
extern DepositDlg DepositDlg_create(int default_cash);
extern void DepositDlg_destroy(DepositDlg dialog);

#endif /* _PUBLIC_DEPOSITDLG_H_INCLUDED */

/* end of file */
