/*
 * file: sellerListP.h
 * purpose: private header file for SellerList
 */

#ifndef _PRIVATE_SELLERLISTP_H_INCLUDED
#define _PRIVATE_SELLERLISTP_H_INCLUDED

#include "dictionaryType.h"

#include "sellerList.h"

struct tagSellerList {
	Dictionary dictionary;
};

#endif /* _PRIVATE_SELLERLISTP_H_INCLUDED */

/* end of file */
