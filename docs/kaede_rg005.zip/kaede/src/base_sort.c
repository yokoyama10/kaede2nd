/*
 * file: base_sort.c
 * purpose: �\�[�g�֌W�̏����B�c��ɂȂ��Ă����̂ŁB
 */

#include <windows.h>
#include <commctrl.h>
#include <string.h>
#include <dbcsstr.h>
#include <stdio.h>
#include "document.h"
#include "itemList.h"
#include "item.h"

#include "baseP.h"

static int compare_genre(ConstItem first, ConstItem second) {
	if(Item_major_genre(first) != Item_major_genre(second)) {
		return Item_major_genre(first) - Item_major_genre(second);
	}
	if(Item_minor_genre(first) != Item_minor_genre(second)) {
		return Item_minor_genre(first) - Item_minor_genre(second);
	}
	return Item_extra_genre(first) - Item_extra_genre(second);
}

typedef struct {
	Base base;
	int column_id;
	Base_Boolean is_ascending;
} Sort;

static int CALLBACK compare_item(LPARAM param_1, LPARAM param_2, LPARAM param_ext) {
	Sort * sort;
	ConstItem first, second;
	int result;

	if(param_1 == NIL_ITEM) {
		return 1;
	} else if(param_2 == NIL_ITEM) {
		return -1;
	}
	sort = (Sort *) param_ext;
	first = ItemList_item(Document_item_list(sort->base->document), param_1);
	second = ItemList_item(Document_item_list(sort->base->document), param_2);


	switch(sort->column_id) {
	case ID_ITEM_ID:
		result = param_1 - param_2;
		break;
	case ID_SELLER:
		result = Item_seller_id(first) - Item_seller_id(second);
		break;
	case ID_ITEM_NAME:
		result = stricmp(Item_name(first), Item_name(second));
		break;
	case ID_IS_TO_BE_RETURNED:
		result = Item_is_to_be_returned(first) - Item_is_to_be_returned(second);
		break;
	case ID_IS_TO_BE_DISCOUNTED:
		result = Item_is_to_be_discounted(first) - Item_is_to_be_discounted(second);
		break;
	case ID_LIST_PRICE:
		result = Item_list_price(first) - Item_list_price(second);
		break;
	case ID_GENRE:
		result = compare_genre(first, second);
		break;
	case ID_SHAPE:
		result = Item_shape(first) - Item_shape(second);
		break;
	case ID_RECEIPT_TIME:
		result = Item_receipt_time(first) - Item_receipt_time(second);
		break;
	case ID_SCHEDULED_DATE:
		result = Item_scheduled_date(first) - Item_scheduled_date(second);
		break;
	case ID_COMMENT:
		result = stricmp(Item_comment(first), Item_comment(second));
		break;
	case ID_IS_SOLD:
		result = Item_is_sold(first) - Item_is_sold(second);
		break;
	case ID_SOLD_TIME:
		if(Item_is_sold(first) != Item_is_sold(second)) {
			result = Item_is_sold(first) - Item_is_sold(second);
		} else if(Item_is_sold(first) /* && Item_is_sold(second) */ ) {
			result = Item_sold_time(first) - Item_sold_time(second);
		} else /* !Item_is_sold(first) && !Item_is_sold(second) */ {
			result = 0;
		}
		break;
	case ID_REAL_PRICE:
		if(Item_is_sold(first) != Item_is_sold(second)) {
			result = Item_is_sold(first) - Item_is_sold(second);
		} else if(Item_is_sold(first) /* && Item_is_sold(second) */ ) {
			result = Item_real_price(first) - Item_real_price(second);
		} else /* !Item_is_sold(first) && !Item_is_sold(second) */ {
			result = 0;
		}
		break;
	case ID_IS_BY_AUCTION:
		result = Item_is_by_auction(first) - Item_is_by_auction(second);
		break;
	case ID_REFUND_RATE:
		result = Item_refund_rate(first) - Item_refund_rate(second);
		break;
	default:
		return 0;
	}

	if(sort->is_ascending) {
		return result;
	} else {
		if(result > 0) {
			return -1;
		} else if(result < 0) {
			return 1;
		} else {
			return 0;
		}
	}
}

void bASE_sort(Base base, int column_id) {
	int i;
	Sort sort;

	for(i = 0; ; i++) {
		if(base->sort_directions[i].column_id == column_id) {
			break;
		}
	}

	sort.is_ascending = base->sort_directions[i].ascend_flag;
	sort.column_id = column_id;
	sort.base = base;
	ListView_SortItems(base->list_window, compare_item, (LPARAM)&sort);
	base->sort_directions[i].ascend_flag = base->sort_directions[i].ascend_flag ? Base_FALSE : Base_TRUE;
}

/* end of file */
