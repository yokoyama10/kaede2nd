/*
 * file: checkitMenuP.h
 * purpose: private header file for CheckitMenu
 */

#ifndef _PRIVATE_CHECKITMENUP_H_INCLUDED
#define _PRIVATE_CHECKITMENUP_H_INCLUDED

#include "checkitMenu.h"


#undef TRUE
#undef FALSE
#define TRUE CheckitMenu_TRUE
#define FALSE CheckitMenu_FALSE
typedef CheckitMenu_Boolean Boolean;


#endif /* _PRIVATE_CHECKITMENUP_H_INCLUDED */
/* end of file */
