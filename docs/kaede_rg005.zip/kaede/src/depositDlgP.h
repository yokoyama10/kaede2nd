/*
 * file: depositDlgP.h
 * purpose: private header file for DepositDlg
 */

#ifndef _PRIVATE_DEPOSITDLGP_H_INCLUDED
#define _PRIVATE_DEPOSITDLGP_H_INCLUDED

#include "depositDlg.h"

#define IDD_DEPOSIT 1013

#define IDC_AMOUNT_OF_MONEY 101

#define IDS_DEFECT 1701

struct tagDepositDlg {
	HWND window;
	int cash;
};

#endif /* _PRIVATE_DEPOSITDLGP_H_INCLUDED */

/* end of file */
