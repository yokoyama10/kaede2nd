/*
 * file: seqFile.c
 * purpose: �V�[�P���V�����t�@�C������
 */

#include <stdio.h>
#include "memory.h"
#include "debug.h"

#include "seqFileP.h"

#define update_not_crc(not_crc, data) (st_crc_table[((not_crc) ^ (data)) & 0xff] ^ ((not_crc) >> 8))

static Boolean st_is_crc_table_created = FALSE;
static U32b st_crc_table[256];

static Byte read_byte(SeqFile file) {
	Byte data;

	data = (Byte)getc(file->file_pointer);
	file->not_crc = update_not_crc(file->not_crc, data);
	return data;
}

SeqFile_U8b SeqFile_read_U8b(SeqFile file) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_READ);

	return read_byte(file);
}

SeqFile_U16b SeqFile_read_U16b(SeqFile file) {
	U16b d0, d1;

	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode==SeqFile_READ);

	d0 = (U16b)read_byte(file);
	d1 = (U16b)read_byte(file);
	return (d0 | (d1 << 8));
}

SeqFile_U32b SeqFile_read_U32b(SeqFile file) {
	U32b d0, d1, d2, d3;

	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_READ);

	d0 = (U32b) read_byte(file);
	d1 = (U32b) read_byte(file);
	d2 = (U32b) read_byte(file);
	d3 = (U32b) read_byte(file);
	return (d0 | (d1 << 8) | (d2 << 16) | (d3 << 24));
}

SeqFile_S8b SeqFile_read_S8b(SeqFile file) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_READ);
	return (S8b)SeqFile_read_U8b(file);
}

SeqFile_S16b SeqFile_read_S16b(SeqFile file) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_READ);
	return (S16b)SeqFile_read_U16b(file);
}

SeqFile_S32b SeqFile_read_S32b(SeqFile file) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_READ);
	return (S32b)SeqFile_read_U32b(file);
}

void SeqFile_read_string(SeqFile file, char *text, int max_size) {
	int i;

	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(text != NULL);
	Debug_assert(file->mode == SeqFile_READ);

	i = 0;
	do {
		if(i >= max_size) {
			goto over_size;
		}
		text[i] = (char) read_byte(file);
		i++;
	} while(text[i - 1]);
	return;
over_size:
	text[0] = 0;
	file->is_error = TRUE;
}

static void write_byte(SeqFile file, Byte data) {
	file->not_crc = update_not_crc(file->not_crc, data);
	putc((int) data, file->file_pointer);
}

void SeqFile_write_U8b(SeqFile file, SeqFile_U8b data) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_WRITE);

	write_byte(file, data);
}

void SeqFile_write_U16b(SeqFile file, SeqFile_U16b data) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_WRITE);

	write_byte(file, (Byte)data);
	write_byte(file, (Byte)(data >> 8));
}

void SeqFile_write_U32b(SeqFile file, SeqFile_U32b data) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_WRITE);

	write_byte(file, (Byte)data);
	write_byte(file, (Byte)(data >> 8));
	write_byte(file, (Byte)(data >> 16));
	write_byte(file, (Byte)(data >> 24));
}

void SeqFile_write_S8b(SeqFile file, SeqFile_S8b data) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_WRITE);
	SeqFile_write_U8b(file, (Byte)data);
}

void SeqFile_write_S16b(SeqFile file, SeqFile_S16b data) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_WRITE);
	SeqFile_write_U16b(file, (U16b)data);
}

void SeqFile_write_S32b(SeqFile file, SeqFile_S32b data) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_WRITE);
	SeqFile_write_U32b(file, (U32b)data);
}

void SeqFile_write_string(SeqFile file, const char *text) {
	int i;

	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_WRITE);


	if(text == NULL) {
		write_byte(file, (Byte)0);
	} else {
		i = 0;
		do {
			write_byte(file, (Byte) text[i]);
			i++;
		} while(text[i - 1]);
	}
}

SeqFile_U32b SeqFile_crc(SeqFile file) {
	return ~file->not_crc;
}

long SeqFile_position(SeqFile file) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	return ftell(file->file_pointer);
}

SeqFile_Boolean SeqFile_is_error(SeqFile file) {
	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	if(file->is_error) {
		return SeqFile_TRUE;
	}
	if(feof(file->file_pointer)) {
		return SeqFile_TRUE;
	}
	if(ferror(file->file_pointer)) {
		return SeqFile_TRUE;
	}
	return SeqFile_FALSE;
}

SeqFile_Boolean SeqFile_is_reading_completed(SeqFile file) {
	long current_position, end_position;

	Debug_assert(Memory_is_on_heap(file));
	Debug_assert(file->file_pointer != NULL);
	Debug_assert(file->mode == SeqFile_READ);

	current_position = ftell(file->file_pointer);
	fseek(file->file_pointer, 0L, SEEK_END);
	end_position = ftell(file->file_pointer);
	fseek(file->file_pointer, current_position, SEEK_SET);
	return current_position == end_position ? SeqFile_TRUE : SeqFile_FALSE;
}

static void make_crc_table(void) {
	U32b c;
	int n, k;

	for(n = 0; n < 256; n++) {
		c = (U32b)n;
		for(k = 0; k < 8; k++) {
			if(c & 1) {
				c = 0xedb88320L ^ (c >> 1);
			} else {
				c = c >> 1;
			}
		}
		st_crc_table[n] = c;
	}
}

SeqFile SeqFile_create(const char *path, SeqFile_Mode mode) {
	SeqFile file;

	if(st_is_crc_table_created == FALSE) {
		st_is_crc_table_created = TRUE;
		make_crc_table();
	}

	file = Memory_malloc(sizeof(*file));

	file->not_crc = 0xffffffffL;
	file->mode = mode;
	file->is_error = FALSE;

	switch(file->mode) {
	case SeqFile_READ:
		file->file_pointer = fopen(path, "rb");
		break;
	case SeqFile_WRITE:
		file->file_pointer = fopen(path, "wb");
		break;
	}

	if(file->file_pointer == NULL) {
		SeqFile_destroy(file);
		return NULL;
	} else {
		return file;
	}
}

void SeqFile_destroy(SeqFile file) {
	Debug_assert(Memory_is_on_heap(file));
	if(file->file_pointer != NULL) {
		fclose(file->file_pointer);
	}
	Memory_free(file);
}

/* end of file */
