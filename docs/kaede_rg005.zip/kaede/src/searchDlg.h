/*
 * file: searchDlg.h
 * purpose: public header file for SearchDlg
 */

#ifndef _PUBLIC_SEARCHDLG_H_INCLUDED
#define _PUBLIC_SEARCHDLG_H_INCLUDED

#include <windows.h>

typedef enum {
	SearchDlg_TRUE = 1,
	SearchDlg_FALSE = 0
} SearchDlg_Boolean;


typedef struct tagSearchDlg *SearchDlg;

extern SearchDlg_Boolean SearchDlg_dialogue(SearchDlg dialog, HWND parent_window);
extern const char *SearchDlg_item_name(SearchDlg dialog);
extern SearchDlg SearchDlg_create(const char *item_name);
extern void SearchDlg_destroy(SearchDlg dialog);

#endif /* _PUBLIC_SEARCHDLG_H_INCLUDED */

/* end of file */
