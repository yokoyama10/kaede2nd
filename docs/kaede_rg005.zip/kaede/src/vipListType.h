/*
 * file: vipListType.h
 * purpose: public header file for VipList
 */

#ifndef _PUBLIC_VIPLISTTYPE_H_INCLUDED
#define _PUBLIC_VIPLISTTYPE_H_INCLUDED

typedef struct tagVipList *VipList;

#endif /* _PUBLIC_VIPLISTTYPE_H_INCLUDED */

/* end of file */
