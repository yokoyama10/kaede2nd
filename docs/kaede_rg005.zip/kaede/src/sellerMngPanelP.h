/*
 * file: sellerMngPanelP.h
 * purpose: private header file for SellerMngPanel
 */

#ifndef _PRIVATE_SELLERMNGPANELP_H_INCLUDED
#define _PRIVATE_SELLERMNGPANELP_H_INCLUDED

#include <windows.h>
#include "baseType.h"
#include "sellerListType.h"
#include "documentType.h"

#include "sellerMngPanel.h"

#define SELLER_MNG_PANEL_CLASS_NAME "kaede_seller_mng_panel"

#define ID_LIST_VIEW 1

typedef struct tagSeller {
	int id;
	int refund;
} Seller;

struct tagSellerMngPanel {
	HWND window;
	HWND list_window;

	SellerList seller_list;
	Base base;
	Document document;
};

#endif /* _PRIVATE_SELLERMNGPANELP_H_INCLUDED */

/* end of file */
