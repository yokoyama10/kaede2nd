/*
 * file: vipList.h
 * purpose: public header file for VipList
 */

#ifndef _PUBLIC_VIPLIST_H_INCLUDED
#define _PUBLIC_VIPLIST_H_INCLUDED

#include "vipListType.h"

#define VipList_ID_NEW (-1)

extern int VipList_count(VipList vip_list);
extern const char *VipList_name(VipList vip_list, int id);
extern int VipList_set(VipList vip_list, int id, const char *name);
extern void VipList_enum(VipList vip_list, void(*proc)(int id, const char *name, void *param), void *param);
extern VipList VipList_clone(VipList vip_list);
extern VipList VipList_create(void);
extern void VipList_destroy(VipList vip_list);

#endif /* _PUBLIC_VIPLIST_H_INCLUDED */

/* end of file */
