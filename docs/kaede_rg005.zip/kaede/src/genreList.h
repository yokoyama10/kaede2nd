/*
 * file: genreList.h
 * purpose: public header file for GenreList
 */

#ifndef _PUBLIC_GENRE_H_INCLUDED
#define _PUBLIC_GENRE_H_INCLUDED

#include "genreListType.h"

#define GenreList_NIL (-2)
#define GenreList_TOP (-1)
#define GenreList_UNDEFINED 0

typedef enum {
	GenreList_TRUE = 1,
	GenreList_FALSE = 0
} GenreList_Boolean;

extern GenreList_Boolean GenreList_including(ConstGenreList genre_list, int tag);
extern int GenreList_count_all(ConstGenreList genre_list);
extern void GenreList_enum_all(ConstGenreList genre_list, void (*proc)(int tag, void *param), void *param);
extern void GenreList_enum(ConstGenreList genre_list, int parent, void (*proc)(int tag, void *param), void *param);
extern int GenreList_parent(ConstGenreList genre_list, int tag);
extern int GenreList_index2tag(ConstGenreList genre_list, int parent, int index);
extern int GenreList_index(ConstGenreList genre_list, int tag);
extern const char *GenreList_order_text(ConstGenreList genre_list, int tag, char *text);
extern int GenreList_order(ConstGenreList genre_list, int tag);
extern const char *GenreList_name(ConstGenreList genre_list, int tag);
extern void GenreList_set_name(GenreList genre_list, int tag, const char *name);
extern void GenreList_delete(GenreList genre_list, int tag);
extern int GenreList_add(GenreList genre_list, int parent);
extern void GenreList_insert(GenreList genre_list, int tag, int parent, int order, const char *name);
extern void GenreList_clear(GenreList genre_list);
extern GenreList GenreList_clone(ConstGenreList genre_list);
extern GenreList GenreList_create(void);
extern void GenreList_destroy(GenreList genre_list);

#endif /* _PUBLIC_GENRE_H_INCLUDED */
/* end of file */
