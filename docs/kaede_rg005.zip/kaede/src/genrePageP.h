/*
 * file: genrePageP.h
 * purpose: private header file for GenrePage
 */

#ifndef _PRIVATE_GENREPAGEP_H_INCLUDED
#define _PRIVATE_GENREPAGEP_H_INCLUDED

#include "genreListType.h"

#include "genrePage.h"


#define IDD_GENRE_PAGE 1007

#define IDC_GENRE_NAME 101
#define IDC_GENRES_TREE 102
#define IDC_APPEND_GENRE 103
#define IDC_DELETE_GENRE 104
#define IDC_CLEAR_ALL_GENRE 105

#define IDS_ASK_CLEAR 1601
#define IDS_ASK_CLEAR_AGAIN 1602

#undef TRUE
#undef FALSE
#define TRUE GenrePage_TRUE
#define FALSE GenrePage_FALSE

typedef GenrePage_Boolean Boolean;

struct tagGenrePage {
	GenreList genre_list;
	ItemList item_list;
	Boolean is_genre_name_changed;
	Boolean is_applied;
	Boolean is_cleared;
	HWND window;
	struct {
		HWND genres;
		HWND append;
		HWND delete;
	} ctrls;
};

#endif /* _PRIVATE_GENREPAGEP_H_INCLUDED */

/* end of file */
