/*
 * file: vipList.c
 * purpose: ���炢����̃��X�g
 */

#include "memory.h"
#include "debug.h"
#include "string.h"

#include "vipListP.h"

int VipList_count(VipList vip_list) {
	Debug_assert(Memory_is_on_heap(vip_list));
	
	return vip_list->count;
}

const char *VipList_name(VipList vip_list, int id) {
	Debug_assert(Memory_is_on_heap(vip_list));
	Debug_assert(id >= 1 && id <= vip_list->count);
	
	return vip_list->names[id - 1];
}

int VipList_set(VipList vip_list, int id, const char *name) {
	int result_id;
	
	Debug_assert(Memory_is_on_heap(vip_list));
	Debug_assert(id == VipList_ID_NEW || (id >= 1 && id <= vip_list->count));
	
	if(id == VipList_ID_NEW) {
		vip_list->names = Memory_realloc(vip_list->names,
				sizeof(*vip_list->names) * (vip_list->count + 1));
		vip_list->names[vip_list->count] = String_make(NULL, name);
		vip_list->count += 1;
		result_id = vip_list->count;
	} else {
		vip_list->names[id - 1] = String_make(vip_list->names[id - 1], name);
		result_id = id;
	}
	return result_id;
}

void VipList_enum(VipList vip_list, void(*proc)(int id, const char *name, void *param), void *param) {
	int i;
	
	Debug_assert(Memory_is_on_heap(vip_list));
	
	for(i = 0; i < vip_list->count; i++) {
		proc(i + 1, vip_list->names[i], param);
	}
}

static void copy_data(VipList dest, VipList src) {
	int i;
	
	dest->names = Memory_realloc(dest->names, sizeof(*dest->names)*src->count);
	for(i = 0; i < src->count; i++) {
		dest->names[i] = String_make(NULL, src->names[i]);
	}
	dest->count = src->count;
}

VipList VipList_clone(VipList vip_list) {
	VipList clone;
	
	clone = VipList_create();
	copy_data(clone, vip_list);
	return clone;
}

VipList VipList_create(void) {
	VipList vip_list;
	
	vip_list = Memory_malloc(sizeof(*vip_list));
	vip_list->names = NULL;
	vip_list->count = 0;
	return vip_list;
}

void VipList_destroy(VipList vip_list) {
	int i;
	
	Debug_assert(Memory_is_on_heap(vip_list));
	
	for(i = 0; i<vip_list->count; i++) {
		Memory_free(vip_list->names[i]);
	}
	Memory_free(vip_list->names);
	Memory_free(vip_list);
}

/* end of file */
