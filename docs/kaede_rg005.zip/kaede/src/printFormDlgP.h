/*
 * file: printFormDlgP.h
 * purpose: private header file for PrintFormDlg
 */

#ifndef _PRIVATE_PRINTFORMDLGP_H_INCLUDED
#define _PRIVATE_PRINTFORMDLGP_H_INCLUDED

#include "printFormDlg.h"

#define IDD_PRINT_FORM 1012

#define IDC_FORMS 101

struct tagPrintFormDlg {
	HWND window;
	int form_count;
	const char * const * form_names;
	int index;

	struct {
		HWND forms;
	} ctrls;
};


#endif /* _PRIVATE_PRINTFORMDLGP_H_INCLUDED */

/* end of file */
