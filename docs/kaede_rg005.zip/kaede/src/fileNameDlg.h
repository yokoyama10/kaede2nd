/*
 * file: fileNameDlg.h
 * purpose: public header file for FileNameDlg.h
 */

#ifndef _PUBLIC_FILENAMEDLG_H_INCLUDED
#define _PUBLIC_FILENAMEDLG_H_INCLUDED

#include <windows.h>

typedef struct tagFileNameDlg *FileNameDlg;
typedef enum {
	FileNameDlg_TRUE = 1,
	FileNameDlg_FALSE = 0
} FileNameDlg_Boolean;

typedef enum {
	FileNameDlg_SAVE,
	FileNameDlg_LOAD
} FileNameDlg_Mode;

extern const char *FileNameDlg_file_name(FileNameDlg dialog);
extern FileNameDlg_Boolean FileNameDlg_dialogue(FileNameDlg dialog, HWND parent_window);
extern FileNameDlg FileNameDlg_create(const char *default_path, const char *extension, const char *type_name, FileNameDlg_Mode mode);
extern void FileNameDlg_destroy(FileNameDlg dialog);

#endif /* _PUBLIC_FILENAMEDLG_H_INCLUDED */
/* end of file */
