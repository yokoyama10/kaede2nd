/*
 * file: shapePageType.h
 * purpose: public header file for ShapePage
 */

#ifndef _PUBLIC_SHAPEPAGETYPE_H_INCLUDED
#define _PUBLIC_SHAPEPAGETYPE_H_INCLUDED

typedef struct tagShapePage *ShapePage;

#endif /* _PUBLIC_SHAPEPAGETYPE_H_INCLUDED */

/* end of file */
