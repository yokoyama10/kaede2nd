/*
 * file: string.c
 * purpose: ������B����@�\�B
 */

#include <string.h>
#include <dbcsstr.h>
#include "memory.h"
#include "debug.h"

#include "stringP.h"

#ifdef DEBUG
char *String_make(char *block, const char *src) {
	char *new_block;
	
	
	if(src == NULL) {
		new_block = Memory_malloc(1);
		new_block[0] = '\0';
	} else {
		new_block = Memory_malloc(strlen(src) + 1);
		strcpy(new_block, src);
	}
	Memory_free(block);
	return new_block;
}
#else
char *String_make(char *block, const char *src) {
	char *new_block;
	
	if(src == NULL) {
		new_block = Memory_realloc(block, 1);
		new_block[0] = '\0';
	} else {
		new_block = Memory_realloc(block, strlen(src) + 1);
		strcpy(new_block, src);
	}
	return new_block;
}
#endif

/* end of file */
