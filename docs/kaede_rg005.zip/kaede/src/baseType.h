/*
 * file: base_Type.h
 * purpose public header file for Base
 */

#ifndef _PUBLIC_BASETYPE_H_INCLUDED
#define _PUBLIC_BASETYPE_H_INCLUDED

typedef struct tagBase *Base;

#endif /* _PUBLIC_BASETYPE_H_INCLUDED */

/* end of file */
