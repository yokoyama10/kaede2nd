/*
 * file: winmain.c
 * purpose: WinMain�֐��B
 */

#include <windows.h>
#include "debug.h"
#include "memory.h"
#include "base.h"

int PASCAL WinMain(HINSTANCE instance, HINSTANCE prev_instance, LPSTR command_line, int n_cmd_show) {
	Base base;
	int ret_value;
	
	Debug_initialize();
	Memory_initialize();
	
	base = Base_create();
	ret_value = Base_main(base, instance, n_cmd_show);
	Base_destroy(base);
	
	Memory_finalize();
	Debug_finalize();
	return ret_value;
}

/* end of file */
