/*
 * file: shapeList.c
 * purpose: �`��̃��X�g
 */

#include <string.h>
#include "debug.h"
#include "memory.h"
#include "string.h"

#include "shapeListP.h"

int ShapeList_count(ShapeList shape_list) {
	Debug_assert(Memory_is_on_heap(shape_list));

	return shape_list->count;
}

const char * ShapeList_name(ShapeList shape_list, int id) {
	Debug_assert(Memory_is_on_heap(shape_list));
	Debug_assert(id >= 0 && id <= shape_list->count);
	if(id == 0) {
		return "����";
	}
	return shape_list->names[id - 1];
}

char *ShapeList_id_text(ShapeList shape_list, int id, char *text) {
	Debug_assert(Memory_is_on_heap(shape_list));
	Debug_assert(id >= 0 && id <= shape_list->count);
	if(id == 0) {
		strcpy(text, "*");
	}
	id = (id - 1) % 52 + 1;
	if(id <= 26) {
		text[0] = 'a' - 1 + id;
	} else {
		text[0] = 'A' - 1 + id - 26;
	}
	text[1] = '\0';
	return text;
}

int ShapeList_set(ShapeList shape_list, int id, const char *name) {
	int result_id;

	Debug_assert(Memory_is_on_heap(shape_list));
	Debug_assert(id == ShapeList_ID_NEW || (id >= 1 && id <= shape_list->count));

	if(id == ShapeList_ID_NEW) {
		shape_list->names = Memory_realloc(shape_list->names, sizeof(*shape_list->names) * (shape_list->count + 1));
		shape_list->names[shape_list->count] = String_make(NULL, name);
		shape_list->count += 1;
		result_id = shape_list->count;
	} else {
		shape_list->names[id - 1] = String_make(shape_list->names[id - 1], name);
		result_id = id;
	}
	return result_id;
}

void ShapeList_enum(ShapeList shape_list, void(*proc)(int id, const char *name, void *param), void *param) {
	int i;

	Debug_assert(Memory_is_on_heap(shape_list));

	for(i = 0; i < shape_list->count; i++) {
		proc(i + 1, shape_list->names[i], param);
	}
}

static void copy_data(ShapeList dest, ShapeList src) {
	int i;

	dest->names = Memory_realloc(dest->names, sizeof(*dest->names) * src->count);
	for(i = 0; i < src->count; i++) {
		dest->names[i] = String_make(NULL, src->names[i]);
	}
	dest->count = src->count;
}

ShapeList ShapeList_clone(ShapeList shape_list) {
	ShapeList clone;

	clone = ShapeList_create();
	copy_data(clone, shape_list);
	return clone;
}

ShapeList ShapeList_create(void) {
	ShapeList shape_list;

	shape_list = Memory_malloc(sizeof(*shape_list));
	shape_list->names = NULL;
	shape_list->count = 0;
	return shape_list;
}

void ShapeList_destroy(ShapeList shape_list) {
	int i;

	Debug_assert(Memory_is_on_heap(shape_list));

	for(i = 0; i < shape_list->count; i++) {
		Memory_free(shape_list->names[i]);
	}
	Memory_free(shape_list->names);

	Memory_free(shape_list);
}

/* end of file */
