/*
 * file: itemDlg.c
 * purpose: ���i�����̓_�C�A���O�̕\��
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <dbcsstr.h>
#include <time.h>
#include "itemList.h"
#include "shapeList.h"
#include "vipList.h"
#include "genreList.h"
#include "application.h"
#include "debug.h"
#include "base.h"
#include "memory.h"
#include "item.h"
#include "document.h"
#include "seller.h"

#include "itemDlgP.h"

#define TOUCH(a) ((void)(a))


static Boolean make_student_id(int *seller_id, const char *grade_txt, const char *class_txt, const char *number_txt) {
	int hoge;
	int grade, class, number;

	if(strlen(class_txt) != 1) {
		return FALSE;
	} else if('1' <= class_txt[0] && class_txt[0] <= '4') {
		class = class_txt[0] - '0';
		grade = grade_txt[0] - '0' + 3;
	} else if('a' <= class_txt[0] && class_txt[0] <= 'c') {
		class = class_txt[0] - 'a' + 1;
		grade = grade_txt[0] - '0';
	} else if('A' <= class_txt[0] && class_txt[0] <= 'C') {
		class = class_txt[0] - 'A' + 1;
		grade = grade_txt[0] - '0';
	} else {
		return FALSE;
	}

	if(sscanf(number_txt, "%d", &number) != 1) {
		return FALSE;
	}
	*seller_id = Seller_make_student_id(grade, class, number);
	return TRUE;
}

static int make_seller_id(const char *grade, const char *class, const char *number, int vip_id) {
	int seller_id;
	Seller_Type seller_type;

	if(stricmp(grade, TEXT_OB) == 0) {
		seller_type = Seller_OB;
	} else if(stricmp(grade, TEXT_TEACHER) == 0) {
		seller_type = Seller_TEACHER;
	} else if(stricmp(grade, TEXT_LEGACY) == 0) {
		seller_type = Seller_LEGACY;
	} else if(stricmp(grade, TEXT_DONATION) == 0) {
		seller_type = Seller_DONATION;
	} else if(strlen(grade) == 1 && grade[0] >= '1' && grade[0] <= '3') {
		seller_type = Seller_STUDENT;
	} else {
		return -1;
	}

	/* �S�ɎK�т��Ď��Ȃ����̓��̌��t�� */
	switch(seller_type) {
	case Seller_STUDENT:
		if(!make_student_id(&seller_id, grade, class, number)) {
			return -1;
		}
		break;
	case Seller_OB:
		if(vip_id == CB_ERR + 1) {
			return -1;
		} else {
			seller_id = Seller_make_ob_id(vip_id);
		}
		break;
	case Seller_TEACHER:
		if(vip_id == CB_ERR + 1) {
			return -1;
		} else {
			seller_id = Seller_make_teacher_id(vip_id);
		}
		break;
	case Seller_DONATION:
		seller_id = Seller_make_donation_id();
		break;
	case Seller_LEGACY:
		seller_id = Seller_make_legacy_id();
		break;
	}
	return seller_id;
}

static Boolean get_data(ItemDlg dialog, Item item) {
	char text_grade[32], text_class[32], text_number[32];
	char text[128];
	int temp;
	BOOL is_translated;
	UINT check_flag;
	int index;
	int seller_id;
	ConstGenreList genre_list;

	/* get �w�N�N���X�ԍ����O */
	GetDlgItemText(dialog->window, IDC_SELLER_GRADE, text_grade, sizeof(text_grade) - 1);
	GetDlgItemText(dialog->window, IDC_SELLER_CLASS, text_class, sizeof(text_class) - 1);
	GetDlgItemText(dialog->window, IDC_SELLER_NUMBER, text_number, sizeof(text_number) - 1);
	index = SendMessage(dialog->ctrls.seller_name, CB_GETCURSEL, 0, 0);

	seller_id = make_seller_id(text_grade, text_class, text_number, index+1);
	if(seller_id == -1) {
		return FALSE;
	} else {
		Item_set_seller_id(item, seller_id);
	}

	/* get ���i�� */
	GetDlgItemText(dialog->window, IDC_ITEM_NAME, text, sizeof(text) - 1);
	if(strlen(text) == 0) {
		return FALSE;
	} else {
		Item_set_name(item, text);
	}

	/* get ��]���i */
	temp = GetDlgItemInt(dialog->window, IDC_LIST_PRICE, &is_translated, FALSE);
	if(!is_translated) {
		return FALSE;
	} else {
		Item_set_list_price(item, temp);
	}

	/* get �ԕi�t���O */
	check_flag = IsDlgButtonChecked(dialog->window, IDC_IS_TO_BE_RETURNED);
	if(check_flag == BST_CHECKED) {
		Item_set_is_to_be_returned(item, Item_TRUE);
	} else {
		Item_set_is_to_be_returned(item, Item_FALSE);
	}

	/* get �@���t���O */
	check_flag = IsDlgButtonChecked(dialog->window, IDC_IS_TO_BE_DISCOUNTED);
	if(check_flag == BST_CHECKED) {
		Item_set_is_to_be_discounted(item, Item_TRUE);
	} else {
		if(!Item_is_to_be_returned(item)) {
			return FALSE;
		} else {
			Item_set_is_to_be_discounted(item, Item_FALSE);
		}
	}

	/* get ���ꂽ?�t���O�Ǝ������i */
	check_flag = IsDlgButtonChecked(dialog->window, IDC_IS_SOLD);
	if(check_flag == BST_CHECKED) {
		ConstItem org_item;

		org_item = ItemList_item(Document_item_list(dialog->document), dialog->item_id);

		Item_set_is_sold(item, Item_TRUE);
		temp = GetDlgItemInt(dialog->window, IDC_REAL_PRICE, &is_translated, FALSE);
		if(!is_translated) {
			return FALSE;
		} else if(!Item_is_to_be_discounted(org_item) && temp < Item_list_price(org_item)) {
			/* �@���t���O���Ȃ��̂ɒ@�����炩�� */
			return FALSE;
		} else if(dialog->is_book && temp > Item_list_price(org_item)) {
			/* �Ö{����ł́A�艿��荂�����邱�Ƃ͂Ȃ� */
			return FALSE;
		}

		Item_set_real_price(item, temp);

		if(!Item_is_sold(org_item)) {
			Item_set_sold_time(item, time(NULL));
		} else {
			Item_set_sold_time(item, Item_sold_time(org_item));
		}
	} else {
		Item_set_is_sold(item, Item_FALSE);
	}

	genre_list = Document_genre_list(dialog->document);
	/* get major genre */
	Item_set_major_genre(item,
			GenreList_index2tag(genre_list, GenreList_TOP,
				SendMessage(dialog->ctrls.major_genres, CB_GETCURSEL, 0, 0)));

	/* get minor genre */
	Item_set_minor_genre(item,
			GenreList_index2tag(genre_list, Item_major_genre(item),
				SendMessage(dialog->ctrls.minor_genres, CB_GETCURSEL, 0, 0)));

	/* get extra genre */
	Item_set_extra_genre(item,
			GenreList_index2tag(genre_list, Item_minor_genre(item),
				SendMessage(dialog->ctrls.extra_genres, CB_GETCURSEL, 0, 0)));

	/* get shape */
	Item_set_shape(item, SendMessage(dialog->ctrls.shapes, CB_GETCURSEL, 0, 0));


	/* get scheduled date */
	if(IsDlgButtonChecked(dialog->window, IDC_SCHEDULE_UNDEFINED)) {
		Item_set_scheduled_date(item, 0);
	} else if (IsDlgButtonChecked(dialog->window, IDC_SCHEDULE_1)) {
		Item_set_scheduled_date(item, 1);
	} else if (IsDlgButtonChecked(dialog->window, IDC_SCHEDULE_2)) {
		Item_set_scheduled_date(item, 2);
	} else {
		Item_set_scheduled_date(item, 3);
	}

	/* get �����t���O */
	check_flag = IsDlgButtonChecked(dialog->window, IDC_IS_BY_AUCTION);
	if(check_flag == BST_CHECKED) {
		Item_set_is_by_auction(item, Item_TRUE);
	} else {
		Item_set_is_by_auction(item, Item_FALSE);
	}

	/* �ԋ��� */
	temp = GetDlgItemInt(dialog->window, IDC_REFUND_RATE, &is_translated, TRUE);
	if(!is_translated) {
		Item_set_refund_rate(item, -1);
	} else if(temp < 0 || temp > 100) {
		return FALSE;
	} else {
		Item_set_refund_rate(item, temp);
	}

	/* get �R�����g */
	GetDlgItemText(dialog->window, IDC_COMMENT, text, sizeof(text) - 1);
	if(strlen(text) != 0) {
		Item_set_comment(item, text);
	}

	/* �󂯕t������ */
	if(dialog->item_id == NEW_ITEM_ID) {
		Item_set_receipt_time(item, time(NULL));
	} else {
		ConstItem org_item;

		org_item = ItemList_item(Document_item_list(dialog->document), dialog->item_id);
		Item_set_receipt_time(item, Item_receipt_time(org_item));
	}

	return TRUE;
}

static void clean_up_ctrls(ItemDlg dialog) {
	SetDlgItemText(dialog->window, IDC_ITEM_NAME, "");
	SetDlgItemText(dialog->window, IDC_LIST_PRICE, "");
	SetDlgItemText(dialog->window, IDC_COMMENT, "");
	CheckDlgButton(dialog->window, IDC_IS_TO_BE_RETURNED, BST_UNCHECKED);
	CheckDlgButton(dialog->window, IDC_IS_TO_BE_DISCOUNTED, BST_UNCHECKED);
	SetFocus(dialog->ctrls.item_name);
}

static void add_vip_list_aux(int vip_id, const char *name, void *param) {
	ItemDlg dialog = (ItemDlg) param;

	SendMessage(dialog->ctrls.seller_name, CB_ADDSTRING, 0, (LPARAM)name);
}

static void add_vip_list(ItemDlg dialog, VipList vip_list) {
	int i;

	SendMessage(dialog->ctrls.seller_name, CB_RESETCONTENT, 0, 0);

	VipList_enum(vip_list, add_vip_list_aux, dialog);
}

static void seller_grade_on_update(ItemDlg dialog) {
	char text[256];

	GetDlgItemText(dialog->window, IDC_SELLER_GRADE, text, sizeof(text) - 1);
	if(stricmp(text, TEXT_OB) == 0) {
		EnableWindow(dialog->ctrls.seller_class, (BOOL)FALSE);
		EnableWindow(dialog->ctrls.seller_number, (BOOL)FALSE);
		EnableWindow(dialog->ctrls.seller_name, (BOOL)TRUE);
		add_vip_list(dialog, Document_ob_list(dialog->document));
		if(dialog->ob_index >= 0) {
			SendMessage(dialog->ctrls.seller_name, CB_SETCURSEL, dialog->ob_index, 0);
		}
	} else if(stricmp(text, TEXT_TEACHER) == 0) {
		EnableWindow(dialog->ctrls.seller_class, (BOOL)FALSE);
		EnableWindow(dialog->ctrls.seller_number, (BOOL)FALSE);
		EnableWindow(dialog->ctrls.seller_name, (BOOL)TRUE);
		add_vip_list(dialog, Document_teacher_list(dialog->document));
		if(dialog->teacher_index >= 0) {
			SendMessage(dialog->ctrls.seller_name, CB_SETCURSEL, dialog->teacher_index, 0);
		}
	} else if(stricmp(text, TEXT_LEGACY) == 0 || stricmp(text, TEXT_DONATION) == 0) {
		EnableWindow(dialog->ctrls.seller_class, (BOOL)FALSE);
		EnableWindow(dialog->ctrls.seller_number, (BOOL)FALSE);
		EnableWindow(dialog->ctrls.seller_name, (BOOL)FALSE);
	} else {  /* student */
		EnableWindow(dialog->ctrls.seller_class, (BOOL)TRUE);
		EnableWindow(dialog->ctrls.seller_number, (BOOL)TRUE);
		EnableWindow(dialog->ctrls.seller_name, (BOOL)FALSE);
	}
}

static void seller_name_on_update(ItemDlg dialog) {
	char seller_grade[256];

	GetDlgItemText(dialog->window, IDC_SELLER_GRADE, seller_grade, sizeof(seller_grade) - 1);
	if(stricmp(seller_grade, TEXT_OB) == 0) {
		dialog->ob_index = SendMessage(dialog->ctrls.seller_name, CB_GETCURSEL, 0, 0);
	} else if(stricmp(seller_grade, TEXT_TEACHER) == 0) {
		dialog->teacher_index = SendMessage(dialog->ctrls.seller_name, CB_GETCURSEL, 0, 0);
	}
}

static void on_ok(ItemDlg dialog) {
	Item item;
	Boolean result;

	item = Item_create();

	result = get_data(dialog, item);
	if(!result) {
		char message[256];
		LoadString((HINSTANCE)GetWindowLong(dialog->window, GWL_HINSTANCE), IDS_FILL_CTRLS, message, sizeof(message));
		MessageBox(dialog->window, message, Application_name(), MB_OK | MB_ICONWARNING);
	} else {
		Base_set_item(dialog->base, dialog->item_id, item);
		if(dialog->item_id == ItemList_ID_NEW) {
			clean_up_ctrls(dialog);
		} else {
			EndDialog(dialog->window, IDOK);
		}
	}
	Item_destroy(item);
}

typedef struct {
	ConstGenreList list;
	HWND ctrl;
} InsertGenres;

void insert_genres_aux(int tag, void *param) {
	char text[256];
	char buf[16];
	InsertGenres *heke = param;

	sprintf(text, "%s: %s", GenreList_order_text(heke->list, tag, buf),
			GenreList_name(heke->list, tag));
	SendMessage(heke->ctrl, CB_ADDSTRING, 0, (LPARAM) text);
}

static void insert_genres(ItemDlg dialog, int parent, HWND ctrl) {
	InsertGenres heke;

	SendMessage(ctrl, CB_RESETCONTENT, 0, 0);
	SendMessage(ctrl, CB_ADDSTRING, 0, (LPARAM) "*: ����");

	if(parent != GenreList_NIL && parent != 0) {
		heke.list = Document_genre_list(dialog->document);
		heke.ctrl = ctrl;
		GenreList_enum(heke.list, parent, insert_genres_aux, &heke);
	}
}

static void select_major_genre(ItemDlg dialog, int tag) {
	ConstGenreList list;

	list = Document_genre_list(dialog->document);
	SendMessage(dialog->ctrls.major_genres, CB_SETCURSEL, GenreList_index(list, tag), 0);
	insert_genres(dialog, tag, dialog->ctrls.minor_genres);
}

static void select_minor_genre(ItemDlg dialog, int tag) {
	ConstGenreList list;

	list = Document_genre_list(dialog->document);
	SendMessage(dialog->ctrls.minor_genres, CB_SETCURSEL, GenreList_index(list, tag), 0);
	insert_genres(dialog, tag, dialog->ctrls.extra_genres);
}

static void select_extra_genre(ItemDlg dialog, int tag) {
	ConstGenreList list;

	list = Document_genre_list(dialog->document);
	SendMessage(dialog->ctrls.extra_genres, CB_SETCURSEL, GenreList_index(list, tag), 0);
}

static void select_shape(ItemDlg dialog, int index) {
	SendMessage(dialog->ctrls.shapes, CB_SETCURSEL, index, 0);
}

static void major_genres_on_sel_change(ItemDlg dialog) {
	int index;
	ConstGenreList list;

	index = SendMessage(dialog->ctrls.major_genres, CB_GETCURSEL, 0, 0);
	list = Document_genre_list(dialog->document);

	insert_genres(dialog, GenreList_index2tag(list, GenreList_TOP, index),
			dialog->ctrls.minor_genres);
	SendMessage(dialog->ctrls.minor_genres, CB_SETCURSEL, 0, 0);

	insert_genres(dialog, GenreList_NIL, dialog->ctrls.extra_genres);
	SendMessage(dialog->ctrls.extra_genres, CB_SETCURSEL, 0, 0);
}

static void minor_genres_on_sel_change(ItemDlg dialog) {
	int major_index, minor_index;
	int major_tag, minor_tag;
	ConstGenreList list;

	list = Document_genre_list(dialog->document);

	major_index = SendMessage(dialog->ctrls.major_genres, CB_GETCURSEL, 0, 0);
	minor_index = SendMessage(dialog->ctrls.minor_genres, CB_GETCURSEL, 0, 0);
	major_tag = GenreList_index2tag(list, GenreList_TOP, major_index);
	minor_tag = GenreList_index2tag(list, major_tag, minor_index);
	insert_genres(dialog, minor_tag, dialog->ctrls.extra_genres);

	SendMessage(dialog->ctrls.extra_genres, CB_SETCURSEL, 0, 0);
}

static void ime_off(HWND window) {
	HIMC imc;

	imc = ImmGetContext(window);
	ImmSetOpenStatus(imc, (BOOL) FALSE);
	ImmReleaseContext(window, imc);
}

static void ime_on(HWND window) {
	HIMC imc;

	imc = ImmGetContext(window);
	ImmSetOpenStatus(imc, (BOOL) TRUE);
	ImmReleaseContext(window, imc);
}

static void on_is_sold_clicked(ItemDlg dialog) {
	if(IsDlgButtonChecked(dialog->window, IDC_IS_SOLD)) {
		char temp_text[128];

		EnableWindow(dialog->ctrls.real_price, (BOOL)TRUE);
		GetDlgItemText(dialog->window, IDC_REAL_PRICE, temp_text, sizeof(temp_text) - 1);
		if(strlen(temp_text) == 0) {
			ConstItem org_item;

			org_item = ItemList_item(Document_item_list(dialog->document), dialog->item_id);
			SetDlgItemInt(dialog->window, IDC_REAL_PRICE, Item_list_price(org_item), FALSE);
		}
	} else {
		EnableWindow(dialog->ctrls.real_price, (BOOL)FALSE);
	}
}

static BOOL on_command(ItemDlg dialog, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDC_SELLER_GRADE:
		if(notify_code == EN_UPDATE) {
			seller_grade_on_update(dialog);
		} else if(notify_code == EN_SETFOCUS) {
			ime_off(ctrl_window);
		}
		break;
	case IDC_SELLER_CLASS:
	case IDC_SELLER_NUMBER:
	case IDC_LIST_PRICE:
	case IDC_REAL_PRICE:
	case IDC_REFUND_RATE:
		if(notify_code == EN_SETFOCUS) {
			ime_off(ctrl_window);
		}
		break;
	case IDC_ITEM_NAME:
	case IDC_COMMENT:
		if(notify_code == EN_SETFOCUS) {
			ime_on(ctrl_window);
		}
		break;
	case IDC_SELLER_NAME:
		if(notify_code == CBN_SELCHANGE) {
			seller_name_on_update(dialog);
		}
		break;
	case IDC_MAJOR_GENRES:
		if(notify_code == CBN_SELCHANGE) {
			major_genres_on_sel_change(dialog);
		}
		break;
	case IDC_MINOR_GENRES:
		if(notify_code == CBN_SELCHANGE) {
			minor_genres_on_sel_change(dialog);
		}
		break;
	case IDC_IS_SOLD:
		if(notify_code == BN_CLICKED) {
			on_is_sold_clicked(dialog);
		}
		break;
	case IDOK:
		on_ok(dialog);
		break;
	case IDCANCEL:
		EndDialog(dialog->window, IDCANCEL);
		break;
	default:
		return (BOOL)FALSE;
	}
	TOUCH(ctrl_window);
	return (BOOL)TRUE;
}

static void display_seller(ItemDlg dialog, ConstItem item) {
	char text[256];
	int grade, class, number;
	int seller_id;

	seller_id = Item_seller_id(item);

	switch(Seller_type(seller_id)) {
	case Seller_STUDENT:
		grade = Seller_grade(seller_id);
		class = Seller_class(seller_id);
		number = Seller_number(seller_id);
		SetDlgItemInt(dialog->window, IDC_SELLER_GRADE, grade <= 3 ? grade : grade - 3, FALSE);
		if(grade<=3) {
			sprintf(text, "%c", 'A' + class - 1);
		} else {
			sprintf(text, "%d", class);
		}
		SetDlgItemText(dialog->window, IDC_SELLER_CLASS, text);
		SetDlgItemInt(dialog->window, IDC_SELLER_NUMBER, number, FALSE);
		break;
	case Seller_TEACHER:
		SetDlgItemText(dialog->window, IDC_SELLER_GRADE, TEXT_TEACHER);
		add_vip_list(dialog, Document_teacher_list(dialog->document));
		dialog->teacher_index = Seller_vip_id(seller_id) - 1;
		SendMessage(dialog->ctrls.seller_name, CB_SETCURSEL, dialog->teacher_index, 0);
		break;
	case Seller_OB:
		SetDlgItemText(dialog->window, IDC_SELLER_GRADE, TEXT_OB);
		add_vip_list(dialog, Document_ob_list(dialog->document));
		dialog->ob_index = Seller_vip_id(seller_id) - 1;
		SendMessage(dialog->ctrls.seller_name, CB_SETCURSEL, dialog->ob_index, 0);
		break;
	case Seller_LEGACY:
		SetDlgItemText(dialog->window, IDC_SELLER_GRADE, TEXT_LEGACY);
		break;
	case Seller_DONATION:
		SetDlgItemText(dialog->window, IDC_SELLER_GRADE, TEXT_DONATION);
		break;
	}
}

static void display_item(ItemDlg dialog) {
	ConstItem org_item;

	if(dialog->item_id==NEW_ITEM_ID) {
		SetDlgItemText(dialog->window, IDC_ITEM_ID, "New");
		EnableWindow(dialog->ctrls.seller_name, (BOOL) FALSE);

		CheckRadioButton(dialog->window, IDC_SCHEDULE_UNDEFINED, IDC_SCHEDULE_3, IDC_SCHEDULE_UNDEFINED);

		select_major_genre(dialog, 0);
		select_minor_genre(dialog, 0);
		select_extra_genre(dialog, 0);
		select_shape(dialog, 0);
	} else {
		char text[256];

		org_item = ItemList_item(Document_item_list(dialog->document), dialog->item_id);
		sprintf(text, "%.5d", dialog->item_id);
		SetDlgItemText(dialog->window, IDC_ITEM_ID, text);
		display_seller(dialog, org_item);

		SetDlgItemText(dialog->window, IDC_ITEM_NAME, Item_name(org_item));
		SetDlgItemInt(dialog->window, IDC_LIST_PRICE, Item_list_price(org_item), FALSE);
		CheckDlgButton(dialog->window, IDC_IS_TO_BE_RETURNED, Item_is_to_be_returned(org_item)? BST_CHECKED : BST_UNCHECKED);
		CheckDlgButton(dialog->window, IDC_IS_TO_BE_DISCOUNTED, Item_is_to_be_discounted(org_item)? BST_CHECKED : BST_UNCHECKED);

		CheckDlgButton(dialog->window, IDC_IS_SOLD, Item_is_sold(org_item) ? BST_CHECKED : BST_UNCHECKED);
		if(Item_is_sold(org_item)) {
			SetDlgItemInt(dialog->window, IDC_REAL_PRICE, Item_real_price(org_item), FALSE);
		}

		SetDlgItemText(dialog->window, IDC_COMMENT, Item_comment(org_item));

		switch(Item_scheduled_date(org_item)) {
		case 0:
			CheckRadioButton(dialog->window, IDC_SCHEDULE_UNDEFINED, IDC_SCHEDULE_3, IDC_SCHEDULE_UNDEFINED);
			break;
		case 1:
			CheckRadioButton(dialog->window, IDC_SCHEDULE_UNDEFINED, IDC_SCHEDULE_3, IDC_SCHEDULE_1);
			break;
		case 2:
			CheckRadioButton(dialog->window, IDC_SCHEDULE_UNDEFINED, IDC_SCHEDULE_3, IDC_SCHEDULE_2);
			break;
		case 3:
			CheckRadioButton(dialog->window, IDC_SCHEDULE_UNDEFINED, IDC_SCHEDULE_3, IDC_SCHEDULE_3);
			break;
		}

		CheckDlgButton(dialog->window, IDC_IS_BY_AUCTION, Item_is_by_auction(org_item) ? BST_CHECKED : BST_UNCHECKED);

		if(Item_refund_rate(org_item) != -1) {
			SetDlgItemInt(dialog->window, IDC_REFUND_RATE, Item_refund_rate(org_item), FALSE);
		}

		select_major_genre(dialog, Item_major_genre(org_item));
		select_minor_genre(dialog, Item_minor_genre(org_item));
		select_extra_genre(dialog, Item_extra_genre(org_item));
		select_shape(dialog, Item_shape(org_item));
	}

	switch(dialog->mode) {
	case ItemDlg_COLLECT:
		EnableWindow(dialog->ctrls.is_sold, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.real_price, (BOOL) FALSE);
		break;
	case ItemDlg_SELL:
		EnableWindow(dialog->ctrls.seller_grade, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.seller_class, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.seller_number, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.seller_name, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.item_name, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.list_price, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.is_to_be_returned, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.is_to_be_discounted, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.major_genres, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.minor_genres, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.extra_genres, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.shapes, (BOOL) FALSE);
		if(!Item_is_sold(org_item)) {
			if(dialog->composure == ItemDlg_HASTE) {
				EnableWindow(dialog->ctrls.real_price, (BOOL) TRUE);
				CheckDlgButton(dialog->window, IDC_IS_SOLD, BST_CHECKED);
				SetDlgItemInt(dialog->window, IDC_REAL_PRICE, Item_list_price(org_item), FALSE);
			} else {
				EnableWindow(dialog->ctrls.real_price, (BOOL) FALSE);
			}
		}
		break;
	case ItemDlg_RETURN:
		EnableWindow(dialog->ctrls.is_sold, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.real_price, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.seller_grade, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.seller_class, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.seller_number, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.seller_name, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.item_name, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.list_price, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.is_to_be_returned, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.is_to_be_discounted, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.major_genres, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.minor_genres, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.extra_genres, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.shapes, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.real_price, (BOOL) FALSE);
		EnableWindow(dialog->ctrls.is_sold, (BOOL) FALSE);
		break;
	}
}

static void insert_shapes_aux(int id, const char *name, void *param) {
	ItemDlg dialog = (ItemDlg) param;
	char text[256];
	char buf[16];

	sprintf(text, "%s: %s",
			ShapeList_id_text(Document_shape_list(dialog->document), id, buf), name);
	SendMessage(dialog->ctrls.shapes, CB_ADDSTRING, 0, (LPARAM) text);
}

static void insert_genres_shapes(ItemDlg dialog) {
	int i;
	int shape_count;
	ShapeList shape_list;

	insert_genres(dialog, GenreList_TOP, dialog->ctrls.major_genres);

	shape_list = Document_shape_list(dialog->document);
	SendMessage(dialog->ctrls.shapes, CB_ADDSTRING, 0, (LPARAM) "*: ����");
	ShapeList_enum(shape_list, insert_shapes_aux, dialog);
}

static BOOL init_dialog(ItemDlg dialog) {
	dialog->ctrls.item_id = GetDlgItem(dialog->window, IDC_ITEM_ID);
	dialog->ctrls.seller_grade = GetDlgItem(dialog->window, IDC_SELLER_GRADE);
	dialog->ctrls.seller_class = GetDlgItem(dialog->window, IDC_SELLER_CLASS);
	dialog->ctrls.seller_number = GetDlgItem(dialog->window, IDC_SELLER_NUMBER);
	dialog->ctrls.seller_name = GetDlgItem(dialog->window, IDC_SELLER_NAME);
	dialog->ctrls.item_name = GetDlgItem(dialog->window, IDC_ITEM_NAME);
	dialog->ctrls.list_price = GetDlgItem(dialog->window, IDC_LIST_PRICE);
	dialog->ctrls.is_to_be_discounted = GetDlgItem(dialog->window, IDC_IS_TO_BE_DISCOUNTED);
	dialog->ctrls.is_to_be_returned = GetDlgItem(dialog->window, IDC_IS_TO_BE_RETURNED);
	dialog->ctrls.is_sold = GetDlgItem(dialog->window, IDC_IS_SOLD);
	dialog->ctrls.real_price = GetDlgItem(dialog->window, IDC_REAL_PRICE);
	dialog->ctrls.major_genres = GetDlgItem(dialog->window, IDC_MAJOR_GENRES);
	dialog->ctrls.minor_genres = GetDlgItem(dialog->window, IDC_MINOR_GENRES);
	dialog->ctrls.extra_genres = GetDlgItem(dialog->window, IDC_EXTRA_GENRES);
	dialog->ctrls.shapes = GetDlgItem(dialog->window, IDC_SHAPES);

	insert_genres_shapes(dialog);
	display_item(dialog);
	if(dialog->composure==ItemDlg_HASTE) {
		SetFocus(dialog->ctrls.real_price);
		SendMessage(dialog->ctrls.real_price, EM_SETSEL, 0, -1);
		return (BOOL) FALSE;
	} else {
		return (BOOL) TRUE;
	}
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	ItemDlg dialog;
	if(message==WM_INITDIALOG) {
		dialog = (ItemDlg) long_param;
		SetWindowLong(dialog_window, DWL_USER, (LONG)dialog);
		dialog->window = dialog_window;
	}
	dialog = (ItemDlg) GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_INITDIALOG:
		return init_dialog(dialog);
	case WM_COMMAND:
		return on_command(dialog, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
	default:
		return (BOOL)FALSE;
	}
}

ItemDlg_Boolean ItemDlg_dialogue(ItemDlg dialog, HWND parent_window) {
	int return_value;
	HINSTANCE instance = (HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE);

	Debug_assert(Memory_is_on_heap(dialog));

	return_value = DialogBoxParam(instance, MAKEINTRESOURCE(IDD_ENTER_ITEM), parent_window, dialog_proc, (LONG)dialog);
	if(return_value == IDOK) {
		return ItemDlg_TRUE;
	} else {
		return ItemDlg_FALSE;
	}
}

ItemDlg ItemDlg_create(Base base, Document document, int item_id, ItemDlg_Mode mode, ItemDlg_Composure composure, ItemDlg_Boolean is_book) {
	ItemDlg dialog;
	int i;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->base = base;
	dialog->document = document;
	dialog->teacher_index = -1;
	dialog->ob_index = -1;
	dialog->item_id = item_id;
	dialog->mode = mode;
	dialog->composure = composure;
	dialog->is_book = is_book;
	return dialog;
}

void ItemDlg_destroy(ItemDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	Memory_free(dialog);
}
/* end of file */
