/*
 * file: refundRateDlgP.h
 * purpose: private header file for RefundRateDlg
 */

#ifndef _PRIVATE_REFUNDRATEDLGP_H_INCLUDED
#define _PRIVATE_REFUNDRATEDLGP_H_INCLUDED

#include <windows.h>

#include "refundRateDlg.h"

#define IDD_REFUND_RATE 1015

#define IDC_REFUND_RATE 101

#define IDS_DEFECT 1801
#define IDS_OUT_OF_RANGE 1802

struct tagRefundRateDlg {
	int refund_rate;
	HWND window;
};

#endif /* _PRIVATE_REFUNDRATEDLGP_H_INCLUDED */

/* end of file */
