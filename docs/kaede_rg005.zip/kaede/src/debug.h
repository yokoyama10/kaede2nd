/*************************************************************
  file: debug.h
  purpose: public heder file for Debug

  comment: DEBUG�}�N������`����Ă��Ȃ��ƁA�f�o�b�O�֐���
           void���ɓW�J����܂��B
 *************************************************************/

#ifndef _PUBLIC_DEBUG_H_INCLUDED
#define _PUBLIC_DEBUG_H_INCLUDED


#ifdef DEBUG

#include <assert.h>

#define Debug_initialize() Debug_initialize_func()
#define Debug_finalize() Debug_finalize_func()
#define Debug_printf Debug_printf_func
#define Debug_error(message) Debug_error_func(message)
#define Debug_assert(term) assert(term)

#else /* DEBUG */

#define Debug_initialize() ((void)0)
#define Debug_finalize() ((void)0)
#define Debug_printf (void)
#define Debug_error (void)
#define Debug_assert (void)

#endif /* DEBUG */

extern void Debug_error_func(const char *message);
extern void Debug_printf_func(const char *form, ...);
extern void Debug_initialize_func(void);
extern void Debug_finalize_func(void);

#endif /* _PUBLIC_DEBUG_H_INCLUDED */
/* end of file */