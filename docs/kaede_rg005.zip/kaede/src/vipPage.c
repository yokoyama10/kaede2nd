/*
 * file: vipPage.c
 * purpose: ����/OB�̃v���p�e�B->�y�[�W
 */

#include <windows.h>
#include <stdio.h>
#include "string.h"
#include "memory.h"
#include "debug.h"
#include "vipList.h"

#include "vipPageP.h"

#define TOUCH(a) ((void)(a))


static void display_vips_aux(int id, const char *name, void *param) {
	VipPage page = (VipPage)param;
	char text[128];
	
	sprintf(text, "%d: %s", id, name);
	SendMessage(page->ctrls.vips, LB_ADDSTRING, 0, (LPARAM) text);
}

static void display_vips(VipPage page) {
	int i;
	
	SendMessage(page->ctrls.vips, LB_RESETCONTENT, 0, 0);
	VipList_enum(page->vip_list, display_vips_aux, page);
}

static void display_name(VipPage page) {
	SetDlgItemText(page->window, IDC_NAME, VipList_name(page->vip_list, page->selected_item+1));
}

static void select_item(VipPage page) {
	if(page->selected_item >= 0) {
		SendMessage(page->ctrls.vips, LB_SETCURSEL, page->selected_item, 0);
	}
}

static void init_dialog(VipPage page) {
	char text[128];
	
	page->ctrls.vips = GetDlgItem(page->window, IDC_VIPS);
	sprintf(text, "%sz(&V)", page->title);
	SetDlgItemText(page->window, IDC_VIPS_TITLE, text);
	display_vips(page);
	
	if(VipList_count(page->vip_list) >= 1) {
		page->selected_item = 0;
		select_item(page);
	}
}

static void set_name(VipPage page) {
	char text[128];
	
	if(VipList_count(page->vip_list) > 0 && page->is_name_changed) {
		GetDlgItemText(page->window, IDC_NAME, text, sizeof(text));
		if(strlen(text) > 0) {
			VipList_set(page->vip_list, page->selected_item + 1, text);
			display_vips(page);
			display_name(page);
		}
	}
	page->is_name_changed = FALSE;
}

static void on_vips_sel_change(VipPage page) {
	int index;
	
	index = SendMessage(page->ctrls.vips, LB_GETCURSEL, 0, 0);
	set_name(page);
	SendMessage(page->ctrls.vips, LB_SETCURSEL, index, 0);
	page->selected_item = index;
	display_name(page);
}

static void on_append(VipPage page) {
	set_name(page);
	
	VipList_set(page->vip_list, VipList_ID_NEW, "newcomer");
	SendMessage(page->ctrls.vips, LB_SETCURSEL, VipList_count(page->vip_list) - 1, 0);
	page->selected_item = VipList_count(page->vip_list) - 1;
	display_vips(page);
	display_name(page);
	select_item(page);
}

static void on_set_active(VipPage page) {
	select_item(page);
}

static void on_kill_active(VipPage page) {
	if(page->selected_item >= 0) {
		set_name(page);
		display_vips(page);
		display_name(page);
	}
}

static void on_notify(VipPage page, int id, LPNMHDR notify_info) {
	switch(notify_info->code) {
	case PSN_SETACTIVE:
		on_set_active(page);
		break;
	case PSN_KILLACTIVE:
		on_kill_active(page);
		break;
	case PSN_APPLY:
		on_kill_active(page);
		page->is_applied = TRUE;
		break;
	}
	TOUCH(id);
}

static void on_command(VipPage page, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDC_NAME:
		if(notify_code == EN_UPDATE) {
			page->is_name_changed = TRUE;
		}
		break;
	case IDC_VIPS:
		if(notify_code == LBN_SELCHANGE) {
			on_vips_sel_change(page);
		}
		break;
	case IDC_APPEND:
		on_append(page);
		break;
	}
	TOUCH(ctrl_window);
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	VipPage page;
	
	if(message == WM_INITDIALOG) {
		PROPSHEETPAGE *page_info;
		
		page_info = (PROPSHEETPAGE *)long_param;
		page = (VipPage)page_info->lParam;
		SetWindowLong(dialog_window, DWL_USER, (LONG)page);
		page->window = dialog_window;
	}
	page = (VipPage)GetWindowLong(dialog_window, DWL_USER);
	
	switch (message) {
	case WM_NOTIFY:
		on_notify(page, (int)word_param, (LPNMHDR)long_param);
		break;
	case WM_INITDIALOG:
		init_dialog(page);
		break;
	case WM_COMMAND:
		on_command(page, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	default:
		return (BOOL) FALSE;
	}
	return (BOOL) TRUE;
}

HPROPSHEETPAGE VipPage_create_page(VipPage page, HINSTANCE instance) {
	PROPSHEETPAGE page_info;
	
	Debug_assert(Memory_is_on_heap(page));
	
	page_info.dwSize = sizeof(page_info);
	page_info.dwFlags = PSP_DEFAULT|PSP_USETITLE;
	page_info.pszTitle = page->title;
	page_info.hInstance = instance;
	page_info.u.pszTemplate = MAKEINTRESOURCE(IDD_VIP_PAGE);
	page_info.pfnDlgProc = (DLGPROC)dialog_proc;
	page_info.lParam = (LPARAM)page;
	return CreatePropertySheetPage(&page_info);
}

VipList VipPage_vip_list(VipPage page) {
	Debug_assert(Memory_is_on_heap(page));
	
	return page->vip_list;
}

VipPage_Boolean VipPage_is_applied(VipPage page) {
	Debug_assert(Memory_is_on_heap(page));
	
	return page->is_applied;
}

VipPage VipPage_create(const char *title, VipList vip_list) {
	VipPage page;
	int i;
	
	page = Memory_malloc(sizeof(*page));
	page->selected_item = -1;
	page->title = String_make(NULL, title);
	page->is_name_changed = FALSE;
	page->is_applied = FALSE;
	page->vip_list = VipList_clone(vip_list);
	return page;
}

void VipPage_destroy(VipPage page) {
	int i;
	
	Debug_assert(Memory_is_on_heap(page));
	
	Memory_free(page->title);
	VipList_destroy(page->vip_list);
	Memory_free(page);
}

/* end of file */
