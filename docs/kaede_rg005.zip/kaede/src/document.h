/*
 * file: document.h
 * purpose: public header file for Document
 */

#ifndef _PUBLIC_DOCUMENT_H_INCLUDED
#define _PUBLIC_DOCUMENT_H_INCLUDED

#include "itemListType.h"
#include "vipListType.h"
#include "shapeListType.h"
#include "genreListType.h"

#include "documentType.h"

extern ItemList Document_item_list(Document document);
extern VipList Document_teacher_list(Document document);
extern void Document_set_teacher_list(Document document, VipList teacher_list);
extern VipList Document_ob_list(Document document);
extern void Document_set_ob_list(Document document, VipList ob_list);
extern GenreList Document_genre_list(Document document);
extern void Document_set_genre_list(Document document, GenreList genre_list);
extern ShapeList Document_shape_list(Document document);
extern void Document_set_shape_list(Document document, ShapeList shape_list);
extern int Document_cash(Document document);
extern void Document_set_cash(Document document, int cash);
extern int Document_refund_rate(Document document);
extern void Document_set_refund_rate(Document document, int refund_rate);
extern Document Document_create(void);
extern void Document_destroy(Document document);

#endif /* _PUBLIC_DOCUMENT_H_INCLUDED */
/* end of file */
