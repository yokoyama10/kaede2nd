/*
 * file: searchDlg.c
 * purpose: �u���i�̌����v�_�C�A���O
 */

#include <windows.h>
#include "memory.h"
#include "debug.h"

#include "searchDlgP.h"


#define TOUCH(a) ((void)(a))


static void on_init_dialog(SearchDlg dialog) {
	HWND item_name_ctrl;

	item_name_ctrl = GetDlgItem(dialog->window, IDC_ITEM_NAME);
	SetDlgItemText(dialog->window, IDC_ITEM_NAME, dialog->item_name);
	SendMessage(item_name_ctrl, EM_SETSEL, 0, -1);
}

static void on_ok(SearchDlg dialog) {
	char item_name[256];

	GetDlgItemText(dialog->window, IDC_ITEM_NAME, item_name, sizeof(item_name));
	if(strlen(item_name) == 0) {
		EndDialog(dialog->window, IDCANCEL);
	} else {
		dialog->item_name = String_make(dialog->item_name, item_name);
		EndDialog(dialog->window, IDOK);
	}
}

static void on_cancel(SearchDlg dialog) {
	EndDialog(dialog->window, IDCANCEL);
}

static void on_command(SearchDlg dialog, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDOK:
		on_ok(dialog);
		break;
	case IDCANCEL:
		on_cancel(dialog);
		break;
	}
	TOUCH(notify_code);
	TOUCH(ctrl_window);
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	SearchDlg dialog;
	if(message == WM_INITDIALOG) {
		dialog = (SearchDlg) long_param;
		SetWindowLong(dialog_window, DWL_USER, (LONG)dialog);
		dialog->window = dialog_window;
	}
	dialog = (SearchDlg)GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_INITDIALOG:
		on_init_dialog(dialog);
		break;
	case WM_COMMAND:
		on_command(dialog, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

SearchDlg_Boolean SearchDlg_dialogue(SearchDlg dialog, HWND parent_window) {
	int return_value;
	HINSTANCE instance = (HINSTANCE)GetWindowLong(parent_window, GWL_HINSTANCE);

	Debug_assert(Memory_is_on_heap(dialog));

	return_value = DialogBoxParam(instance, MAKEINTRESOURCE(IDD_FIND_ITEM),
			parent_window, dialog_proc, (LONG)dialog);
	if(return_value == IDOK) {
		return SearchDlg_TRUE;
	} else {
		return SearchDlg_FALSE;
	}
}

const char *SearchDlg_item_name(SearchDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	return dialog->item_name;
}

SearchDlg SearchDlg_create(const char *item_name) {
	SearchDlg dialog;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->item_name = String_make(NULL, item_name);
	return dialog;
}

void SearchDlg_destroy(SearchDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	Memory_free(dialog->item_name);
	Memory_free(dialog);
}

/* end of file */
