/*
 * file: base.c
 * purpose: �����Bmain�Ƃ������O�͎g���Ȃ��̂ŁB
 */

#include <windows.h>
#include <string.h>
#include <dbcsstr.h>
#include <stdlib.h>
#include <stdio.h>
#include <commctrl.h>
#include <time.h>
#include "debug.h"
#include "memory.h"
#include "argument.h"
#include "application.h"
#include "disk.h"
#include "document.h"
#include "itemList.h"
#include "item.h"
#include "string.h"
#include "genreList.h"
#include "vipList.h"
#include "shapeList.h"
#include "checkitCap.h"
#include "checkitMenu.h"
#include "print.h"
#include "config.h"
#include "events.h"
#include "jumpDlg.h"
#include "searchDlg.h"
#include "fileNameDlg.h"
#include "genreShapeDlg.h"
#include "vipDlg.h"
#include "itemDlg.h"
#include "aboutDlg.h"
#include "depositDlg.h"
#include "refundRateDlg.h"
#include "sellerList.h"
#include "sellerMngPanel.h"
#include "seller.h"
#include "import.h"

#include "baseP.h"

#define IDR_MAIN_ACCELS 1001
#define IDS_APPLICATION_NAME 1101

#define TOUCH(a) ((void)(a))


const ColumnInfo column_infos[] = {
	{ID_ITEM_ID, Base_FALSE, "id"},
	{ID_SELLER, Base_FALSE, "seller"},
	{ID_LIST_PRICE, Base_TRUE, "list_price"},
	{ID_ITEM_NAME, Base_FALSE, "item_name"},
	{ID_IS_TO_BE_RETURNED, Base_TRUE, "henpin_flag"},
	{ID_IS_TO_BE_DISCOUNTED, Base_TRUE, "tataki_flag"},
	{ID_GENRE, Base_FALSE, "genre"},
	{ID_SHAPE, Base_FALSE, "shape"},
	{ID_RECEIPT_TIME, Base_FALSE, "receipt_time"},
	{ID_SCHEDULED_DATE, Base_FALSE, "schedule"},
	{ID_COMMENT, Base_FALSE, "comment"},
	{ID_IS_SOLD, Base_TRUE, "sold_flag"},
	{ID_SOLD_TIME, Base_FALSE, "sold_time"},
	{ID_REAL_PRICE, Base_TRUE, "real_price"},
	{ID_IS_BY_AUCTION, Base_TRUE, "auction_flag"},
	{ID_REFUND_RATE, Base_TRUE, "refund_rate"},
};

static void auto_save(Base base) {
	if(!base->is_document_new && base->is_document_modified) {
		char drive[MAX_PATH], dir[MAX_PATH], fname[MAX_PATH], extension[MAX_PATH];
		char path[MAX_PATH];
		Disk_ErrorType error_type;

		_splitpath(base->file_name, drive, dir, fname, extension);
		sprintf(path, "%s%s#%s%s#", drive, dir, fname, extension);
		Disk_save(base->document, path, &error_type);
	}
}

static void message_file_error(Base base, Disk_ErrorType error_type) {
	char message[256];
	int message_id;

	switch(error_type) {
	case Disk_TOO_OLD_FILE:
		message_id = IDS_TOO_OLD_FILE;
		break;
	case Disk_GET_NEW_VERSION:
		message_id = IDS_GET_NEW_VERSION;
		break;
	case Disk_DATA_ERROR:
		message_id = IDS_DATA_ERROR;
		break;
	case Disk_CRC_UNMATCH:
		message_id = IDS_CRC_UNMATCH;
		break;
	case Disk_NO_FILE:
		message_id = IDS_NO_FILE;
		break;
	case Disk_UNKNOWN_FILE:
		message_id = IDS_UNKNOWN_FILE;
		break;
	case Disk_UNKNOWN_SAVE_ERROR:
		message_id = IDS_UNKNOWN_SAVE_ERROR;
		break;
	}

	LoadString(base->instance, message_id, message, sizeof(message));
	MessageBox(base->main_window, message, Application_name(), MB_OK | MB_ICONERROR);
}

static Base_Boolean save_as(Base base) {
	FileNameDlg dialog;
	Base_Boolean result = Base_FALSE;
	char extension[64];
	char type_name[128];

	LoadString(base->instance, IDS_KAE_EXTENSION, extension, sizeof(extension));
	LoadString(base->instance, IDS_KAE_TYPE_NAME, type_name, sizeof(type_name));
	dialog = FileNameDlg_create(base->is_document_new ? NULL : base->file_name, extension, type_name, FileNameDlg_SAVE);
	if(FileNameDlg_dialogue(dialog, base->main_window)) {
		const char *file_name;
		Disk_ErrorType error_type;

		file_name = FileNameDlg_file_name(dialog);
		if(Disk_save(base->document, file_name, &error_type)) {
			base->is_document_new = Base_FALSE;
			base->is_document_modified = Base_FALSE;
			base->file_name = String_make(base->file_name, file_name);
			bASE_display_file_name(base);
			result = Base_TRUE;
		} else {
			message_file_error(base, error_type);
		}
	} 
	FileNameDlg_destroy(dialog);
	return result;
}

static Base_Boolean save(Base base) {
	Disk_ErrorType error_type;

	if(base->is_document_new) {
		return save_as(base);
	} else {
		if(Disk_save(base->document, base->file_name, &error_type)) {
			base->is_document_modified = Base_FALSE;
			return Base_TRUE;
		} else {
			message_file_error(base, error_type);
			return Base_FALSE;
		}
	}
}

/* cancel����Base_FALSE��Ԃ� */
static Base_Boolean ask_n_save(Base base) {
	char message[128];
	int ret_value;

	if(!base->is_document_modified) {
		return Base_TRUE;
	}

	LoadString(base->instance, IDS_ASK_SAVE_MODIFIED_FILE, message, sizeof(message));
	ret_value = MessageBox(base->main_window, message, Application_name(),
			MB_YESNOCANCEL | MB_ICONQUESTION);
	switch(ret_value) {
	case IDCANCEL:
		return Base_FALSE;
	case IDNO:
		return Base_TRUE;
	case IDYES:
		if(save(base)) {
			return Base_TRUE;
		} else {
			return Base_FALSE;
		}
	default:
		return Base_FALSE;
	}
}

static void on_checkit_captions(void) {
	if(CheckitCap_is_checkiting()) {
		CheckitCap_uncheckit();
	} else {
		CheckitCap_checkit();
	}
}

static void on_checkit_menus(void) {
	if(CheckitMenu_is_checkiting()) {
		CheckitMenu_uncheckit();
	} else {
		CheckitMenu_checkit();
	}
}

static void on_open(Base base) {
	FileNameDlg dialog;
	char extension[64];
	char type_name[128];

	if(!ask_n_save(base)) {
		return;
	}

	LoadString(base->instance, IDS_KAE_EXTENSION, extension, sizeof(extension));
	LoadString(base->instance, IDS_KAE_TYPE_NAME, type_name, sizeof(type_name));
	dialog = FileNameDlg_create(NULL, extension, type_name, FileNameDlg_LOAD);
	if(FileNameDlg_dialogue(dialog, base->main_window)) {
		Disk_ErrorType error_type;
		Document document;
		const char *file_name;

		file_name = FileNameDlg_file_name(dialog);
		document = Disk_load(file_name, &error_type);
		if(document != NULL) {
			Document_destroy(base->document);
			if(base->mode == MODE_RETURN) {
				SellerMngPanel_destroy_window(base->seller_mng_panel);
				SellerMngPanel_destroy(base->seller_mng_panel);
				base->seller_mng_panel = NULL;
			}

			base->document = document;
			base->is_document_new = Base_FALSE;
			base->is_document_modified = Base_FALSE;
			base->file_name = String_make(base->file_name, file_name);
			base->mode = MODE_COLLECT;
			bASE_calc_proceeds(base);
			bASE_display(base);
		} else {
			message_file_error(base, error_type);
		}
	}
	FileNameDlg_destroy(dialog);
}

static void on_import_kaede(Base base) {
	FileNameDlg dialog;
	char extension[64];
	char type_name[128];

	LoadString(base->instance, IDS_KAE_EXTENSION, extension, sizeof(extension));
	LoadString(base->instance, IDS_KAE_TYPE_NAME, type_name, sizeof(type_name));
	dialog = FileNameDlg_create(NULL, extension, type_name, FileNameDlg_LOAD);
	if(FileNameDlg_dialogue(dialog, base->main_window)) {
		Disk_ErrorType error_type;
		Document document;
		const char *file_name;

		file_name = FileNameDlg_file_name(dialog);
		document = Disk_load(file_name, &error_type);
		if(!document) {
			message_file_error(base, error_type);
			goto quit;
		}
		if(Import_import(base->document, document)) {
			bASE_calc_proceeds(base);
			bASE_display(base);
			/* !! */
			MessageBox(base->main_window, "�C���|�[�g�����ɂ�", Application_name(), MB_OK);
		} else {
			/* !! */
			MessageBox(base->main_window, "���̂��͒m��˂ǂ��C���|�[�g�ł��Ȃ�", Application_name(), MB_OK | MB_ICONEXCLAMATION);
		}
		Document_destroy(document);
	}
quit:
	FileNameDlg_destroy(dialog);
}

static void on_deposit(Base base) {
	DepositDlg dialog;

	dialog = DepositDlg_create(Document_cash(base->document));
	if(DepositDlg_dialogue(dialog, base->main_window)) {
		Document_set_cash(base->document, DepositDlg_cash(dialog));
		bASE_display_cash(base);
	}
	DepositDlg_destroy(dialog);
}

static void clear_item_shape(int id, Item item, void *param) {
	Item_set_shape(item, 0);
	TOUCH(id);
	TOUCH(param);
}

static void clear_item_genre(int id, Item item, void *param) {
	Item_set_major_genre(item, 0);
	Item_set_minor_genre(item, 0);
	Item_set_extra_genre(item, 0);
	TOUCH(id);
	TOUCH(param);
}

static void on_edit_genres_shapes(Base base) {
	GenreShapeDlg dialog;
	ItemList item_list;

	item_list = Document_item_list(base->document);

	dialog = GenreShapeDlg_create(Document_genre_list(base->document), Document_shape_list(base->document), Document_item_list(base->document));
	if(GenreShapeDlg_dialogue(dialog, base->main_window)) {
		if(GenreShapeDlg_is_shapes_cleared(dialog)) {
			ItemList_enum(item_list, clear_item_shape, NULL);
		}
		if(GenreShapeDlg_is_genres_cleared(dialog)) {
			ItemList_enum(item_list, clear_item_genre, NULL);
		}

		Document_set_genre_list(base->document, GenreShapeDlg_genre_list(dialog));
		Document_set_shape_list(base->document, GenreShapeDlg_shape_list(dialog));
		base->is_document_modified = Base_TRUE;
		bASE_update_display(base);
	}
	GenreShapeDlg_destroy(dialog);
}

static void on_edit_vips_list(Base base) {
	VipDlg dialog;

	dialog = VipDlg_create(Document_ob_list(base->document), Document_teacher_list(base->document));

	if(VipDlg_dialogue(dialog, base->main_window)) {
		Document_set_ob_list(base->document, VipDlg_ob_list(dialog));
		Document_set_teacher_list(base->document, VipDlg_teacher_list(dialog));

		base->is_document_modified = Base_TRUE;
		bASE_update_display(base);
	}
	VipDlg_destroy(dialog);
}

static void edit_items(Base base, int item_id, Base_Boolean is_haste) {
	ItemDlg dialog;

	dialog = ItemDlg_create(base, base->document,
			item_id, base->mode == MODE_SELL ? ItemDlg_SELL : base->mode == MODE_RETURN ? ItemDlg_RETURN : ItemDlg_COLLECT,
			is_haste ? ItemDlg_HASTE : ItemDlg_CALM,
			base->is_book ? ItemDlg_TRUE : ItemDlg_FALSE);
	/* Base_set_item() ���Ă΂�� */
	ItemDlg_dialogue(dialog, base->main_window);
	ItemDlg_destroy(dialog);
}

static Base_Boolean on_exit(Base base) {
	if(ask_n_save(base)) {
		Document_destroy(base->document);
		if(base->mode == MODE_RETURN) {
			SellerMngPanel_destroy_window(base->seller_mng_panel);
			SellerMngPanel_destroy(base->seller_mng_panel);
		}
		KillTimer(base->main_window, base->timer);
		DestroyWindow(base->main_window);
		return Base_TRUE;
	} else {
		return Base_FALSE;
	}
}

#if 0
static void on_genre_statistics(Base base) {
	StatisticsDlg dialog;

	dialog = StatisticsDlg_create(base->document);
	StatisticsDlg_dialogue(dialog, base->main_window);
	StatisticsDlg_destroy(dialog);
}
#endif

static void reset_selection(Base base) {
	int i;
	LVITEM lv_item;
	int prev;

	prev = -1;
	while(1) {
		lv_item.iItem = ListView_GetNextItem(base->list_window, prev,
				LVNI_ALL | LVNI_SELECTED);
		if(lv_item.iItem == -1) {
			break;
		}
		ListView_SetItemState(base->list_window, lv_item.iItem, 0, LVIS_SELECTED);
		prev = lv_item.iItem;
	}
}

static Base_Boolean jump(Base base, int id) {
	LVITEM lv_item;

	lv_item.mask = LVIF_PARAM;
	lv_item.iItem = -1;

	for(lv_item.iItem = ListView_GetNextItem(base->list_window, -1, LVNI_ALL);
			lv_item.iItem != -1;
			lv_item.iItem = ListView_GetNextItem(base->list_window, lv_item.iItem, LVNI_ALL)) {
		ListView_GetItem(base->list_window, &lv_item);
		if(lv_item.lParam == NIL_ITEM) {
			continue;
		}
		if(lv_item.lParam == id) {
			reset_selection(base);
			ListView_SetItemState(base->list_window, lv_item.iItem,
					LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);
			ListView_EnsureVisible(base->list_window, lv_item.iItem, TRUE);
			return Base_TRUE;
		}
	}
	return Base_FALSE;
}

static void on_jump(Base base) {
	JumpDlg dialog;

	dialog = JumpDlg_create(JumpDlg_CALM);
	if(JumpDlg_dialogue(dialog, base->main_window)) {
		if(!jump(base, JumpDlg_item_id(dialog))) {
			char message[128];

			LoadString(base->instance, IDS_INVALID_ITEM_ID, message, sizeof(message));
			MessageBox(base->main_window, message, Application_name(), MB_OK | MB_ICONWARNING);
		}
	}
	JumpDlg_destroy(dialog);
}

static void on_sell(Base base) {
	JumpDlg dialog;

	dialog = JumpDlg_create(JumpDlg_HASTE);
	while(JumpDlg_dialogue(dialog, base->main_window)) {
		if(!jump(base, JumpDlg_item_id(dialog))) {
			char message[128];

			LoadString(base->instance, IDS_INVALID_ITEM_ID, message, sizeof(message));
			MessageBox(base->main_window, message, Application_name(), MB_OK | MB_ICONWARNING);
		} else {
			edit_items(base, JumpDlg_item_id(dialog), Base_TRUE);
		}
	}
	JumpDlg_destroy(dialog);
}

typedef struct tagCalcStruct {
	SellerList seller_list;
	int default_refund_rate;
} CalcStruct;

static void calc_refunder_aux(int id, Item item, void *param) {
	int seller_id;
	Seller_Type seller_type;
	CalcStruct *calc_struct = (CalcStruct *)param;

	seller_id = Item_seller_id(item);
	seller_type = Seller_type(seller_id);
	if(seller_type != Seller_LEGACY && seller_type != Seller_DONATION && Item_is_sold(item)) {
		int old;
		int refund_rate;

		if(Item_refund_rate(item) == -1) {
			refund_rate = calc_struct->default_refund_rate;
		} else {
			refund_rate = Item_refund_rate(item);
		}

		if(SellerList_is_including(calc_struct->seller_list, seller_id)) {
			old = SellerList_refunder(calc_struct->seller_list, seller_id);
		} else {
			old = 0;
		}
		SellerList_set(calc_struct->seller_list, seller_id,
				Item_real_price(item) * refund_rate / 100 + old);
	}
}

static void calc_refunder(Base base) {
	CalcStruct calc_struct;

	if(base->seller_list) {
		SellerList_destroy(base->seller_list);
	}
	base->seller_list = SellerList_create();
	calc_struct.seller_list = base->seller_list;
	calc_struct.default_refund_rate = Document_refund_rate(base->document);
	ItemList_enum(Document_item_list(base->document), calc_refunder_aux, &calc_struct);
}

static void on_mode(Base base, Mode mode) {
	Mode prev_mode;

	prev_mode = base->mode;
	base->mode = mode;

	switch(base->mode) {
	case MODE_COLLECT:
	case MODE_SELL:
		if(prev_mode == MODE_RETURN) {
			SellerMngPanel_destroy_window(base->seller_mng_panel);
			SellerMngPanel_destroy(base->seller_mng_panel);
			base->seller_mng_panel = NULL;
			bASE_display_refunder_sum(base);
		}
		break;
	case MODE_RETURN:
		if(prev_mode != MODE_RETURN) {
			calc_refunder(base);
			bASE_display_refunder_sum(base);
			base->seller_mng_panel = SellerMngPanel_create(base, base->document, base->seller_list);
			SellerMngPanel_create_window(base->seller_mng_panel, base->main_window);
			bASE_display_refunder_sum(base);
		}
		break;
	}
	bASE_display_mode(base);
}

static void on_new(Base base) {
	if(!ask_n_save(base)) {
		return;
	}

	Document_destroy(base->document);

	if(base->mode == MODE_RETURN) {
		SellerMngPanel_destroy_window(base->seller_mng_panel);
		SellerMngPanel_destroy(base->seller_mng_panel);
		base->seller_mng_panel = NULL;
	}

	base->document = Document_create();
	base->is_document_new = Base_TRUE;
	base->is_document_modified = Base_FALSE;
	base->mode = MODE_COLLECT;
	bASE_calc_proceeds(base);
	bASE_display(base);
}

static void on_print(Base base) {
	LVITEM lv_item;
	int * items_ids;
	int count;

	count = ListView_GetSelectedCount(base->list_window);
	if(count <= 0) {
		items_ids = NULL;
	} else {
		int i, prev_id;

		items_ids = Memory_malloc(sizeof(int)*count);
		lv_item.mask = LVIF_PARAM;
		prev_id = -1;
		for(i = 0; i < count; i++) {
			lv_item.iItem = ListView_GetNextItem(base->list_window, prev_id, LVNI_ALL | LVNI_SELECTED);
			ListView_GetItem(base->list_window, &lv_item);
			if(lv_item.lParam == NIL_ITEM) {
				i -= 1;
				count -= 1;
			} else {
				items_ids[i] = lv_item.lParam;
			}
			prev_id = lv_item.iItem;
		}
	}

	Print_print(base->document, items_ids, count, base->file_name, base->main_window);
	Memory_free(items_ids);
}

static void search_item(Base base, Base_Boolean is_ascend) {
	LVITEM lv_item;
	char search_text[256];
	DWORD direction_flag = is_ascend ? 0 : LVNI_ABOVE;

	if(strlen(base->search_text) == 0) {
		return;
	}

	lv_item.mask = LVIF_PARAM;
	if(base->is_first_search) {
		lv_item.iItem = -1;
	} else {
		lv_item.iItem = ListView_GetNextItem(base->list_window, -1, LVNI_ALL | LVNI_FOCUSED);
	}

	strcpy(search_text, base->search_text);
	strupr(search_text);
	while(-1 != (lv_item.iItem = ListView_GetNextItem(base->list_window, lv_item.iItem, LVNI_ALL|direction_flag))) {
		ConstItem item;
		char item_name[256];
		char comment[256];

		ListView_GetItem(base->list_window, &lv_item);
		if(lv_item.lParam == NIL_ITEM) {
			continue;
		}
		item = ItemList_item(Document_item_list(base->document), lv_item.lParam);
		strcpy(item_name, Item_name(item));
		strcpy(comment, Item_comment(item));
		strupr(item_name);
		strupr(comment);
		if(strstr(item_name, search_text) != NULL || strstr(comment, search_text)) {
			reset_selection(base);
			ListView_SetItemState(base->list_window, lv_item.iItem, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);
			ListView_EnsureVisible(base->list_window, lv_item.iItem, TRUE);
			break;
		}
	}
	base->is_first_search = Base_FALSE;
}

static void on_search_item(Base base) {
	SearchDlg dialog;

	dialog = SearchDlg_create(base->search_text);

	if(SearchDlg_dialogue(dialog, base->main_window)) {
		base->is_first_search = Base_TRUE;
		base->search_text = String_make(base->search_text, SearchDlg_item_name(dialog));
		search_item(base, Base_TRUE);
	}

	SearchDlg_destroy(dialog);
}

static void on_search_next_item(Base base) {
	search_item(base, Base_TRUE);
}

static void on_search_prev_item(Base base) {
	search_item(base, Base_FALSE);
}

static void on_set_refund_rate(Base base) {
	RefundRateDlg dialog;

	dialog = RefundRateDlg_create(Document_refund_rate(base->document));

	if(RefundRateDlg_dialogue(dialog, base->main_window)) {
		Document_set_refund_rate(base->document, RefundRateDlg_refund_rate(dialog));
		base->is_document_modified = Base_TRUE;
		if(base->mode == MODE_RETURN) {
			calc_refunder(base);
			bASE_display_refunder_sum(base);
			SellerMngPanel_redraw(base->seller_mng_panel);
		}
	}
	RefundRateDlg_destroy(dialog);
}

static void on_usage(void) {
	char drive[MAX_PATH], dir[MAX_PATH], fname[MAX_PATH];
	char path[MAX_PATH];
	char module_file_name[MAX_PATH];


	GetModuleFileName(NULL, module_file_name, sizeof(module_file_name));
	_splitpath(module_file_name, drive, dir, fname, NULL);
	sprintf(path, "%s%susage.txt", drive, dir);

	ShellExecute(GetDesktopWindow(), "open", path, NULL, NULL, SW_SHOWNORMAL);
}

static void on_about(Base base) {
	AboutDlg dialog;

	dialog = AboutDlg_create();
	AboutDlg_dialogue(dialog, base->main_window);
	AboutDlg_destroy(dialog);
}

static void on_is_book(Base base) {
	if(base->is_book) {
		base->is_book = Base_FALSE;
	} else {
		base->is_book = Base_TRUE;
	}
}

static int on_command(Base base, WORD notify_code, WORD command_id, HWND ctrl_window) {
	switch(command_id) {
	case IDM_ABOUT_APPLICATION:
		on_about(base);
		break;
	case IDM_CHECKIT_CAPTIONS:
		on_checkit_captions();
		break;
	case IDM_CHECKIT_MENUS:
		on_checkit_menus();
		break;
	case IDM_DEPOSIT:
		on_deposit(base);
		break;
	case IDM_EDIT_GENRES_SHAPES:
		on_edit_genres_shapes(base);
		break;
	case IDM_EDIT_VIPS_LIST:
		on_edit_vips_list(base);
		break;
	case IDM_EXIT:
		on_exit(base);
		break;
	case IDM_EXPORT_CSV:
		bASE_on_export_csv(base);
		break;
#if 0
	case IDM_GENRE_STATISTICS:
		on_genre_statistics(base);
		break;
#endif
	case IDM_JUMP:
		on_jump(base);
		break;
	case IDM_IMPORT_KAEDE:
		on_import_kaede(base);
		break;
	case IDM_IS_BOOK:
		on_is_book(base);
		break;
	case IDM_MODE_COLLECT:
		on_mode(base, MODE_COLLECT);
		break;
	case IDM_MODE_SELL:
		on_mode(base, MODE_SELL);
		break;
	case IDM_MODE_RETURN:
		on_mode(base, MODE_RETURN);
		break;
	case IDM_MONEY_UNIT:
		bASE_on_money_unit(base);
		break;
	case IDM_NEW_DOCUMENT:
		on_new(base);
		break;
	case IDM_OPEN_FILE:
		on_open(base);
		break;
	case IDM_PRINT:
		on_print(base);
		break;
	case IDM_SAVE_FILE:
		save(base);
		break;
	case IDM_SAVE_FILE_AS:
		save_as(base);
		break;
	case IDM_SEARCH_ITEM:
		on_search_item(base);
		break;
	case IDM_SEARCH_NEXT_ITEM:
		on_search_next_item(base);
		break;
	case IDM_SEARCH_PREV_ITEM:
		on_search_prev_item(base);
		break;
	case IDM_SELL:
		on_sell(base);
		break;
	case IDM_SET_REFUND_RATE:
		on_set_refund_rate(base);
		break;
	case IDM_USAGE:
		on_usage();
		break;
	}
	TOUCH(notify_code);
	TOUCH(ctrl_window);
	return 0;
}

static void on_double_clicked(Base base, LPNMLISTVIEW info) {
	LVITEM lv_item;

	if(info->iItem == -1) {
		return;
	}
	lv_item.mask = LVIF_PARAM;
	lv_item.iItem = info->iItem;
	ListView_GetItem(base->list_window, &lv_item);
	if(lv_item.lParam == NIL_ITEM) {
		if(base->mode == MODE_COLLECT) {
			edit_items(base, ItemList_ID_NEW, Base_FALSE);
		}
	} else {
		edit_items(base, lv_item.lParam, Base_FALSE);
	}
}

static void on_column_click(Base base, LPNMLISTVIEW info) {
	LVCOLUMN column;

	column.mask = LVCF_SUBITEM;
	ListView_GetColumn(base->list_window, info->iSubItem, &column);

	bASE_sort(base, column.iSubItem);
}

static void on_return(Base base) {
	LVITEM lv_item;

	lv_item.mask = LVIF_PARAM;

	for(lv_item.iItem = ListView_GetNextItem(base->list_window, -1, LVNI_ALL | LVNI_SELECTED);
			lv_item.iItem != -1;
			lv_item.iItem = ListView_GetNextItem(base->list_window, lv_item.iItem, LVNI_ALL | LVNI_SELECTED)) {
		ListView_GetItem(base->list_window, &lv_item);
		if(lv_item.lParam == NIL_ITEM) {
			if(base->mode == MODE_COLLECT) {
				edit_items(base, ItemList_ID_NEW, Base_FALSE);
			}
			break;
		} else {
			edit_items(base, lv_item.lParam, Base_FALSE);
		}
	}
}

static void on_delete(Base base) {
	char message[256];
	ItemList items;
	LVITEM lv_item;
	int i;

	if(base->mode != MODE_COLLECT) {
		return;
	}

	items = Document_item_list(base->document);

	lv_item.mask = LVIF_PARAM;

	if(ListView_GetNextItem(base->list_window, -1, LVNI_ALL | LVNI_SELECTED) == -1) {
		return;
	}

	LoadString(base->instance, IDS_MAKE_SURE_DELETE, message, sizeof(message));
	if(MessageBox(base->main_window, message, Application_name(), MB_YESNO | MB_ICONQUESTION) != IDYES) {
		return;
	}

	while(1) {
		lv_item.iItem = ListView_GetNextItem(base->list_window, -1, LVNI_ALL | LVNI_SELECTED);
		if(lv_item.iItem == -1) {
			break;
		}

		ListView_GetItem(base->list_window, &lv_item);
		if(lv_item.lParam == NIL_ITEM) {
			break;
		} else {
			ItemList_delete(items, lv_item.lParam);
			ListView_DeleteItem(base->list_window, lv_item.iItem);
			base->is_document_modified = Base_TRUE;
		}
	}
	bASE_display_item_count(base);
}

static void on_key_down(Base base, LV_KEYDOWN *info) {
	switch(info->wVKey) {
	case VK_RETURN:
		on_return(base);
		break;
	case VK_DELETE:
		on_delete(base);
		break;
	}
}

static int on_notify(Base base, NMHDR *info) {
	if(info->idFrom == ID_LIST_VIEW) {
		switch(info->code) {
		case NM_DBLCLK:
			on_double_clicked(base, (LPNMLISTVIEW)info);
			break;
		case LVN_COLUMNCLICK:
			on_column_click(base, (NMLISTVIEW *)info);
			break;
		case LVN_GETDISPINFO:
			bASE_on_get_display_info(base, (NMLVDISPINFO *)info);
			break;
		case LVN_KEYDOWN:
			on_key_down(base, (LV_KEYDOWN *)info);
			break;
		}
	}
	return 0;
}

static void init_menu_item(Base base, HMENU menu, int id) {
	MENUITEMINFO menu_item;

	menu_item.cbSize = sizeof(menu_item);
	menu_item.fMask = MIIM_STATE;

	switch(id) {
	case IDM_CHECKIT_MENUS:
		menu_item.fState = CheckitMenu_is_checkiting() ? MFS_CHECKED : MFS_UNCHECKED;
		break;
	case IDM_CHECKIT_CAPTIONS:
		menu_item.fState = CheckitCap_is_checkiting() ? MFS_CHECKED : MFS_UNCHECKED;
		break;
	case IDM_MODE_COLLECT:
		menu_item.fState = base->mode == MODE_COLLECT ? MFS_CHECKED : MFS_UNCHECKED;
		break;
	case IDM_MODE_SELL:
		menu_item.fState = base->mode == MODE_SELL ? MFS_CHECKED : MFS_UNCHECKED;
		break;
	case IDM_MODE_RETURN:
		menu_item.fState = base->mode == MODE_RETURN ? MFS_CHECKED : MFS_UNCHECKED;
		break;
	case IDM_SELL:
		menu_item.fState = base->mode == MODE_SELL ? MFS_ENABLED : MFS_DISABLED;
		break;
	case IDM_IS_BOOK:
		menu_item.fState = base->is_book ? MFS_CHECKED : MFS_UNCHECKED;
		break;
	case IDM_MONEY_UNIT:
		menu_item.fState = base->mode == MODE_RETURN ? MFS_ENABLED : MFS_DISABLED;
		break;
	default:
		menu_item.fState = MFS_ENABLED;
		break;
	}
	SetMenuItemInfo(menu, id, FALSE, &menu_item);
}

static void on_init_menu(Base base, HMENU menu) {
	int i;
	int menu_item_count;

	menu_item_count = GetMenuItemCount(menu);
	for(i = 0; i < menu_item_count; i++) {
		UINT id;

		id = GetMenuItemID(menu, i);
		init_menu_item(base, menu, id);
	}
}

static void on_set_focus(Base base) {
	BringWindowToTop(base->list_window);
	SetFocus(base->list_window);
}

static void on_size(Base base, int cx, int cy) {
	RECT rect;

	MoveWindow(base->status_window, 0, 0, cx, cy, TRUE);

	GetClientRect(base->status_window, &rect);
	MoveWindow(base->list_window, 0, 0, cx, cy-rect.bottom, TRUE);
}

static LRESULT CALLBACK main_window_proc(HWND main_window, UINT message, WPARAM word_param, LPARAM long_param) {
	Base base;

	if(message == WM_NCCREATE) {
		LPCREATESTRUCT create_info = (LPCREATESTRUCT) long_param;

		base = create_info->lpCreateParams;
		base->main_window = main_window;
		SetWindowLong(main_window, 0, (long) base);
	}

	base = (Base) GetWindowLong(main_window, 0);

	switch(message) {
	case WM_QUERYENDSESSION:
		if(on_exit(base)) {
			return 1L;
		} else {
			return 0L;
		}
	case WM_CLOSE:
		on_exit(base);
		break;
	case WM_COMMAND:
		on_command(base, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_INITMENUPOPUP:
		if(!HIWORD(long_param)) {
			on_init_menu(base, (HMENU)word_param);
		}
		break;
	case WM_NOTIFY:
		return on_notify(base, (NMHDR *)long_param);
	case WM_SETFOCUS:
		on_set_focus(base);
		break;
	case WM_SIZE:
		on_size(base, LOWORD(long_param), HIWORD(long_param));
		break;
	case WM_TIMER:
		auto_save(base);
		break;
	default:
		return DefWindowProc(main_window, message, word_param, long_param);
	}
	return 0L;
}

/*----------------------*
  windowz creation
 *----------------------*/
static void regist_class(HINSTANCE instance) {
	WNDCLASSEX class;

	class.cbSize = sizeof(class);
	class.style = CS_HREDRAW|CS_VREDRAW;
	class.lpfnWndProc = main_window_proc;
	class.cbClsExtra = 0;
	class.cbWndExtra = sizeof(Base);
	class.hInstance = instance;
	class.hIcon = LoadIcon(instance, MAKEINTRESOURCE(IDI_MAIN));
	class.hCursor = LoadCursor(0, IDC_ARROW);
	class.hbrBackground = (HBRUSH) (COLOR_MENU + 1);
	class.lpszMenuName = MAKEINTRESOURCE(IDR_MAIN_MENU);
	class.lpszClassName = CLASS_NAME_MAIN;
	class.hIconSm = LoadIcon(instance, MAKEINTRESOURCE(IDI_MAIN));
	RegisterClassEx(&class);
}

static HWND create_main_window(Base base, HINSTANCE instance, int n_cmd_show) {
	HWND main_window;

	main_window = CreateWindowEx(WS_EX_CONTROLPARENT|WS_EX_APPWINDOW,
			CLASS_NAME_MAIN, NULL, WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
			CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
			NULL, NULL, instance, base);
	ShowWindow(main_window, n_cmd_show);
	return main_window;
}

static void insert_column_aux(HWND list_window, int index, int column_id, int cx, Base_Boolean is_right_alligned) {
	LVCOLUMN lv_column;
	HINSTANCE instance;
	char text[256];

	instance = (HINSTANCE) GetWindowLong(list_window, GWL_HINSTANCE);
	LoadString(instance, column_id, text, sizeof(text) - 1);
	lv_column.mask = LVCF_SUBITEM  | LVCF_TEXT | LVCF_WIDTH | LVCF_FMT;
	if(is_right_alligned) {
		lv_column.fmt = LVCFMT_RIGHT;
	} else {
		lv_column.fmt = LVCFMT_LEFT;
	}
	lv_column.iSubItem = column_id;
	lv_column.pszText = text;
	lv_column.cx = cx;
	ListView_InsertColumn(list_window, index, &lv_column);
}

static void insert_columns(HWND list_window) {
	int column_count;
	char config_file_name[512];
	int i;

	strcpy(config_file_name, Config_file_name());
	column_count = GetPrivateProfileInt("MainWindow", "column_count", 1, config_file_name);
	for(i = 0; i < column_count; i++) {
		char column_name[128];
		char name_key[128];
		char width_key[128];
		int column_width;
		Base_Boolean is_right_alligned;
		int column_id;
		int j;

		sprintf(name_key, "column%d", i + 1);
		sprintf(width_key, "column_width%d", i + 1);
		GetPrivateProfileString("MainWindow", name_key, "item_name",
				column_name, sizeof(column_name), config_file_name);
		column_width = GetPrivateProfileInt("MainWindow", width_key, 60, config_file_name);

		for(j = 0; j < sizeof(column_infos) / sizeof(*column_infos); j++) {
			if(strcmp(column_name, column_infos[j].name) == 0) {
				column_id = column_infos[j].id;
				is_right_alligned = column_infos[j].right_allign_flag;
				break;
			}
		}
		if(i == sizeof(column_infos) / sizeof(*column_infos)) {
			column_id = column_infos[0].id;
			is_right_alligned = column_infos[0].right_allign_flag;
		}

		insert_column_aux(list_window, i, column_id, column_width, is_right_alligned);
	}
}

static HWND create_list_window(HWND main_window, HINSTANCE instance) {
	HWND list_window;

	InitCommonControls();

	list_window = CreateWindowEx(0, WC_LISTVIEW, "",
			WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | LVS_REPORT,
			0, 0, 10, 10,
			main_window, (HMENU)ID_LIST_VIEW, instance, NULL);
	ListView_SetExtendedListViewStyle(list_window, LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	ShowWindow(list_window, SW_SHOWNORMAL);
	insert_columns(list_window);
	return list_window;
}

static void create_windowz(Base base, HINSTANCE instance, int n_cmd_show) {
	RECT rect;
	int part_widths[] = {100, 170, 380, 500, 620};

	regist_class(instance);
	base->main_window = create_main_window(base, instance, n_cmd_show);
	base->list_window = create_list_window(base->main_window, instance);
	base->status_window = CreateStatusWindow(WS_CHILD | WS_VISIBLE | CCS_BOTTOM,
			NULL, base->main_window, ID_STATUS_BAR); 
	SendMessage(base->status_window, SB_SETPARTS,
			sizeof(part_widths) / sizeof(*part_widths), (LPARAM)(int*)part_widths);
	GetClientRect(base->main_window, &rect);
	SendMessage(base->main_window, WM_SIZE, 0, MAKELPARAM(rect.right, rect.bottom));
	BringWindowToTop(base->list_window);
	SetFocus(base->list_window);
}

static void touch_command_line(Base base) {
	int i;
	int argc;
	char ** argv;

	Argument_split_command_line(GetCommandLine(), &argc, &argv);

	if(argc <= 1) {
		base->document = Document_create();
		base->is_document_new = Base_TRUE;
		base->is_document_modified = Base_FALSE;
		bASE_calc_proceeds(base);
	} else {
		Document document;
		char full_path[400];
		Disk_ErrorType error_type;

		GetFullPathName(argv[1], sizeof(full_path), full_path, NULL);
		document = Disk_load(full_path, &error_type);
		if(document != NULL) {
			base->document = document;
			base->file_name = String_make(base->file_name, full_path);
			base->is_document_new = Base_FALSE;
			base->is_document_modified = Base_FALSE;
			bASE_calc_proceeds(base);
		} else {
			message_file_error(base, error_type);
			base->document = Document_create();
			base->is_document_new = Base_TRUE;
			base->is_document_modified = Base_FALSE;
			bASE_calc_proceeds(base);
		}
	}

	for(i = 0; i < argc; i++) {
		Memory_free(argv[i]);
	}
	Memory_free(argv);
}

void Base_select_item_to_return(Base base, int seller_id) {
	LVITEM lv_item;

	reset_selection(base);

	lv_item.mask = LVIF_PARAM;

	for(lv_item.iItem = ListView_GetNextItem(base->list_window, -1, LVNI_ALL);
			lv_item.iItem != -1;
			lv_item.iItem = ListView_GetNextItem(base->list_window, lv_item.iItem, LVNI_ALL)) {
		ConstItem item;
		ListView_GetItem(base->list_window, &lv_item);
		if(lv_item.lParam == NIL_ITEM) {
			continue;
		}

		item = ItemList_item(Document_item_list(base->document), lv_item.lParam);
		if(!Item_is_sold(item) && Item_is_to_be_returned(item) &&
				Item_seller_id(item) == seller_id) {
			ListView_SetItemState(base->list_window, lv_item.iItem,
					LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
			ListView_EnsureVisible(base->list_window, lv_item.iItem, TRUE);
		}
	}
}

void Base_set_item(Base base, int id, ConstItem item) {
	int new_item_id;

	Debug_assert(Memory_is_on_heap(base));

	bASE_modify_proceeds(base, id, item);
	bASE_display_cash(base);

	new_item_id = ItemList_set(Document_item_list(base->document), id, item);
	base->is_document_modified = Base_TRUE;
	if(id == ItemList_ID_NEW) {
		bASE_display_new_item(base, new_item_id);
		ListView_EnsureVisible(base->list_window, ListView_GetItemCount(base->list_window)-2, TRUE);
	} else {
		LVFINDINFO find_info;
		int index;

		find_info.flags = LVFI_PARAM;
		find_info.lParam = new_item_id;
		index = ListView_FindItem(base->list_window, -1, &find_info);
		ListView_Update(base->list_window, index);
	}
	auto_save(base);
	bASE_display_item_count(base);
	if(base->mode == MODE_RETURN) {
		calc_refunder(base);
		bASE_display_refunder_sum(base);
		SellerMngPanel_redraw(base->seller_mng_panel);
	}
}

static void happy_birthday_kaede(Base base) {
	time_t date_aux;
	struct tm date;

	date_aux = time(NULL);
	date = *localtime(&date_aux);
	if(date.tm_mon == 11 - 1 && date.tm_mday == 15) {
		char message[128];

		LoadString(base->instance, IDS_HAPPY_BIRTHDAY_KAEDE, message, sizeof(message));
		MessageBox(NULL, message, Application_name(), MB_OK | MB_ICONINFORMATION);
	}
}

int Base_main(Base base, HINSTANCE instance, int n_cmd_show) {
	MSG message;
	HACCEL accels;
	char application_name[128];

	base->instance = instance;

	LoadString(instance, IDS_APPLICATION_NAME, application_name, sizeof(application_name)-1);
	Application_set_name(application_name);

	Config_initialize();
	Print_initialize();
	Events_initialize();

	srand(time(NULL));

	happy_birthday_kaede(base);

	create_windowz(base, instance, n_cmd_show);
	base->timer = SetTimer(base->main_window, 1, 1000 * 60 * 3, NULL);

	accels = LoadAccelerators(instance, MAKEINTRESOURCE(IDR_MAIN_ACCELS));

	touch_command_line(base);

	bASE_display(base);

	CheckitCap_initialize(instance);
	CheckitMenu_initialize(instance);

	/* main loop */
	while(GetMessage(&message, 0, 0, 0)) {
		if (!TranslateAccelerator(base->main_window, accels, &message)) {
			TranslateMessage(&message);
			DispatchMessage(&message);
		}
	}

	CheckitMenu_finalize();
	CheckitCap_finalize();

	Events_finalize();
	Print_finalize();
	Config_finalize();

	return message.wParam;
}

static void set_sort_directions(Base base) {
	int i;

	for(i = 0; i < sizeof(column_infos) / sizeof(*column_infos); i++) {
		base->sort_directions[i].column_id = column_infos[i].id;
		base->sort_directions[i].ascend_flag = Base_TRUE;
	}
}

Base Base_create(void) {
	Base base;

	base = Memory_malloc(sizeof(*base));

	base->document = NULL;
	base->main_window = NULL;
	base->list_window = NULL;
	base->instance = NULL;

	base->file_name = String_make(NULL, "");

	base->sort_directions = Memory_malloc(sizeof(*base->sort_directions) *
			(sizeof(column_infos) / sizeof(*column_infos)));
	set_sort_directions(base);

	base->search_text = String_make(NULL, "");

	base->mode = MODE_COLLECT;

	base->is_book = Base_TRUE;

	base->seller_list = NULL;

	return base;
}

void Base_destroy(Base base) {
	Memory_free(base->file_name);
	Memory_free(base->search_text);
	Memory_free(base->sort_directions);

	if(base->seller_list) {
		SellerList_destroy(base->seller_list);
	}

	Memory_free(base);
}

/* end of file */
