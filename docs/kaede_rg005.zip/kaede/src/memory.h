/*
 * file: memory.h
 * purpose: public header file for Memory
 */

#ifndef _PUBLIC_MEMORY_H_INCLUDED
#define _PUBLIC_MEMORY_H_INCLUDED

#ifndef NULL
#define NULL ((void*)0)
#endif

typedef enum {
	Memory_TRUE = 1,
	Memory_FALSE = 0
} Memory_Boolean;

#ifdef DEBUG

#define Memory_initialize() Memory_initialize_dbg()
#define Memory_finalize() Memory_finalize_dbg()

#define Memory_is_on_heap(block) Memory_is_on_heap_dbg(block)

#define Memory_malloc(size) Memory_malloc_dbg(size, __FILE__, __LINE__)
#define Memory_realloc(block, size) Memory_realloc_dbg(block, size, __FILE__, __LINE__)
#define Memory_free(block) Memory_free_dbg(block, __FILE__, __LINE__)

extern Memory_Boolean Memory_is_on_heap_dbg(const void * block);
extern void *Memory_malloc_dbg(int size, const char *file_name, int line);
extern void *Memory_realloc_dbg(void *block, int size, const char *file_name, int line);
extern void Memory_free_dbg(void *block, const char *file_name, int line);
extern void Memory_initialize_dbg(void);
extern void Memory_finalize_dbg(void);


#else /* DEBUG is not defined */

#define Memory_initialize() ((void)0)
#define Memory_finalize() ((void)0)

#define Memory_is_on_heap(block) Memory_TRUE

extern void * Memory_malloc(int size);
extern void * Memory_realloc(void * block, int size);
extern void Memory_free(void * block);

#endif /* DEBUG */

#endif /* _PUBLIC_MEMORY_H_INCLUDED */
/* end of file */
