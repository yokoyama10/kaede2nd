/*
 * file: checkitCapP.h
 * purpose: private header file for CheckitCap
 */

#ifndef _PRIVATE_CHECKITCAPP_H_INCLUDED
#define _PRIVATE_CHECKITCAPP_H_INCLUDED

#include <windows.h>

#include "checkitCap.h"

#undef TRUE
#undef FALSE
#define TRUE CheckitCap_TRUE
#define FALSE CheckitCap_FALSE
typedef CheckitCap_Boolean Boolean;

typedef struct tagWindowData WindowData;

struct tagWindowData {
	HWND window;
	char *org_caption;
	WindowData *next;
};


/*-----------------------------------------*
   implemented in checkitCap_windowData.c
 *-----------------------------------------*/
extern WindowData checkitCap_WindowData_create(void);
extern void checkitCap_WindowData_destroy(WindowData window_data);


#endif /* _PRIVATE_CHECKITCAPP_H_INCLUDED */
/* end of file */
