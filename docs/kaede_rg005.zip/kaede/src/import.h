/*
 * file: import.h
 * purpose: public header file for Import
 */

#ifndef _PUBLIC_IMPORT_H_INCLUDED
#define _PUBLIC_IMPORT_H_INCLUDED

#include "documentType.h"

typedef enum {
	Import_TRUE = 1,
	Import_FALSE = 0
} Import_Boolean;

Import_Boolean Import_import(Document dest, Document src);

#endif /* _PUBLIC_IMPORT_H_INCLUDED */

/* end of file */
