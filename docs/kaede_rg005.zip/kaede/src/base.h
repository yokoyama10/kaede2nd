/*
 * file: base.h
 * purpose: public header file for Base
 */

#ifndef _PUBLIC_BASE_H_INCLUDED
#define _PUBLIC_BASE_H_INCLUDED

#include <windows.h>

#include "itemType.h"

#include "baseType.h"

typedef enum {
	Base_TRUE = 1,
	Base_FALSE = 0
} Base_Boolean;

extern void Base_select_item_to_return(Base base, int seller_id);
extern void Base_set_item(Base base, int id, ConstItem item);
extern int Base_main(Base base, HINSTANCE instance, int n_cmd_show);
extern Base Base_create(void);
extern void Base_destroy(Base base);

#endif /* _PUBLIC_BASE_H_INCLUDED */

/* end of file */
