/*
 * file: config.c
 * purpose: �ݒ�t�@�C���̖���Ԃ�����....�����B
 */

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include "memory.h"
#include "string.h"

#include "config.h"


char *st_file_name;


const char *Config_file_name(void) {
	return st_file_name;
}

void Config_initialize(void) {
	char drive[MAX_PATH], dir[MAX_PATH], fname[MAX_PATH];
	char path[MAX_PATH];
	char module_file_name[MAX_PATH];
	char line[256];
	FILE * file;
	
	GetModuleFileName(NULL, module_file_name, sizeof(module_file_name));
	_splitpath(module_file_name, drive, dir, fname, NULL);
	sprintf(path, "%s%s%s.ini", drive, dir, fname);
	
	st_file_name = String_make(st_file_name, path);
}

void Config_finalize(void) {
	Memory_free(st_file_name);
}

/* end of file */
