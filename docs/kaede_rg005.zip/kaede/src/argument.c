/*
 * file: argument.c
 * purpose: argv,argc�̐؂�o���B
 */

#include <string.h>
#include <dbcsstr.h>

#include "memory.h"
#include "debug.h"

#include "argument.h"

typedef enum {
	TRUE = 1,
	FALSE = 0
} Boolean;

/*---------------------------------------*
   argv,argc�̐؂�o��
   ���̂��炢�V�X�e�����ŗp�ӂ����B
   Unicode�p��API�͂���炵���񂾂��ǁB
 *---------------------------------------*/
static int get_argc(const char *command_line) {
	int argc;
	int si;
	Boolean is_in_quote;
	Boolean is_in_token;
	
	si = 0;
	argc = 0;
	is_in_quote = FALSE;
	is_in_token = FALSE;
	while(command_line[si] != '\0') {
		switch(command_line[si]) {
		case '\"':
			is_in_quote = is_in_quote ? FALSE : TRUE;
			break;
		case '/':
			if(is_in_quote == FALSE) {
				is_in_token = TRUE;
				argc++;
			}
			break;
		case ' ':
		case '\t':
			if(is_in_quote == FALSE) {
				is_in_token = FALSE;
			}
			break;
		default:
			if(is_in_token == FALSE) {
				is_in_token = TRUE;
				argc++;
			}
			break;
		}
		si++;
	}
	return argc;
}

static const char *first_token(const char *command_line) {
	const char *token;
	
	for(token = command_line; *token == ' ' || *token == '\t'; token++) {
		;
	}
	return token;
}

static const char *next_token(const char *prev) {
	Boolean is_in_quote;
	Boolean is_in_token;
	const char *sp;
	
	is_in_token = TRUE;
	is_in_quote = FALSE;
	sp = prev;
	while(1) {
		switch(*sp) {
		case '\0':
			return sp;
		case '/':
			if(sp != prev && is_in_quote == FALSE) {
				return sp;
			}
			break;
		case '\"':
			if(is_in_token == FALSE) {
				return sp;
			}
			is_in_quote = is_in_quote ? FALSE : TRUE;
			break;
		case ' ':
		case '\t':
			if(is_in_quote == FALSE) {
				is_in_token = FALSE;
			}
			break;
		default:
			if(is_in_token == FALSE) {
				return sp;
			}
			break;
		}
		sp++;
	}
}

static char *get_token(const char *source) {
	Boolean is_in_quote;
	char *token;
	int si,di;
	
	token = Memory_malloc(next_token(source) - source + 1);	/* �K�� */
	si = 0;
	di = 0;
	is_in_quote = FALSE;
	while(1) {
		switch(source[si]) {
		case '\0':
			goto quit;
		case '\"':
			is_in_quote = is_in_quote ? FALSE : TRUE;
			break;
		case '/':
		case ' ':
		case '\t':
			if(is_in_quote == FALSE && si != 0) {
				goto quit;
			} else {
				token[di] = source[si];
				di++;
			}
			break;
		default:
			token[di] = source[si];
			di++;
			break;
		}
		si++;
	}
quit:
	token[di] = '\0';
	return token;
}

static char **get_argv(const char *command_line, int argc) {
	int i;
	char **argv;
	const char *token;
	
	argv = Memory_malloc(sizeof(*argv) * argc);
	token = first_token(command_line);
	for(i = 0; i < argc; i++) {
		argv[i] = get_token(token);
		token = next_token(token);
	}
	return argv;
}

void Argument_split_command_line(const char *command_line, int *argc_ref, char ***argv_ref) {
	*argc_ref = get_argc(command_line);
	*argv_ref = get_argv(command_line, *argc_ref);
}

/* end of file */
