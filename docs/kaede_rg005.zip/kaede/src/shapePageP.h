/*
 * file: shapePageP.h
 * purpose: private header file for ShapPage
 */

#ifndef _PRIVATE_SHAPEPAGEP_H_INCLUDED
#define _PRIVATE_SHAPEPAGEP_H_INCLUDED

#include "shapePage.h"

#define IDD_SHAPE_PAGE 1008

#define IDC_SHAPE_NAME 101
#define IDC_SHAPES_LIST 102
#define IDC_APPEND_SHAPE 103
#define IDC_CLEAR_ALL_SHAPE 104

#define IDS_ASK_CLEAR 1601
#define IDS_ASK_CLEAR_AGAIN 1602


#undef TRUE
#undef FALSE
#define TRUE ShapePage_TRUE
#define FALSE ShapePage_FALSE

typedef ShapePage_Boolean Boolean;

struct tagShapePage {
	int selected_item;
	Boolean is_cleared;
	Boolean is_applied;
	ShapeList shape_list;
	Boolean is_shape_name_changed;
	HWND window;
	struct {
		HWND shapes;
	} ctrls;
};

#endif /* _PRIVATE_SHAPEPAGEP_H_INCLUDED */

/* end of file */
