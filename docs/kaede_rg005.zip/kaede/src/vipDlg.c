/*
 * file: vipDlg.c
 * purpose: ����/OB���X�g�̃v���p�e�B�{�b�N�X
 */

#include <windows.h>
#include "memory.h"
#include "debug.h"

#include "vipPage.h"

#include "vipDlgP.h"

const VipList VipDlg_ob_list(VipDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	return VipPage_vip_list(dialog->ob_page);
}

const VipList VipDlg_teacher_list(VipDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	return VipPage_vip_list(dialog->teacher_page);
}

VipDlg_Boolean VipDlg_dialogue(VipDlg dialog, HWND parent_window) {
	HPROPSHEETPAGE pages[2];
	PROPSHEETHEADER sheet;
	HINSTANCE instance;

	Debug_assert(Memory_is_on_heap(dialog));

	instance = (HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE);

	pages[0] = VipPage_create_page(dialog->teacher_page, instance);
	pages[1] = VipPage_create_page(dialog->ob_page, instance);

	sheet.dwSize = sizeof(sheet);
	sheet.dwFlags = PSH_NOAPPLYNOW;
	sheet.hInstance = instance;
	sheet.hwndParent = parent_window;
	sheet.nPages = sizeof(pages) / sizeof(pages[0]);
	sheet.u3.phpage = pages;
	sheet.pszCaption = "����/OB�̃��X�g";
	PropertySheet(&sheet);
	if(VipPage_is_applied(dialog->ob_page) || VipPage_is_applied(dialog->teacher_page)) {
		return VipDlg_TRUE;
	} else {
		return VipDlg_FALSE;
	}
}

VipDlg VipDlg_create(VipList ob_list, VipList teacher_list) {
	VipDlg dialog;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->ob_page = VipPage_create("OB", ob_list);
	dialog->teacher_page = VipPage_create("����", teacher_list);
	return dialog;
}

void VipDlg_destroy(VipDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	VipPage_destroy(dialog->ob_page);
	VipPage_destroy(dialog->teacher_page);
	Memory_free(dialog);
}

/* end of file */
