/*
 * file: seller_list.c
 * purpose: �o�i�҂̃��X�g
 */

#include "memory.h"
#include "debug.h"
#include "dictionary.h"

#include "sellerListP.h"


typedef struct tagEnumAux {
	void (*proc)(int id, int refunder, void *param);
	void *param;
} EnumStruct;

static void enum_aux(Dictionary_Key key, Dictionary_Data refunder, void *param) {
	EnumStruct *enum_struct = (EnumStruct*)param;
	
	enum_struct->proc((int)key, (int)refunder, enum_struct->param);
}

void SellerList_enum(SellerList seller_list, void(*proc)(int id, int refunder, void *param), void *param) {
	EnumStruct enum_struct;
	
	enum_struct.proc = proc;
	enum_struct.param = param;
	Dictionary_enum(seller_list->dictionary, enum_aux, &enum_struct);
}

void SellerList_set(SellerList seller_list, int id, int refunder) {
	Debug_assert(Memory_is_on_heap(seller_list));
	Debug_assert(refunder >= 0);
	
	Dictionary_set(seller_list->dictionary, (Dictionary_Key)id, (Dictionary_Data)refunder);
}

int SellerList_refunder(SellerList seller_list, int id) {
	int data;
	int refunder;
	
	Debug_assert(Memory_is_on_heap(seller_list));
	
	return Dictionary_data(seller_list->dictionary, (Dictionary_Key)id);
}

SellerList_Boolean SellerList_is_including(SellerList seller_list, int id) {
	Debug_assert(Memory_is_on_heap(seller_list));
	
	if((int)Dictionary_data(seller_list->dictionary, (Dictionary_Key)id) == -1) {
		return SellerList_FALSE;
	} else {
		return SellerList_TRUE;
	}
}

static int comp_id(Dictionary_Key key1, Dictionary_Key key2) {
	int a = (int)key1, b = (int)key2;
	
	return a - b;
}

SellerList SellerList_create(void) {
	SellerList seller_list;
	
	seller_list = Memory_malloc(sizeof(*seller_list));
	
	seller_list->dictionary = Dictionary_create((Dictionary_Data) - 1, comp_id);
	return seller_list;
}

void SellerList_destroy(SellerList seller_list) {
	Debug_assert(Memory_is_on_heap(seller_list));
	
	Dictionary_destroy(seller_list->dictionary);
	Memory_free(seller_list);
}

/* end of file */
