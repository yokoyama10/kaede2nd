/*
 * file: checkitMenu.h
 * purpose: public header file for CheckitMenu
 */

#ifndef _PUBLIC_CHECKITMENU_H_INCLUDED
#define _PUBLIC_CHECKITMENU_H_INCLUDED

typedef enum {
	CheckitMenu_TRUE = 1,
	CheckitMenu_FALSE = 0
} CheckitMenu_Boolean;


extern CheckitMenu_Boolean CheckitMenu_checkit(void);
extern void CheckitMenu_uncheckit(void);
extern CheckitMenu_Boolean CheckitMenu_is_checkiting(void);
extern void CheckitMenu_initialize(HINSTANCE instance);
extern void CheckitMenu_finalize(void);

#endif /* _PUBLIC_CHECKITMENU_H_INCLUDED */
/* end of file */
