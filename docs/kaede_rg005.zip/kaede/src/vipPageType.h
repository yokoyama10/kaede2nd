/*
 * file: vipPageType.h
 * purpose: public header file for VipPage
 */

#ifndef _PUBLIC_VIPPAGETYPE_H_INCLUDED
#define _PUBLIC_VIPPAGETYPE_H_INCLUDED

typedef struct tagVipPage *VipPage;

#endif /* _PUBLIC_VIPPAGETYPE_H_INCLUDED */

/* end of file */
