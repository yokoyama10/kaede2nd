/*
 * file: memory.c
 * purpose: �A���P�[�^����
 */

#include <windows.h>
#include <stdlib.h>
#include <math.h>
#include "debug.h"

#include "memory.h"

#undef TRUE
#undef FALSE

typedef enum {
	TRUE = 1,
	FALSE = 0
} Boolean;

static Boolean st_initialized = FALSE;

static int ceil_size(int size) {
	if(size == 0) {
		return 0;
	} else {
		return (int) pow(1.3, ceil(log(size) / log(1.3)));
	}
}

#ifdef DEBUG
/*----------------------------*
  �f�o�b�O�p���[�`���B
 *----------------------------*/

#define GAP_SIZE 4

#define GAP_BLOCK_VALUE 0xde
#define NEW_BLOCK_VALUE 0xed
#define RELEASED_BLOCK_VALUE 0xfd

/*-----------------------------------------------*
  �u���b�N�̍\��
  BlockHeader gap[GAP_SIZE] body[size] gap[GAP_SIZE]
 *-----------------------------------------------*/

typedef struct tagBlockHeader BlockHeader;
struct tagBlockHeader {
	BlockHeader *prev;
	BlockHeader *next;
	int size;
	const char *file_name;
	int line;
};

static BlockHeader st_tip_body;
static BlockHeader *st_tip = &st_tip_body;

static int st_committed_count = 0;

static void allocation_failed(int size, const char *file_name, int line) {
	Debug_error("error: �̈���m�ۂł��܂���\n");
	Debug_printf("error in %s, %d\n", file_name, line);
	Debug_printf("�̈���m�ۂł��܂���\n");
	Debug_printf("�v�����ꂽ�T�C�Y; %d\n", size);
	abort();
}

static void write_verification_buffer(unsigned char *p, int size, const char *file_name, int line) {
	BlockHeader *header;
	BlockHeader *prev;
	unsigned char *head_gap, *tail_gap;
	int i;

	header = (BlockHeader *) p;
	head_gap = p+sizeof(BlockHeader);
	tail_gap = p+sizeof(BlockHeader) + GAP_SIZE + size;
	prev = st_tip->prev;
	header->prev = prev;
	header->next = st_tip;
	prev->next = header;
	st_tip->prev = header;

	header->size = size;
	header->file_name = file_name;
	header->line = line;

	for(i = 0; i < GAP_SIZE; i++) {
		head_gap[i] = GAP_BLOCK_VALUE;
		tail_gap[i] = GAP_BLOCK_VALUE;
	}
}

static void unchain_verification_buffer(unsigned char *p) {
	BlockHeader *header;
	BlockHeader *prev, *next;

	header = (BlockHeader *) p;
	prev = header->prev;
	next = header->next;
	prev->next = next;
	next->prev = prev;
}

static void output_block_info(unsigned char *p) {
	BlockHeader *header;
	unsigned char *head_gap, *tail_gap;
	int i;


	header = (BlockHeader *)p;
	head_gap = p + sizeof(BlockHeader);
	tail_gap = p + sizeof(BlockHeader) + GAP_SIZE + header->size;

	Debug_printf("block size: %d\n", header->size);
	Debug_printf("allocated in %s, %d\n", header->file_name, header->line);
	Debug_printf("head gap: ");
	for(i = 0; i < GAP_SIZE; i++) {
		Debug_printf("0x%.2x ", head_gap[i]);
	}
	Debug_printf("\n");
	Debug_printf("tail gap: ");
	for(i = 0; i < GAP_SIZE; i++) {
		Debug_printf("0x%.2x ", tail_gap[i]);
	}
	Debug_printf("\n\n");
}

static void verify_block(unsigned char *p, const char *file_name, int line) {
	BlockHeader *header;
	unsigned char *head_gap, *tail_gap;
	int i;

	header = (BlockHeader *)p;
	head_gap = p+sizeof(BlockHeader);
	tail_gap = p+sizeof(BlockHeader) + GAP_SIZE + header->size;

	for(i = 0; i < GAP_SIZE; i++) {
		if(head_gap[i] != GAP_BLOCK_VALUE || tail_gap[i] != GAP_BLOCK_VALUE) {
			Debug_error("error: �̈���z���ď������݂�����Ă��܂�");

			Debug_printf("error in %s, %d\n", file_name, line);
			Debug_printf("�̈���z���ď������݂�����Ă��܂�\n");
			Debug_printf("block information\n");
			output_block_info(p);
			abort();
		}
	}
}

#if 0
/* strict */
Memory_Boolean Memory_is_on_heap_dbg(const void * block) {
	const BlockHeader * header;

	Debug_assert(st_initialized);

	for(header=st_tip->next; header!=st_tip; header=header->next) {
		const unsigned char * body;

		body = (unsigned char *)header+sizeof(BlockHeader)+GAP_SIZE;
		if(block>=body && block<body+header->size) {
			return Memory_TRUE;
		}
	}
	return Memory_FALSE;
}
#endif

/* practical */
Memory_Boolean Memory_is_on_heap_dbg(const void *block) {
	if(block == NULL) {
		Debug_printf("%p\n", block);
		return FALSE;
	}
	if((unsigned long)block == ((unsigned long)GAP_BLOCK_VALUE | (GAP_BLOCK_VALUE << 8) | 
				(GAP_BLOCK_VALUE << 16) | (GAP_BLOCK_VALUE << 24))) {
		Debug_printf("%p\n", block);
		return FALSE;
	}
	if((unsigned long)block == ((unsigned long)NEW_BLOCK_VALUE | (NEW_BLOCK_VALUE << 8) | 
				(NEW_BLOCK_VALUE << 16) | (NEW_BLOCK_VALUE << 24))) {
		Debug_printf("%p\n", block);
		return FALSE;
	}
	if((unsigned long)block == ((unsigned long)RELEASED_BLOCK_VALUE | (RELEASED_BLOCK_VALUE << 8) |
				(RELEASED_BLOCK_VALUE << 16) | (RELEASED_BLOCK_VALUE << 24))) {
		Debug_printf("%p\n", block);
		return FALSE;
	}
	return TRUE;
}

void * Memory_malloc_dbg(int size, const char *file_name, int line) {
	unsigned char *p;

	Debug_assert(st_initialized);

	if(size == 0) {
		return NULL;
	}

	st_committed_count += 1;
	p = malloc(sizeof(BlockHeader) + GAP_SIZE + size + GAP_SIZE);
	if(p == NULL) {
		allocation_failed(size, file_name, line);
		return NULL;
	} else {
		int i;
		unsigned char *body;

		body = p + sizeof(BlockHeader) + GAP_SIZE;
		write_verification_buffer(p, size, file_name, line);
		for(i = 0; i < size; i++) {
			body[i] = NEW_BLOCK_VALUE;
		}
		return body;
	}
}

void *Memory_realloc_dbg(void *block, int size, const char *file_name, int line) {
	Debug_assert(st_initialized);

	if(block == NULL) {
		return Memory_malloc_dbg(size, file_name, line);
	} else if(size == 0) {
		Memory_free_dbg(block, file_name, line);
		return NULL;
	} else {
		int old_size;
		BlockHeader *header;
		unsigned char *p;

		p = (unsigned char *)block - sizeof(BlockHeader) - GAP_SIZE;
		header = (BlockHeader *)p;
		old_size = header->size;
		verify_block(p, file_name, line);
		unchain_verification_buffer(p);
		if(size<old_size) {
			int i;
			unsigned char *body;

			body = block;
			for(i = size; i < old_size; i++) {
				body[i] = RELEASED_BLOCK_VALUE;
			}
		}

		p = realloc(p, ceil_size(sizeof(BlockHeader) + GAP_SIZE + size + GAP_SIZE));
		if(p == NULL) {
			allocation_failed(size, file_name, line);
			return NULL;
		} else {
			unsigned char *body;

			body = p + sizeof(BlockHeader) + GAP_SIZE;
			write_verification_buffer(p, size, file_name, line);
			if(size > old_size) {
				int i;
				for(i = old_size; i < size; i++) {
					body[i] = NEW_BLOCK_VALUE;
				}
			}
			return body;
		}
	}
}

void Memory_free_dbg(void *block, const char *file_name, int line) {
	Debug_assert(st_initialized);

	if(block == NULL) {
		return;
	} else {
		BlockHeader *header;
		unsigned char *p;
		unsigned char *body;
		int i;

		p = (unsigned char *)block-sizeof(BlockHeader) - GAP_SIZE;
		header = (BlockHeader *)p;
		body = block;
		verify_block(p, file_name, line);
		unchain_verification_buffer(p);
		for(i = 0; i < header->size; i++) {
			body[i] = RELEASED_BLOCK_VALUE;
		}
		st_committed_count -= 1;
		free(p);
	}
}

void Memory_initialize_dbg(void) {
	Debug_assert(!st_initialized);

	st_initialized = TRUE;

	st_committed_count = 0;
	st_tip = &st_tip_body;
	st_tip->prev = st_tip;
	st_tip->next = st_tip;
}

void Memory_finalize_dbg(void) {
	Debug_assert(st_initialized);

	if(st_committed_count != 0) {
		BlockHeader * header;

		Debug_error("error: �������Ă��Ȃ��̈悪����܂�");
		Debug_printf("error in finalization\n");
		Debug_printf("%d �ӏ��̗̈悪�������Ă��܂���\n", st_committed_count);
		for(header = st_tip->next; header != st_tip; header = header->next) {
			output_block_info((unsigned char *)header);
		}
		abort();
	}
	st_initialized = FALSE;
}

#else /* DEBUG is not defined */

/*-------------------------------*
  �f�o�b�O�R�[�h�������[�`���B
 *-------------------------------*/

static void allocation_failed(void) {
	MessageBox(NULL, "���������m�ۂł��܂���\n�s�{�ӂȂ���ُ�I�����܂�\n�J���҂ɘA�����Ă��ꂢ", "Kaede", MB_OK | MB_ICONSTOP);
	abort();
}

void *Memory_malloc(int size) {
	void *p;

	if(size == 0) {
		return NULL;
	}

	p = malloc(size);
	if(p == NULL) {
		allocation_failed();
	}
	return p;
}

void *Memory_realloc(void *block, int size) {
	if(block == NULL) {
		return Memory_malloc(size);
	} else if(size == 0) {
		Memory_free(block);
		return NULL;
	} else {
		void *p;

		p = realloc(block, ceil_size(size));
		if(p == NULL) {
			allocation_failed();
		}
		return p;
	}
}

void Memory_free(void *block) {
	if(block != NULL) {
		free(block);
	}
}

#endif /* DEBUG */
/* end of file */
