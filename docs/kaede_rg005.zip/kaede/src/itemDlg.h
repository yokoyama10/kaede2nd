/*
 * file: itemDlg.h
 * purpose: public header file for ItemDlg
 */

#ifndef _PUBLIC_ITEMDLG_H_INCLUDED
#define _PUBLIC_ITEMDLG_H_INCLUDED

#include <windows.h>
#include "itemType.h"
#include "baseType.h"

#include "itemDlgType.h"

#define ItemDlg_NEW_ITEM_ID (-1)

typedef enum {
	ItemDlg_TRUE = 1,
	ItemDlg_FALSE = 0
} ItemDlg_Boolean;

typedef enum {
	ItemDlg_CALM,
	ItemDlg_HASTE
} ItemDlg_Composure;

typedef enum {
	ItemDlg_COLLECT,
	ItemDlg_SELL,
	ItemDlg_RETURN
} ItemDlg_Mode;

extern ItemDlg_Boolean ItemDlg_dialogue(ItemDlg dialog, HWND parent_window);
extern ItemDlg ItemDlg_create(Base base, Document document, int item_id, ItemDlg_Mode mode, ItemDlg_Composure composure, ItemDlg_Boolean is_book);
extern void ItemDlg_destroy(ItemDlg dialog);

#endif /* _PUBLIC_ITEMDLG_H_INCLUDED */
/* end of file */
