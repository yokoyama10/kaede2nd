/*
 * file: seller.h
 * purpose: public header file for Seller
 */

#ifndef _PUBLIC_SELLER_H_INCLUDED
#define _PUBLIC_SELLER_H_INCLUDED

typedef enum {
	Seller_TRUE = 1,
	Seller_FALSE = 0
} Seller_Boolean;

typedef enum {
	Seller_STUDENT = 0,
	Seller_OB = 1,
	Seller_TEACHER = 2,
	Seller_LEGACY = 3,
	Seller_DONATION = 4
} Seller_Type;

extern int Seller_make_student_id(int grade, int class, int number);
extern int Seller_make_teacher_id(int vip);
extern int Seller_make_ob_id(int vip);
extern int Seller_make_legacy_id(void);
extern int Seller_make_donation_id(void);
extern Seller_Type Seller_type(int id);
extern int Seller_grade(int id);
extern int Seller_class(int id);
extern int Seller_number(int id);
extern int Seller_vip_id(int id);

#endif /* _PUBLIC_SELLER_H_INCLUDED */

/* end of file */
