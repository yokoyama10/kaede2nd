/*
 * file: genrePage.c
 * purpose: �W�������ƌ`��̕ҏW�v���p�e�B�̃W�������y�[�W
 */

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <string.h>
#include <dbcsstr.h>
#include "application.h"
#include "genreList.h"
#include "memory.h"
#include "debug.h"
#include "item.h"
#include "itemList.h"

#include "genrePageP.h"

#define TOUCH(a) ((void)(a))

typedef struct {
	GenrePage page;
	HTREEITEM root_node;
} DisplayGenre;

static void display_genre(GenrePage page, int genre, HTREEITEM parent_node);

static void display_genre_aux(int genre, void *param) {
	DisplayGenre *heke = (DisplayGenre*)param;

	display_genre(heke->page, genre, heke->root_node);
}

static void display_genre(GenrePage page, int genre, HTREEITEM parent_node) {
	TVINSERTSTRUCT item;
	HTREEITEM node;
	int i;
	DisplayGenre heke;

	item.hInsertAfter = TVI_LAST;
	item.hParent = parent_node;
	item.u.item.mask = TVIF_TEXT | TVIF_PARAM;
	item.u.item.lParam = genre;
	item.u.item.pszText = LPSTR_TEXTCALLBACK;
	node = TreeView_InsertItem(page->ctrls.genres, &item);

	heke.page = page;
	heke.root_node = node;
	GenreList_enum(page->genre_list, genre, display_genre_aux, &heke);
}

static void on_init_dialog(GenrePage page) {
	page->ctrls.genres = GetDlgItem(page->window, IDC_GENRES_TREE);
	page->ctrls.append = GetDlgItem(page->window, IDC_APPEND_GENRE);
	page->ctrls.delete = GetDlgItem(page->window, IDC_DELETE_GENRE);

	TreeView_DeleteAllItems(page->ctrls.genres);
	display_genre(page, GenreList_TOP, TVI_ROOT);
	SetFocus(page->ctrls.genres);
}

static Boolean set_genre_name(GenrePage page, int genre) {
	char text[128];

	GetDlgItemText(page->window, IDC_GENRE_NAME, text, sizeof(text)-1);
	if(strlen(text)==0) {
		return FALSE;
	} else {
		GenreList_set_name(page->genre_list, genre, text);
		return TRUE;
	}
}

static int node_depth(HWND genres_tree, HTREEITEM node) {
	if(node==NULL) {
		return -1;
	} else {
		return 1+node_depth(genres_tree, TreeView_GetParent(genres_tree, node));
	}
}

static int current_genre(GenrePage page) {
	HTREEITEM current_node;
	int genre;
	TVITEM current_item;

	current_node = TreeView_GetSelection(page->ctrls.genres);

	current_item.mask = TVIF_PARAM;
	current_item.hItem = current_node;
	TreeView_GetItem(page->ctrls.genres, &current_item);
	genre = current_item.lParam;
	return genre;
}

static void on_append_genre(GenrePage page) {
	HTREEITEM current_node;
	HTREEITEM new_node;
	TVINSERTSTRUCT item;
	int parent, genre;

	current_node = TreeView_GetSelection(page->ctrls.genres);
	parent = current_genre(page);

	genre = GenreList_add(page->genre_list, parent);
	GenreList_set_name(page->genre_list, genre, "�V�����W������");

	item.hParent = current_node;
	item.hInsertAfter = TVI_LAST;
	item.u.item.mask = TVIF_TEXT | TVIF_PARAM;
	item.u.item.lParam = genre;
	item.u.item.pszText = LPSTR_TEXTCALLBACK;
	new_node = TreeView_InsertItem(page->ctrls.genres, &item);
	TreeView_Select(page->ctrls.genres, new_node, TVGN_CARET);
}

static void genre_name_on_update(GenrePage page) {
	HTREEITEM current_node;

	current_node = TreeView_GetSelection(page->ctrls.genres);
	if(TreeView_GetParent(page->ctrls.genres, current_node)!=NULL) {
		page->is_genre_name_changed = TRUE;
	}
}

typedef struct {
	int genre;
	int used;
} GenreUsed;

static void genre_used_aux(int id, Item item, void *param) {
	GenreUsed *heke = param;

	if(Item_major_genre(item) == heke->genre) {
		heke->used = 1;
	} else if(Item_minor_genre(item) == heke->genre) {
		heke->used = 1;
	} else if(Item_extra_genre(item) == heke->genre) {
		heke->used = 1;
	}
}

static int genre_used(GenrePage page, int genre) {
	GenreUsed heke;

	heke.genre = genre;
	heke.used = 0;
	ItemList_enum(page->item_list, genre_used_aux, &heke);
	return heke.used;
}

static void on_delete_genre(GenrePage page) {
	int genre;

	genre = current_genre(page);
	if(genre_used(page, genre)) {
		MessageBox(page->window, "���̃W�������̏��i������̂ŁA�폜�ł��ւ��",
				Application_name(), MB_OK | MB_ICONERROR);
		return;
	}
	if(MessageBox(page->window, "�{���ɍ폜����?", Application_name(),
				MB_YESNO | MB_ICONQUESTION) == IDYES) {
		HTREEITEM current_node;

		current_node = TreeView_GetSelection(page->ctrls.genres);
		TreeView_DeleteItem(page->ctrls.genres, current_node);
		GenreList_delete(page->genre_list, genre);
	}
}

static void on_clear_all(GenrePage page) {
	char message[128];

	LoadString((HINSTANCE)GetWindowLong(page->window, GWL_HINSTANCE), IDS_ASK_CLEAR, message, sizeof(message));
	if(MessageBox(page->window, message, Application_name(), MB_YESNO | MB_ICONQUESTION) == IDYES &&
			MessageBox(page->window, message, Application_name(), MB_YESNO | MB_ICONQUESTION) == IDYES) {
		TreeView_DeleteAllItems(page->ctrls.genres);
		GenreList_clear(page->genre_list);
		page->is_cleared = TRUE;
		display_genre(page, GenreList_TOP, TVI_ROOT);
	}
}

static BOOL on_command(GenrePage page, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDC_GENRE_NAME:
		if(notify_code==EN_UPDATE) {
			genre_name_on_update(page);
		}
		break;
	case IDC_DELETE_GENRE:
		on_delete_genre(page);
		break;
	case IDC_CLEAR_ALL_GENRE:
		on_clear_all(page);
		break;
	case IDC_APPEND_GENRE:
		on_append_genre(page);
		break;
	}
	TOUCH(ctrl_window);
	TOUCH(notify_code);
	return (BOOL) TRUE;
}

static void on_get_display_info(GenrePage page, int id, LPNMTVDISPINFO disp_info) {
	static char text[256];
	int genre;

	genre = disp_info->item.lParam;
	if(genre == GenreList_TOP) {
		strcpy(text, "�W�������B");
	} else {
		char buf[16];
		sprintf(text, "%s: %s", GenreList_order_text(page->genre_list, genre, buf),
				GenreList_name(page->genre_list, genre));
	}
	disp_info->item.pszText = text;
	TOUCH(id);
	TOUCH(page);
}

static void on_sel_changed(GenrePage page, int id, LPNMTREEVIEW notify_info) {
	int old_tag, new_tag;

	if(node_depth(page->ctrls.genres, notify_info->itemNew.hItem) <= 2) {
		EnableWindow(page->ctrls.append, (BOOL) TRUE);
	} else {
		EnableWindow(page->ctrls.append, (BOOL) FALSE);
	}

	if(node_depth(page->ctrls.genres, notify_info->itemNew.hItem) != 0) {
		EnableWindow(page->ctrls.delete, (BOOL) TRUE);
	} else {
		EnableWindow(page->ctrls.delete, (BOOL) FALSE);
	}

	old_tag = notify_info->itemOld.lParam;
	if(old_tag != GenreList_TOP && page->is_genre_name_changed) {
		if(!set_genre_name(page, old_tag)) {
			page->is_genre_name_changed = FALSE;
			return;
		} else {
			TVITEM item;
			item.hItem = notify_info->itemOld.hItem;
			item.mask = TVIF_TEXT;
			item.pszText = LPSTR_TEXTCALLBACK;
			TreeView_SetItem(page->ctrls.genres, &item);
			page->is_genre_name_changed = FALSE;
		}
	}

	new_tag = notify_info->itemNew.lParam;
	if(new_tag!=GenreList_TOP) {
		SetDlgItemText(page->window, IDC_GENRE_NAME, GenreList_name(page->genre_list, new_tag));
		page->is_genre_name_changed = FALSE;
	} else {
		SetDlgItemText(page->window, IDC_GENRE_NAME, NULL);
	}
}

static void on_kill_active(GenrePage page) {
	HTREEITEM current_node;
	TVITEM item;
	int genre;

	current_node = TreeView_GetSelection(page->ctrls.genres);
	item.mask = TVIF_PARAM;
	item.hItem = current_node;
	TreeView_GetItem(page->ctrls.genres, &item);
	genre = item.lParam;
	if(genre != GenreList_TOP && page->is_genre_name_changed) {
		set_genre_name(page, genre);
	}
}


static BOOL on_notify(GenrePage page, int id, LPNMHDR notify_info) {
	switch(notify_info->code) {
	case TVN_GETDISPINFO:
		on_get_display_info(page, id, (LPNMTVDISPINFO) notify_info);
		break;
	case TVN_SELCHANGED:
		on_sel_changed(page, id, (LPNMTREEVIEW)notify_info);
		break;
	case PSN_KILLACTIVE:
		on_kill_active(page);
		break;
	case PSN_APPLY:
		on_kill_active(page);
		page->is_applied = TRUE;
		break;
	}
	return (BOOL) FALSE;
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	GenrePage page;
	if(message==WM_INITDIALOG) {
		PROPSHEETPAGE * page_info;
		page_info = (PROPSHEETPAGE *) long_param;
		page = (GenrePage) page_info->lParam;
		SetWindowLong(dialog_window, DWL_USER, (LONG)page);
		page->window = dialog_window;
	}
	page = (GenrePage) GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_NOTIFY:
		on_notify(page, (int) word_param, (LPNMHDR) long_param);
		break;
	case WM_INITDIALOG:
		on_init_dialog(page);
		break;
	case WM_COMMAND:
		on_command(page, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	default:
		return (BOOL) FALSE;
	}
	return (BOOL) TRUE;
}

HPROPSHEETPAGE GenrePage_create_page(GenrePage page, HINSTANCE instance) {
	PROPSHEETPAGE page_info;

	Debug_assert(Memory_is_on_heap(page));

	page_info.dwSize = sizeof(page_info);
	page_info.dwFlags = PSP_DEFAULT;
	page_info.hInstance = instance;
	page_info.u.pszTemplate = MAKEINTRESOURCE(IDD_GENRE_PAGE);
	page_info.pfnDlgProc = (DLGPROC) dialog_proc;
	page_info.lParam = (LPARAM) page;
	return CreatePropertySheetPage(&page_info);
}

GenreList GenrePage_genre_list(GenrePage page) {
	Debug_assert(Memory_is_on_heap(page));

	return page->genre_list;
}

GenrePage_Boolean GenrePage_is_cleared(GenrePage page) {
	Debug_assert(Memory_is_on_heap(page));

	return page->is_cleared;
}

GenrePage_Boolean GenrePage_is_applied(GenrePage page) {
	Debug_assert(Memory_is_on_heap(page));

	return page->is_applied;
}

GenrePage GenrePage_create(ConstGenreList genre_list, ItemList item_list) {
	int i;
	GenrePage page;

	page = Memory_malloc(sizeof(*page));
	page->genre_list = GenreList_clone(genre_list);
	page->item_list = item_list;
	page->is_cleared = FALSE;
	page->is_applied = FALSE;
	return page;
}

void GenrePage_destroy(GenrePage page) {
	int i;

	Debug_assert(Memory_is_on_heap(page));

	GenreList_destroy(page->genre_list);
	Memory_free(page);
}

/* end of file */
