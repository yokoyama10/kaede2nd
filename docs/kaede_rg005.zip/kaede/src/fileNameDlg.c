/*
 * file: fileNameDlg.c
 * purpose: �u�t�@�C�����J���v�u�t�@�C����ۑ��v�_�C�A���O
 */

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <dbcsstr.h>
#include <stdio.h>
#include <commdlg.h>
#include "string.h"
#include "memory.h"
#include "debug.h"

#include "fileNameDlgP.h"

const char *FileNameDlg_file_name(FileNameDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	return dialog->file_name;
}

FileNameDlg_Boolean FileNameDlg_dialogue(FileNameDlg dialog, HWND parent_window) {
	OPENFILENAME info;
	char filter[256];
	char file_name[MAX_PATH] = "";
	BOOL result;

	/* ���܂��ċꂢ �}�[�}���[�h */
	/* ���̒��̗V�A�Ƃ��Ă��������������� */
	/* �����A����ȂɗD���������炢���̂ɂ� */

	Debug_assert(Memory_is_on_heap(dialog));

	memset(&info, 0, sizeof(info));
	sprintf(filter, "%s filez (*.%s)%c*.%s%cAll filez (*.*)%c*.*%c%c",
			dialog->type_name, dialog->extension, 0,
			dialog->extension, 0, 0, 0, 0);

	info.lStructSize = sizeof(info);
	info.hwndOwner = parent_window;
	info.lpstrDefExt = dialog->extension;
	info.lpstrFilter = filter;
	info.lpstrFile = file_name;
	info.nMaxFile = sizeof(file_name);
	info.lpstrInitialDir = dialog->default_dir;
	if(dialog->mode == FileNameDlg_SAVE) {
		info.Flags = OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT;
		result = GetSaveFileName(&info);
	} else {
		strcpy(file_name, dialog->default_file_name);
		info.Flags = OFN_HIDEREADONLY|OFN_FILEMUSTEXIST;
		result = GetOpenFileName(&info);
	}
	/* �����A���̂܂ܐM���~�߂Ă� */
	/* �����A����Ȃɑ����e��ł��炠���������ꂻ���� */
	/* ����������C�ɂȂ�A����ȋC�����͉���? */
	/* �䂤�[�[�� */
	if(result) {
		dialog->file_name = String_make(dialog->file_name, file_name);
		return FileNameDlg_TRUE;
	} else {
		Debug_printf("reason: %d\n", CommDlgExtendedError());
		return FileNameDlg_FALSE;
	}
}

FileNameDlg FileNameDlg_create(const char *default_path, const char *extension, const char *type_name, FileNameDlg_Mode mode) {
	FileNameDlg dialog;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->file_name = String_make(NULL, "");
	dialog->mode = mode;

	dialog->default_dir = String_make(NULL, "");
	dialog->default_file_name = String_make(NULL, "");
	dialog->extension = String_make(NULL, extension);
	dialog->type_name = String_make(NULL, type_name);
	if(default_path!=NULL) {
		char drive[MAX_PATH], dir[MAX_PATH], file[MAX_PATH], extension[MAX_PATH];
		char text[MAX_PATH];
		_splitpath(default_path, drive, dir, file, extension);
		sprintf(text, "%s%s", drive, dir);
		dialog->default_dir = String_make(dialog->default_dir, text);
		sprintf(text, "%s%s", file, extension);
		dialog->default_file_name = String_make(dialog->default_file_name, text);
	} else {
		char text[MAX_PATH];
		GetCurrentDirectory(sizeof(text), text);
		dialog->default_dir = String_make(dialog->default_dir, text);
		sprintf(text, "*.%s", dialog->extension);
		dialog->default_file_name = String_make(dialog->default_file_name, text);
	}
	return dialog;
}

void FileNameDlg_destroy(FileNameDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	Memory_free(dialog->default_dir);
	Memory_free(dialog->default_file_name);
	Memory_free(dialog->file_name);
	Memory_free(dialog->extension);
	Memory_free(dialog->type_name);
	Memory_free(dialog);
}

/* end of file */
