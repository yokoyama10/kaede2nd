/*
 * file: aboutDlg.c
 * purpose: �o�[�W�������_�C�A���O�̕\��
 */

#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dbcsstr.h>
#include "memory.h"
#include "debug.h"
#include "events.h"

#include "aboutDlgP.h"

#define TOUCH(a) ((void)(a))
#define EVENT_COUNT_MAX 10


static void display_time_bomb(AboutDlg dialog) {
	int i;
	char text[256];
	
	Events_time_bomb_text(text, time(NULL));
	SetDlgItemText(dialog->window, IDC_TIME_BOMB, text);
}

static int on_timer(AboutDlg dialog) {
	display_time_bomb(dialog);
	return 0;
}

static int on_destroy(AboutDlg dialog) {
	KillTimer(dialog->window, dialog->timer);
	return 0;
}

static BOOL on_init_dialog(AboutDlg dialog) {
	dialog->timer = SetTimer(dialog->window, 1, 1000, NULL);
	
	display_time_bomb(dialog);
	return TRUE;
}

static BOOL on_command(AboutDlg dialog, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDOK:
		EndDialog(dialog->window, IDOK);
		break;
	case IDCANCEL:
		EndDialog(dialog->window, IDCANCEL);
		break;
	}
	TOUCH(notify_code);
	TOUCH(ctrl_window);
	return TRUE;
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	AboutDlg dialog;
	
	if(message==WM_INITDIALOG) {
		dialog = (AboutDlg) long_param;
		SetWindowLong(dialog_window, DWL_USER, (LONG)dialog);
		dialog->window = dialog_window;
	}
	dialog = (AboutDlg) GetWindowLong(dialog_window, DWL_USER);
	
	switch (message) {
	case WM_TIMER:
		return on_timer(dialog);
	case WM_INITDIALOG:
		on_init_dialog(dialog);
		break;
	case WM_COMMAND:
		on_command(dialog, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	case WM_DESTROY:
		return on_destroy(dialog);
	default:
		return FALSE;
	}
	return TRUE;
}

AboutDlg_Boolean AboutDlg_dialogue(AboutDlg dialog, HWND parent_window) {
	int return_value;
	HINSTANCE instance = (HINSTANCE) GetWindowLong(parent_window, GWL_HINSTANCE);
	
	Debug_assert(Memory_is_on_heap(dialog));
	
	return_value = DialogBoxParam(instance, MAKEINTRESOURCE(IDD_ABOUT_APPLICATION), parent_window, dialog_proc, (long)dialog);
	if(return_value == IDOK) {
		return AboutDlg_TRUE;
	} else {
		return AboutDlg_FALSE;
	}
}

void AboutDlg_destroy(AboutDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));
	
	Memory_free(dialog);
}

AboutDlg AboutDlg_create(void) {
	AboutDlg dialog;
	
	dialog = Memory_malloc(sizeof(*dialog));
	return dialog;
}

/* end of file */
