/*
 * file: vipListP.h
 * purpose: private header file for VipList
 */

#ifndef _PRIVATE_VIPLISTP_H_INCLUDED
#define _PRIVATE_VIPLISTP_H_INCLUDED

#include "vipList.h"

struct tagVipList {
	char **names;
	int count;
};

#endif /* _PRIVATE_VIPLISTP_H_INCLUDED */

/* end of file */
