/*
 * file: events.h
 * purpose: public header file for Events
 */

#ifndef _PUBLIC_EVENTS_H_INCLUDED
#define _PUBLIC_EVENTS_H_INCLUDED

extern void Events_time_bomb_text(char *text, time_t now);
extern void Events_initialize(void);
extern void Events_finalize(void);

#endif /* _PUBLIC_EVENTS_H_INCLUDED */

/* end of file */
