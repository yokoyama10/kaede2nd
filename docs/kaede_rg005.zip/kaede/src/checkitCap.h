/******************************************
  file: checkitCap.h
  purpose: public header file for ChitCap
 ******************************************/

#ifndef _PUBLIC_CHECKITCAP_H_INCLUDED
#define _PUBLIC_CHECKITCAP_H_INCLUDED

typedef enum {
	CheckitCap_TRUE = 1,
	CheckitCap_FALSE = 0
} CheckitCap_Boolean;

extern CheckitCap_Boolean CheckitCap_checkit(void);
extern void CheckitCap_uncheckit(void);
extern CheckitCap_Boolean CheckitCap_is_checkiting(void);
extern void CheckitCap_initialize(HINSTANCE instance);
extern void CheckitCap_finalize(void);

#endif /* _PUBLIC_CHECKITCAP_H_INCLUDED */
/* end of file */