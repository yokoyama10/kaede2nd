/*
 * file: dictionary.h
 * purpose: public header file for Dictionary
 */

#ifndef _PUBLIC_DICTIONARY_H_INCLUDED
#define _PUBLIC_DICTIONARY_H_INCLUDED

#include "dictionaryType.h"

typedef long Dictionary_Key;
typedef long Dictionary_Data;
typedef int (* Dictionary_Comparer)(Dictionary_Key key1, Dictionary_Key key2);
typedef void (* Dictionary_Iterator)(Dictionary_Key key, Dictionary_Data data, void *param);
typedef enum {
	Dictionary_TRUE = 1,
	Dictionary_FALSE = 0
} Dictionary_Boolean;


extern void Dictionary_enum_from(Dictionary dictionary, Dictionary_Key from, Dictionary_Iterator iterator, void *param);
extern void Dictionary_enum_to(Dictionary dictionary, Dictionary_Key to, Dictionary_Iterator iterator, void *param);
extern void Dictionary_enum_range(Dictionary dictionary, Dictionary_Key from, Dictionary_Key to, Dictionary_Iterator iterator, void *param);
extern void Dictionary_enum(Dictionary dictionary, Dictionary_Iterator iterator, void *param);
extern Dictionary_Boolean Dictionary_delete(Dictionary dictionary, Dictionary_Key key);
extern Dictionary_Data Dictionary_data(Dictionary dictionary, Dictionary_Key key);
extern void Dictionary_set(Dictionary dictionary, Dictionary_Key key, Dictionary_Data data);
extern Dictionary Dictionary_create(Dictionary_Data default_data, Dictionary_Comparer comp_func);
extern void Dictionary_destroy(Dictionary dictionary);

#endif /* _PUBLIC_DICTIONARY_H_INCLUDED */

/* end of file */
