/*
 * file: aboutDlgP.h
 * purpose: private header file for AboutDlg
 */

#ifndef _PRIVATE_ABOUTDLGP_H_INCLUDED
#define _PRIVATE_ABOUTDLGP_H_INCLUDED

#include <windows.h>
#include <time.h>

#include "aboutDlg.h"

#define IDD_ABOUT_APPLICATION 1004

#define IDC_TIME_BOMB 101

struct tagAboutDlg {
	HWND window;
	UINT timer;
};

#endif /* _PRIVATE_ABOUTDLGP_H_INCLUDED */
/* end of file */
