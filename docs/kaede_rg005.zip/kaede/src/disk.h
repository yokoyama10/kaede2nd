/*
 * file: disk.h
 * purpose: public header file for Disk
 */

#ifndef _PUBLIC_DISK_H_INCLUDED
#define _PUBLIC_DISK_H_INCLUDED

#include "documentType.h"

typedef enum {
	Disk_TRUE = 1,
	Disk_FALSE = 0
} Disk_Boolean;

typedef enum {
	Disk_SUCCESS = 1,
	Disk_NO_FILE,
	Disk_DATA_ERROR,
	Disk_CRC_UNMATCH,
	Disk_UNKNOWN_FILE,
	Disk_TOO_OLD_FILE,
	Disk_GET_NEW_VERSION,
	Disk_UNKNOWN_SAVE_ERROR
} Disk_ErrorType;

extern Document Disk_load(const char *file_name, Disk_ErrorType *error_type);
extern Disk_Boolean Disk_save(Document document, const char *path, Disk_ErrorType *error_type);

#endif /* _PUBLIC_DISK_H_INCLUDED */
/* end of file */
