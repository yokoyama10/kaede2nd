/*
 * file: item.h
 * purpose: public header file for ItemList
 */

#ifndef _PUBLIC_ITEMLIST_H_INCLUDED
#define _PUBLIC_ITEMLIST_H_INCLUDED

#include "itemType.h"

#include "itemListType.h"

#define ItemList_ID_NEW (-1)

extern int ItemList_set(ItemList item_list, int id, ConstItem org_item);
extern int ItemList_count(ItemList item_list);
extern int ItemList_first_id(ItemList item_list);
extern int ItemList_last_id(ItemList item_list);
extern void ItemList_enum(ItemList item_list, void(*proc)(int id, Item, void *param), void *param);
extern ConstItem ItemList_item(ItemList item_list, int id);
extern void ItemList_delete(ItemList item_list, int id);
extern ItemList ItemList_create(void);
extern void ItemList_destroy(ItemList item_list);

#endif /* _PUBLIC_ITEMLIST_H_INCLUDED */
/* end of file */
