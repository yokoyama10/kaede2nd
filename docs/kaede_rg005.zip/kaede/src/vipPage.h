/*
 * file: vipPage.h
 * purpose: public header file for VipPage
 */

#ifndef _PUBLIC_VIPPAGE_H_INCLUDED
#define _PUBLIC_VIPPAGE_H_INCLUDED

#include "vipListType.h"

#include "vipPageType.h"

typedef enum {
	VipPage_TRUE = 1,
	VipPage_FALSE = 0
} VipPage_Boolean;

extern HPROPSHEETPAGE VipPage_create_page(VipPage page, HINSTANCE instance);
extern VipList VipPage_vip_list(VipPage page);
extern VipPage_Boolean VipPage_is_applied(VipPage page);
extern VipPage VipPage_create(const char *title, VipList vip_list);
extern void VipPage_destroy(VipPage page);

#endif /* _PUBLIC_VIPPAGE_H_INCLUDED */

/* end of file */
