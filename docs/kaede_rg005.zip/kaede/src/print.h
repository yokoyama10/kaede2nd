/*
 * file: print.h
 * purpose: public header file for Print
 */

#ifndef _PUBLIC_PRINT_H_INCLUDED
#define _PUBLIC_PRINT_H_INCLUDED

#include "documentType.h"

extern void Print_print(Document document, const int *selected_ids, int selected_count, const char *doc_name, HWND parent_window);
extern void Print_initialize(void);
extern void Print_finalize(void);

#endif /* _PUBLIC_PRINT_H_INCLUDED */

/* end of file */
