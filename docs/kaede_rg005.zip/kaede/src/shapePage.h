/*
 * file: shapePage.h
 * purpose: public header file for ShapePage
 */

#ifndef _PUBLIC_SHAPEPAGE_H_INCLUDED
#define _PUBLIC_SHAPEPAGE_H_INCLUDED

#include "shapeListType.h"

#include "shapePageType.h"

typedef enum {
	ShapePage_TRUE = 1,
	ShapePage_FALSE = 0
} ShapePage_Boolean;

extern HPROPSHEETPAGE ShapePage_create_page(ShapePage page, HINSTANCE instance);
extern ShapePage_Boolean ShapePage_is_cleared(ShapePage page);
extern ShapePage_Boolean ShapePage_is_applied(ShapePage page);
extern ShapeList ShapePage_shape_list(ShapePage page);
extern ShapePage ShapePage_create(ShapeList shape_list);
extern void ShapePage_destroy(ShapePage page);

#endif /* _PUBLIC_SHAPEPAGE_H_INCLUDED */

/* end of file */
