/*
 * file: itemDlgP.h
 * purpose: private header file for ItemDlg
 */

#ifndef _PRIVATE_ITEMDLG_H_INCLUDED
#define _PRIVATE_ITEMDLG_H_INCLUDED

#include <windows.h>
#include "baseType.h"
#include "itemType.h"

#include "itemDlg.h"


#define IDD_ENTER_ITEM 1003

#define IDC_ITEM_ID 101
#define IDC_SELLER_GRADE 102
#define IDC_SELLER_CLASS 103
#define IDC_SELLER_NUMBER 104
#define IDC_SELLER_NAME 105
#define IDC_ITEM_NAME 106
#define IDC_LIST_PRICE 107
#define IDC_IS_TO_BE_RETURNED 108
#define IDC_IS_TO_BE_DISCOUNTED 109
#define IDC_IS_SOLD 110
#define IDC_REAL_PRICE 111
#define IDC_MAJOR_GENRES 112
#define IDC_MINOR_GENRES 113
#define IDC_EXTRA_GENRES 114
#define IDC_SHAPES 115
#define IDC_SCHEDULE_UNDEFINED 116
#define IDC_SCHEDULE_1 117
#define IDC_SCHEDULE_2 118
#define IDC_SCHEDULE_3 119
#define IDC_IS_BY_AUCTION 120
#define IDC_REFUND_RATE 122
#define IDC_COMMENT 123

#define IDS_FILL_CTRLS 1301


#define TEXT_OB "ob"
#define TEXT_TEACHER "teacher"
#define TEXT_LEGACY "legacy"
#define TEXT_DONATION "donation"

#define NEW_ITEM_ID ItemDlg_NEW_ITEM_ID

#undef TRUE
#undef FALSE
#define TRUE ItemDlg_TRUE
#define FALSE ItemDlg_FALSE

typedef ItemDlg_Boolean Boolean;

struct tagItemDlg {
	Base base;
	Document document;
	HWND window;
	int section_id;
	int item_id;
	int teacher_index;
	int ob_index;

	ItemDlg_Mode mode;
	ItemDlg_Composure composure;
	ItemDlg_Boolean is_book;
	struct {
		HWND item_id;
		HWND seller_grade;
		HWND seller_class;
		HWND seller_number;
		HWND seller_name;
		HWND item_name;
		HWND list_price;
		HWND is_to_be_discounted;
		HWND is_to_be_returned;
		HWND is_sold;
		HWND real_price;
		HWND booth_price;
		HWND major_genres;
		HWND minor_genres;
		HWND extra_genres;
		HWND shapes;
	} ctrls;
};



#endif /* _PRIVATE_ITEMDLG_H_INCLUDED */
/* end of file */
