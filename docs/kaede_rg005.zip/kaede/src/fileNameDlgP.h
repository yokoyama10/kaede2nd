/*
 * file: fileNameDlgP.h
 * purpose: private header file for FileNameDlg
 */

#ifndef _PRIVATE_FILENAMEDLGP_H_INCLUDED
#define _PRIVATE_FILENAMEDLGP_H_INCLUDED

#include "fileNameDlg.h"

struct tagFileNameDlg {
	char *default_dir;
	char *default_file_name;
	char *file_name;
	
	char *extension;
	char *type_name;
	FileNameDlg_Mode mode;
};

#endif /* _PRIVATE_FILENAMEDLGP_H_INCLUDED */
/* end of file */
