/*
 * file: refundRateDlg.c
 * purpose: �f�t�H���g�̕ԋ����̐ݒ�
 */

#include <windows.h>
#include "memory.h"
#include "debug.h"
#include "application.h"

#include "refundRateDlgP.h"

#define TOUCH(a) ((void)(a))


static void on_init_dialog(RefundRateDlg dialog) {
	SetDlgItemInt(dialog->window, IDC_REFUND_RATE, dialog->refund_rate, FALSE);
}

static void on_ok(RefundRateDlg dialog) {
	int is_translated;

	dialog->refund_rate = GetDlgItemInt(dialog->window, IDC_REFUND_RATE, &is_translated, FALSE);
	if(is_translated) {
		if(0 <= dialog->refund_rate && dialog->refund_rate <= 100) {
			EndDialog(dialog->window, IDOK);
		} else {
			char message[128];

			LoadString((HINSTANCE)GetWindowLong(dialog->window, GWL_HINSTANCE),
					IDS_OUT_OF_RANGE, message, sizeof(message));
			MessageBox(dialog->window, message, Application_name(), MB_OK | MB_ICONWARNING);
		}
	} else {
		char message[128];

		LoadString((HINSTANCE)GetWindowLong(dialog->window, GWL_HINSTANCE),
				IDS_DEFECT, message, sizeof(message));
		MessageBox(dialog->window, message, Application_name(), MB_OK | MB_ICONWARNING);
	}
}

static void on_command(RefundRateDlg dialog, WORD notify_code, WORD id, HWND ctrl_window) {
	switch(id) {
	case IDOK:
		on_ok(dialog);
		break;
	case IDCANCEL:
		EndDialog(dialog->window, IDCANCEL);
		break;
	}
	TOUCH(notify_code);
	TOUCH(ctrl_window);
}

static BOOL CALLBACK dialog_proc(HWND dialog_window, UINT message, WPARAM word_param, LPARAM long_param) {
	RefundRateDlg dialog;

	if(message == WM_INITDIALOG) {
		dialog = (RefundRateDlg)long_param;
		SetWindowLong(dialog_window, DWL_USER, (LONG)dialog);
		dialog->window = dialog_window;
	}
	dialog = (RefundRateDlg)GetWindowLong(dialog_window, DWL_USER);

	switch (message) {
	case WM_INITDIALOG:
		on_init_dialog(dialog);
		break;
	case WM_COMMAND:
		on_command(dialog, HIWORD(word_param), LOWORD(word_param), (HWND)long_param);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

int RefundRateDlg_refund_rate(RefundRateDlg dialog) {
	return dialog->refund_rate;
}

RefundRateDlg_Boolean RefundRateDlg_dialogue(RefundRateDlg dialog, HWND parent_window) {
	int return_value;
	HINSTANCE instance = (HINSTANCE)GetWindowLong(parent_window, GWL_HINSTANCE);

	Debug_assert(Memory_is_on_heap(dialog));

	return_value = DialogBoxParam(instance, MAKEINTRESOURCE(IDD_REFUND_RATE), parent_window, dialog_proc, (LONG)dialog);
	if(return_value == IDOK) {
		return RefundRateDlg_TRUE;
	} else {
		return RefundRateDlg_FALSE;
	}
}

RefundRateDlg RefundRateDlg_create(int refund_rate) {
	RefundRateDlg dialog;

	dialog = Memory_malloc(sizeof(*dialog));
	dialog->refund_rate = refund_rate;
	return dialog;
}

void RefundRateDlg_destroy(RefundRateDlg dialog) {
	Debug_assert(Memory_is_on_heap(dialog));

	Memory_free(dialog);
}

/* end of file */
