/*
 * file: config.h
 * purpose: public header file for Config
 */

#ifndef _PUBLIC_CONFIG_H_INCLUDED
#define _PUBLIC_CONFIG_H_INCLUDED

extern const char *Config_file_name(void);
extern void Config_initialize(void);
extern void Config_finalize(void);

#endif /* _PUBLIC_CONFIG_H_INCLUDED */

/* end of file */
