/*
 * file: sellerMngPanel.h
 * purpose: public header file for SellerMngPanel
 */

#ifndef _PUBLIC_SELLERMNGPANEL_H_INCLUDED
#define _PUBLIC_SELLERMNGPANEL_H_INCLUDED

#include <windows.h>
#include "baseType.h"
#include "sellerListType.h"
#include "documentType.h"

#include "sellerMngPanelType.h"

typedef enum {
	SellerMngPanel_TRUE = 1,
	SellerMngPanel_FALSE = 0
} SellerMngPanel_Boolean;

extern void SellerMngPanel_redraw(SellerMngPanel panel);
extern void SellerMngPanel_create_window(SellerMngPanel panel, HWND parent_window);
extern void SellerMngPanel_destroy_window(SellerMngPanel panel);
extern SellerMngPanel SellerMngPanel_create(Base base, Document document, SellerList seller_list);
extern void SellerMngPanel_destroy(SellerMngPanel panel);

#endif /* _PUBLIC_SELLERMNGPANEL_H_INCLUDED */

/* end of file */
