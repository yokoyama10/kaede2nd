/*
 * file: checkitCap.c
 * purpose: �L���v�V�������`�F�L!�𑀍삷�邪��B
 */

#include <windows.h>
#include <stdio.h>
#include "debug.h"
#include "memory.h"
#include "config.h"
#include "string.h"
#include "../include/checkit_caption_common.h"

#include "checkitCapP.h"

#define SERVER_WINDOW_CLASS_NAME "CheckitCaptionServer"
#define DLL_NAME "chitcap.dll"
#define MUTEX_NAME "checkit caption mutex name"


#define EXPORT _declspec(dllexport)
#pragma pack(1)
#pragma pack()

static HINSTANCE st_instance;

static Boolean st_initialized = FALSE;

static WindowData * st_first_window_data = NULL;
static HWND st_server_window = NULL;
static UINT st_window_created_message, st_text_changed_message, st_focus_set_message;
static UINT st_window_destroyed_message;
static Boolean st_is_ready;
static Boolean st_is_checkiting;
static char * * st_forms;
static int st_form_count;

static HANDLE st_mutex;
static HMODULE st_dll;

typedef EXPORT void (*ResetCheckit)(void);
typedef EXPORT void (*SetCheckit)(HWND);

static void get_org_caption(WindowData * window_data) {
	char text[512];

	GetWindowText(window_data->window, text, sizeof(text));
	window_data->org_caption = String_make(window_data->org_caption, text);
}

static void set_caption(WindowData *window_data) {
	char text[512];
	int r;

	r = rand() % st_form_count;
	sprintf(text, st_forms[r], window_data->org_caption,
			window_data->org_caption, window_data->org_caption);
	SendMessage(window_data->window, WM_SETTEXT, MAGIC_WORD, (LPARAM) text);
}

static void checkit_window(HWND window) {
	WindowData *window_data;

	window_data = Memory_malloc(sizeof(*window_data));
	window_data->org_caption = String_make(NULL, "");
	window_data->next = st_first_window_data;

	st_first_window_data = window_data;
	window_data->window = window;

	get_org_caption(window_data);
	set_caption(window_data);
}

static WindowData *search_window_data(HWND window) {
	WindowData *window_data;

	for(window_data = st_first_window_data; window_data; window_data = window_data->next) {
		if(window_data->window == window) {
			return window_data;
		}
	}
	return NULL;
}

static void on_text_changed(HWND window, WORD word) {
	WindowData *window_data;

	if((GetWindowLong(window, GWL_STYLE) & WS_CAPTION) != WS_CAPTION) {
		return;
	}
	window_data = search_window_data(window);
	if(window_data == NULL) {
		checkit_window(window);
		window_data = st_first_window_data;
	}

	if(word != MAGIC_WORD) {
		get_org_caption(window_data);
		set_caption(window_data);
	}
}

static void on_window_created(HWND window) {
	if((GetWindowLong(window, GWL_STYLE)&WS_CAPTION)==WS_CAPTION) {
		checkit_window(window);
	}
}

static void on_focus_set(HWND window) {
	WindowData *window_data;

	if((GetWindowLong(window, GWL_STYLE) & WS_CAPTION) != WS_CAPTION) {
		return;
	}
	window_data = search_window_data(window);
	if(window_data == NULL) {
		checkit_window(window);
		window_data = st_first_window_data;
	}

	set_caption(window_data);
}

static void on_window_destroyed(HWND window) {
	WindowData *window_data, *prev;

	prev = NULL;
	for(window_data = st_first_window_data; window_data; window_data = window_data->next) {
		if(window_data->window == window) {
			if(prev == NULL) {
				st_first_window_data = window_data->next;
			} else {
				prev->next = window_data->next;
			}
			Memory_free(window_data->org_caption);
			Memory_free(window_data);
			return;
		}
		prev = window_data;
	}
}

static LRESULT CALLBACK server_window_proc(HWND window,UINT message,WPARAM word_param,LPARAM long_param) {
	if(!st_is_ready) {
		return DefWindowProc(window, message, word_param, long_param);
	}

	if(message == st_window_created_message) {
		on_window_created((HWND)word_param);
	} else if(message == st_text_changed_message) {
		on_text_changed((HWND)word_param, long_param);
	} else if(message == st_focus_set_message) {
		on_focus_set((HWND)word_param);
	} else if(message == st_window_destroyed_message) {
		on_window_destroyed((HWND)word_param);
	} else {
		return DefWindowProc(window, message, word_param, long_param);
	}
	return 0L;
}


static void regist_window_class(void) {
	WNDCLASS window_class;

	window_class.style = CS_HREDRAW|CS_VREDRAW;
	window_class.lpfnWndProc = server_window_proc;
	window_class.cbClsExtra = 0;
	window_class.cbWndExtra = 0;
	window_class.hInstance = st_instance;
	window_class.hIcon = NULL;
	window_class.hCursor = LoadCursor(0, IDC_ARROW);
	window_class.hbrBackground = GetStockObject(WHITE_BRUSH);
	window_class.lpszMenuName = (LPSTR)NULL;
	window_class.lpszClassName = SERVER_WINDOW_CLASS_NAME;
	RegisterClass(&window_class);
}

static HWND create_server_window(void) {
	return CreateWindow(SERVER_WINDOW_CLASS_NAME, "checkit caption", WS_POPUP,
			-30, -30, 20, 20, NULL, NULL, st_instance, NULL);
}

static BOOL CALLBACK enum_proc(HWND window, LPARAM long_param) {
	if((GetWindowLong(window, GWL_STYLE) & WS_CAPTION) == WS_CAPTION) {
		checkit_window(window);
	}
	EnumChildWindows(window, enum_proc, 0);
	return (BOOL) TRUE;
}

static void checkit_all_windows(void) {
	EnumWindows(enum_proc, 0);
}

CheckitCap_Boolean CheckitCap_checkit(void) {
	SetCheckit set_checkit_captions;

	Debug_assert(st_initialized);

	if(st_dll == NULL || st_form_count == 0 || st_is_checkiting) {
		return FALSE;
	}
	st_mutex = CreateMutex(NULL, FALSE, MUTEX_NAME);
	if(GetLastError() == ERROR_ALREADY_EXISTS) {
		CloseHandle(st_mutex);
		return FALSE;
	}

	set_checkit_captions = (SetCheckit)GetProcAddress(st_dll, "_set_checkit_captions");

	st_window_created_message = RegisterWindowMessage(WINDOW_CREATED_MESSAGE_NAME);
	st_text_changed_message = RegisterWindowMessage(TEXT_CHANGED_MESSAGE_NAME);
	st_focus_set_message = RegisterWindowMessage(FOCUS_SET_MESSAGE_NAME);
	st_window_destroyed_message = RegisterWindowMessage(WINDOW_DESTROYED_MESSAGE_NAME);

	st_server_window = create_server_window();

	st_is_ready = FALSE;
	st_first_window_data = NULL;
	set_checkit_captions(st_server_window);
	st_is_ready = TRUE;
	checkit_all_windows();
	st_is_checkiting = TRUE;

	return TRUE;
}

void CheckitCap_uncheckit(void) {
	ResetCheckit reset_checkit_captions;
	WindowData * window_data, * next;

	Debug_assert(st_initialized);

	if(st_dll == NULL || st_form_count == 0 || !st_is_checkiting) {
		return;
	}

	reset_checkit_captions = (ResetCheckit)GetProcAddress(st_dll, "_reset_checkit_captions");

	st_is_ready = FALSE;

	reset_checkit_captions();

	for(window_data = st_first_window_data; window_data; window_data = next) {
		next = window_data->next;
		SetWindowText(window_data->window, window_data->org_caption);
		Memory_free(window_data->org_caption);
		Memory_free(window_data);
	}
	st_first_window_data = NULL;
	DestroyWindow(st_server_window);
	st_server_window = NULL;

	st_is_checkiting = FALSE;
	CloseHandle(st_mutex);
}

CheckitCap_Boolean CheckitCap_is_checkiting(void) {
	Debug_assert(st_initialized);
	return st_is_checkiting;
}

static void load_forms(void) {
	int i;

	st_form_count = GetPrivateProfileInt("CheckitCaption", "neta_count", 0, Config_file_name());
	st_forms = Memory_malloc(sizeof(*st_forms) * st_form_count);

	for(i = 0; i < st_form_count; i++) {
		char key_name[128];
		char neta[128];

		sprintf(key_name, "neta%d", i + 1);
		GetPrivateProfileString("CheckitCaption", key_name, "%s", neta,
				sizeof(neta), Config_file_name());
		st_forms[i] = String_make(NULL, neta);
	}
}

static void destroy_forms(void) {
	int i;

	for(i = 0; i < st_form_count; i++) {
		Memory_free(st_forms[i]);
	}
	Memory_free(st_forms);
}

void CheckitCap_initialize(HINSTANCE instance) {
	Debug_assert(!st_initialized);

	st_instance = instance;
	st_initialized = TRUE;

	regist_window_class();
	load_forms();
	st_dll = LoadLibrary(DLL_NAME);
	st_is_checkiting = FALSE;
}

void CheckitCap_finalize(void) {
	Debug_assert(st_initialized);

	if(st_is_checkiting) {
		CheckitCap_uncheckit();
	}
	destroy_forms();
	FreeLibrary(st_dll);

	st_initialized = FALSE;
}

/* end of file */
